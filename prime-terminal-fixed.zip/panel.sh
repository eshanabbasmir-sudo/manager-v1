#!/usr/bin/env bash
# =============================================================================
#  PRIME TERMINAL — installer and service manager
#
#  Usage:
#     bash panel.sh                  install (or re-run to repair/update)
#     bash panel.sh start|stop|restart|status
#     bash panel.sh update
#     bash panel.sh uninstall
#     bash panel.sh reset-password
#     bash panel.sh logs
#     bash panel.sh config
#
#  The script never reports success unless the panel is actually serving HTTP.
# =============================================================================
set -uo pipefail

APP_NAME="PRIME TERMINAL"
APP_SLUG="prime-terminal"
APP_VERSION="1.0.0"
REQUIREMENTS=(fastapi uvicorn websockets)

SCRIPT_PATH="$(readlink -f "${BASH_SOURCE[0]}" 2>/dev/null || echo "${BASH_SOURCE[0]}")"
SCRIPT_DIR="$(cd "$(dirname "${SCRIPT_PATH}")" && pwd)"

# ---------------------------------------------------------------- colours ----
if [ -t 1 ] && [ "${NO_COLOR:-}" = "" ]; then
  C_RESET=$'\033[0m'; C_BOLD=$'\033[1m'; C_DIM=$'\033[2m'
  C_RED=$'\033[31m'; C_GREEN=$'\033[32m'; C_YELLOW=$'\033[33m'; C_BLUE=$'\033[34m'
  C_CYAN=$'\033[36m'; C_MAGENTA=$'\033[35m'
else
  C_RESET=""; C_BOLD=""; C_DIM=""; C_RED=""; C_GREEN=""; C_YELLOW=""; C_BLUE=""
  C_CYAN=""; C_MAGENTA=""
fi

say()   { printf '%s\n' "$*"; }
info()  { printf '%s\n' "  ${C_BLUE}•${C_RESET} $*"; }
ok()    { printf '%s\n' "  ${C_GREEN}✓${C_RESET} $*"; }
warn()  { printf '%s\n' "  ${C_YELLOW}!${C_RESET} $*" >&2; WARNINGS=$((WARNINGS + 1)); }
fail()  { printf '%s\n' "  ${C_RED}✗${C_RESET} $*" >&2; }
die()   { fail "$*"; say ""; say "${C_RED}${C_BOLD}Installation did not complete.${C_RESET}"; exit 1; }
step()  { say ""; say "${C_BOLD}${C_CYAN}$*${C_RESET}"; }

WARNINGS=0
INTERRUPTED=0
on_interrupt() {
  INTERRUPTED=1
  say ""
  fail "Interrupted by the user."
  say "${C_YELLOW}Nothing is left half-configured that a re-run cannot fix; run 'bash panel.sh' again.${C_RESET}"
  exit 130
}
trap on_interrupt INT TERM

banner() {
  say ""
  say "${C_MAGENTA}${C_BOLD}========================================${C_RESET}"
  say "${C_BOLD}       ${APP_NAME} INSTALLER${C_RESET}"
  say "${C_DIM}       real Linux control panel · v${APP_VERSION}${C_RESET}"
  say "${C_MAGENTA}${C_BOLD}========================================${C_RESET}"
}

# ------------------------------------------------------------- preflight ----
detect_os() {
  step "Checking operating system..."
  OS_ID=""; OS_NAME=""; OS_VERSION=""; ARCH=""
  ARCH="$(uname -m)"
  case "$ARCH" in
    x86_64|amd64)   ARCH_PY="x86_64" ;;
    aarch64|arm64)  ARCH_PY="aarch64" ;;
    armv7l|armv6l)  ARCH_PY="armv7l" ;;
    *)              ARCH_PY="$ARCH" ;;
  esac
  if [ -r /etc/os-release ]; then
    # shellcheck disable=SC1091
    . /etc/os-release
    OS_ID="${ID:-unknown}"
    OS_NAME="${PRETTY_NAME:-${NAME:-unknown}}"
    OS_VERSION="${VERSION_ID:-unknown}"
  elif [ "$(uname -s)" = "Darwin" ]; then
    die "macOS is not supported. This panel manages a Linux server."
  else
    die "Cannot read /etc/os-release — this does not look like a supported Linux system."
  fi
  ok "${OS_NAME} (${OS_ID} ${OS_VERSION}) on ${ARCH_PY}"
  case "$OS_ID" in
    ubuntu|debian|linuxmint|pop|raspbian|kali|elementary|zorin|neon|devuan)
      FAMILY="debian" ;;
    fedora)                       FAMILY="fedora" ;;
    rhel|centos|rocky|almalinux|ol|amzn) FAMILY="rhel" ;;
    arch|manjaro|endeavouros|garuda)     FAMILY="arch" ;;
    alpine)                       FAMILY="alpine" ;;
    opensuse*|sles|sled)          FAMILY="suse" ;;
    *)                            FAMILY="unknown" ;;
  esac
  if [ "$FAMILY" = "unknown" ]; then
    warn "Unrecognised distribution '${OS_ID}'. The installer will continue with whatever tools are present."
  else
    ok "Package family: ${FAMILY}"
  fi
}

detect_pm() {
  PKG_MGR=""
  if command -v apt-get >/dev/null 2>&1; then PKG_MGR="apt"
  elif command -v dnf >/dev/null 2>&1; then PKG_MGR="dnf"
  elif command -v yum >/dev/null 2>&1; then PKG_MGR="yum"
  elif command -v pacman >/dev/null 2>&1; then PKG_MGR="pacman"
  elif command -v zypper >/dev/null 2>&1; then PKG_MGR="zypper"
  elif command -v apk >/dev/null 2>&1; then PKG_MGR="apk"
  fi
  if [ -n "$PKG_MGR" ]; then ok "Package manager: ${PKG_MGR}"; else warn "No supported package manager detected."; fi
}

check_privileges() {
  step "Checking permissions and disk space..."
  EUID_NOW="$(id -u)"
  if [ "$EUID_NOW" -eq 0 ]; then
    AS_ROOT=1
    ok "Running as root — the panel will be installed system-wide."
  else
    AS_ROOT=0
    if command -v sudo >/dev/null 2>&1; then
      if sudo -n true 2>/dev/null; then
        SUDO="sudo -n"; ok "Running as a normal user with passwordless sudo available."
      else
        SUDO="sudo"; warn "Not root: system packages will be installed with sudo (you may be asked for a password)."
      fi
    else
      SUDO=""; warn "Not root and sudo is unavailable: the installer will only install what the current user can."
    fi
  fi

  # disk space check on the target filesystem
  local need_mb=350 avail_mb
  avail_mb="$(df -Pk / | awk 'NR==2 {print int($4/1024)}')"
  if [ -z "$avail_mb" ]; then warn "Could not determine free disk space."; return 0; fi
  if [ "$avail_mb" -lt "$need_mb" ]; then
    die "Not enough free disk space: ${avail_mb} MB available, ${need_mb} MB required."
  fi
  ok "Free disk space: ${avail_mb} MB"

  if [ ! -e /dev/ptmx ] || [ ! -e /dev/pts ]; then
    warn "/dev/ptmx or /dev/pts is missing — interactive terminal sessions will not work in this environment."
  else
    ok "PTY support present (/dev/ptmx)"
  fi
}

# ---------------------------------------------------------- dependencies ----
as_root() {
  if [ "$AS_ROOT" -eq 1 ]; then "$@"; else ${SUDO:+$SUDO} "$@"; fi
}

pkg_install() {
  local pkgs=("$@")
  [ ${#pkgs[@]} -eq 0 ] && return 0
  case "$PKG_MGR" in
    apt)     as_root env DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "${pkgs[@]}" ;;
    dnf)     as_root dnf install -y "${pkgs[@]}" ;;
    yum)     as_root yum install -y "${pkgs[@]}" ;;
    pacman)  as_root pacman -Sy --noconfirm --needed "${pkgs[@]}" ;;
    zypper)  as_root zypper --non-interactive install "${pkgs[@]}" ;;
    apk)     as_root apk add --no-cache "${pkgs[@]}" ;;
    *)       return 127 ;;
  esac
}

ensure_python() {
  step "Checking dependencies..."
  PYTHON=""
  for cand in python3 python3.13 python3.12 python3.11 python3.10 python3.9; do
    if command -v "$cand" >/dev/null 2>&1; then PYTHON="$(command -v "$cand")"; break; fi
  done
  if [ -z "$PYTHON" ]; then
    warn "Python 3 was not found — installing it."
    case "$PKG_MGR" in
      apt)    pkg_install python3 python3-venv python3-pip ;;
      dnf|yum) pkg_install python3 python3-pip ;;
      pacman) pkg_install python python-pip ;;
      zypper) pkg_install python3 python3-pip ;;
      apk)    pkg_install python3 py3-pip ;;
      *)      die "Python 3 is required and no package manager is available to install it." ;;
    esac
    for cand in python3 python3.13 python3.12 python3.11 python3.10 python3.9; do
      if command -v "$cand" >/dev/null 2>&1; then PYTHON="$(command -v "$cand")"; break; fi
    done
    [ -n "$PYTHON" ] || die "Python 3 installation failed."
  fi
  PY_VER="$("$PYTHON" -c 'import sys;print("%d.%d"%sys.version_info[:2])')"
  PY_OK="$("$PYTHON" -c 'import sys;print(1 if sys.version_info[:2] >= (3,9) else 0)')"
  [ "$PY_OK" = "1" ] || die "Python ${PY_VER} is too old; 3.9 or newer is required."
  ok "Python ${PY_VER} at ${PYTHON}"

  if ! "$PYTHON" -c 'import venv' >/dev/null 2>&1; then
    warn "The venv module is missing — installing it."
    case "$PKG_MGR" in
      apt) pkg_install python3-venv ;;
      apk) pkg_install python3 ;;
      *)   : ;;
    esac
  fi

  # helpful (not strictly required) extras, installed only when missing
  local need=()
  command -v ss >/dev/null 2>&1 || need+=(iproute2)
  command -v curl >/dev/null 2>&1 || need+=(curl)
  if [ ${#need[@]} -gt 0 ] && [ -n "$PKG_MGR" ] && { [ "$AS_ROOT" -eq 1 ] || [ -n "$SUDO" ]; }; then
    info "Installing optional tools: ${need[*]}"
    if ! pkg_install "${need[@]}" >/tmp/prime-pkg.log 2>&1; then
      warn "Could not install optional packages (see /tmp/prime-pkg.log). The panel still works."
    else
      ok "Optional tools installed"
    fi
  fi
}

install_python_deps() {
  step "Installing application dependencies..."
  VENV_DIR="${INSTALL_DIR}/.venv"
  USE_SYSTEM_PY=0

  if [ -d "$VENV_DIR" ] && [ -x "$VENV_DIR/bin/python" ]; then
    if "$VENV_DIR/bin/python" -c "import fastapi, uvicorn, websockets" >/dev/null 2>&1; then
      ok "Python dependencies already present in ${VENV_DIR} — skipping reinstall."
      PY="$VENV_DIR/bin/python"
      return 0
    fi
    info "Existing virtual environment is incomplete; repairing."
  fi

  info "Creating virtual environment at ${VENV_DIR}"
  rm -rf "$VENV_DIR"
  if ! "$PYTHON" -m venv --system-site-packages "$VENV_DIR" >/tmp/prime-venv.log 2>&1; then
    warn "venv creation failed ($(tail -1 /tmp/prime-venv.log 2>/dev/null)); falling back to the system interpreter."
    USE_SYSTEM_PY=1
  fi

  if [ "$USE_SYSTEM_PY" -eq 0 ]; then
    PY="$VENV_DIR/bin/python"
    info "Installing: ${REQUIREMENTS[*]}"
    if ! "$PY" -m pip install --quiet --upgrade pip >>/tmp/prime-pip.log 2>&1; then
      warn "pip self-upgrade failed; continuing."
    fi
    if ! "$PY" -m pip install --quiet --upgrade "${REQUIREMENTS[@]}" >>/tmp/prime-pip.log 2>&1; then
      fail "pip install failed. Last lines of /tmp/prime-pip.log:"
      tail -n 12 /tmp/prime-pip.log | sed 's/^/      /' >&2
      warn "Retrying with the system interpreter…"
      PY="$PYTHON"
      USE_SYSTEM_PY=1
    fi
  fi

  if [ "$USE_SYSTEM_PY" -eq 1 ]; then
    if "$PYTHON" -c "import fastapi, uvicorn, websockets" >/dev/null 2>&1; then
      ok "Required modules already importable from the system interpreter."
      PY="$PYTHON"
    else
      info "Installing dependencies for the current user (--user)…"
      if ! "$PYTHON" -m pip install --user --upgrade "${REQUIREMENTS[@]}" >/tmp/prime-pip-user.log 2>&1; then
        fail "Could not install Python dependencies."
        tail -n 12 /tmp/prime-pip-user.log | sed 's/^/      /' >&2
        die "Install python3-venv/python3-pip and re-run, or install fastapi, uvicorn and websockets manually."
      fi
      ok "Dependencies installed with pip --user"
      PY="$PYTHON"
    fi
  fi

  "$PY" -c "import fastapi, uvicorn, websockets" >/dev/null 2>&1 \
    || die "Dependency verification failed: fastapi/uvicorn/websockets are not importable."
  ok "Dependencies verified: $("$PY" -c 'import fastapi,uvicorn;print("fastapi",fastapi.__version__,"uvicorn",uvicorn.__version__)')"
}

# --------------------------------------------------------------- sources ----
fetch_sources() {
  step "Installing application files..."
  mkdir -p "$INSTALL_DIR" || die "Cannot create ${INSTALL_DIR}"

  if [ -f "${SCRIPT_DIR}/prime/app.py" ]; then
    info "Copying application source from ${SCRIPT_DIR}"
    local items=(prime run.py requirements.txt README.md docs tests panel.sh)
    for item in "${items[@]}"; do
      [ -e "${SCRIPT_DIR}/${item}" ] || continue
      rm -rf "${INSTALL_DIR:?}/${item}"
      cp -a "${SCRIPT_DIR}/${item}" "$INSTALL_DIR/" || die "Failed to copy ${item}"
    done
  elif [ -n "${PRIME_SOURCE_URL:-}" ]; then
    info "Downloading application source from ${PRIME_SOURCE_URL}"
    local tmp; tmp="$(mktemp -d)"
    if ! curl -fsSL "${PRIME_SOURCE_URL}" -o "${tmp}/src.tar.gz"; then
      rm -rf "$tmp"; die "Download failed: ${PRIME_SOURCE_URL}"
    fi
    if ! tar -xzf "${tmp}/src.tar.gz" -C "$tmp"; then
      rm -rf "$tmp"; die "The downloaded archive could not be extracted."
    fi
    local root; root="$(find "$tmp" -maxdepth 2 -name app.py -path '*/prime/*' -printf '%h\n' | head -1)"
    if [ -z "$root" ]; then rm -rf "$tmp"; die "The archive does not contain the PRIME TERMINAL sources."; fi
    rm -rf "${INSTALL_DIR:?}/prime"
    cp -a "${root%/*}/." "$INSTALL_DIR/" || die "Failed to install the downloaded sources."
    rm -rf "$tmp"
  else
    die "Application sources not found next to panel.sh and PRIME_SOURCE_URL is not set."
  fi

  [ -f "${INSTALL_DIR}/prime/app.py" ] || die "Installed sources are incomplete (prime/app.py missing)."
  [ -f "${INSTALL_DIR}/prime/static/index.html" ] || die "Installed frontend is incomplete (index.html missing)."
  ok "Application files in ${INSTALL_DIR}"
}

# ---------------------------------------------------------------- config ----
is_port_free() {
  "$PY" - "$1" <<'EOF' >/dev/null 2>&1
import socket, sys
port = int(sys.argv[1])
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
try:
    s.bind(("0.0.0.0", port))
except OSError:
    sys.exit(1)
finally:
    s.close()
EOF
}

port_in_use_by_panel() {
  [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE" 2>/dev/null)" 2>/dev/null && return 0
  return 1
}

prompt_port() {
  step "Configuring the panel port"
  local default_port="8080" answer
  if [ -n "${PRIME_PORT:-}" ]; then
    PANEL_PORT="$PRIME_PORT"
    info "Using port ${PANEL_PORT} from PRIME_PORT"
    if ! [[ "$PANEL_PORT" =~ ^[0-9]+$ ]] || [ "$PANEL_PORT" -lt 1 ] || [ "$PANEL_PORT" -gt 65535 ]; then
      die "PRIME_PORT='${PANEL_PORT}' is not a valid port (1-65535)."
    fi
  elif [ -f "$CONFIG_FILE" ] && [ -z "${FRESH_INSTALL:-}" ]; then
    local existing
    existing="$("$PY" -c "import json,sys;print(json.load(open(sys.argv[1])).get('port',''))" "$CONFIG_FILE" 2>/dev/null)"
    [ -n "$existing" ] && default_port="$existing"
  fi

  if [ -z "${PANEL_PORT:-}" ]; then
  if [ ! -t 0 ]; then
    PANEL_PORT="$default_port"
    info "Non-interactive shell — using port ${PANEL_PORT}"
  else
    while true; do
      printf '  %sEnter panel port [%s]: %s' "" "$default_port" "" >&2
      read -r answer || answer=""
      answer="${answer:-$default_port}"
      if ! [[ "$answer" =~ ^[0-9]+$ ]]; then warn "Ports are numbers between 1 and 65535."; continue; fi
      if [ "$answer" -lt 1 ] || [ "$answer" -gt 65535 ]; then warn "Port out of range (1-65535)."; continue; fi
      if [ "$answer" -lt 1024 ] && [ "$AS_ROOT" -eq 0 ]; then
        warn "Ports below 1024 require root. Choose another port (e.g. 8080)."; continue
      fi
      if is_port_free "$answer"; then
        PANEL_PORT="$answer"; break
      fi
      if [ -f "$PID_FILE" ] && port_in_use_by_panel; then
        local current
        current="$("$PY" -c "import json,sys;print(json.load(open(sys.argv[1])).get('port',''))" "$CONFIG_FILE" 2>/dev/null)"
        if [ "$current" = "$answer" ]; then
          info "Port ${answer} is used by this panel's own running service — that is fine, it will restart."
          PANEL_PORT="$answer"; break
        fi
      fi
      warn "Port ${answer} is already in use by another program."
      if command -v ss >/dev/null 2>&1; then
        ss -ltnp 2>/dev/null | grep -E ":${answer}\b" | head -2 | sed 's/^/      /' >&2
      fi
    done
  fi
  fi

  if ! is_port_free "$PANEL_PORT" && ! { [ -f "$PID_FILE" ] && port_in_use_by_panel; }; then
    fail "Port ${PANEL_PORT} is already in use by another program."
    if command -v ss >/dev/null 2>&1; then
      ss -ltnp 2>/dev/null | grep -E ":${PANEL_PORT}\b" | head -2 | sed 's/^/      /' >&2
    fi
    die "Choose a different port (for example 8080) or stop the program using ${PANEL_PORT}."
  fi
  ok "Port ${PANEL_PORT} is available"
}

detect_host_ip() {
  local ip=""
  ip="$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src") {print $(i+1); exit}}')"
  if [ -z "$ip" ] && command -v hostname >/dev/null 2>&1; then
    ip="$(hostname -I 2>/dev/null | awk '{print $1}')"
  fi
  if [ -z "$ip" ]; then
    ip="$("$PY" - <<'EOF'
import socket
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
try:
    s.connect(("1.1.1.1", 80))
    print(s.getsockname()[0])
except OSError:
    print("127.0.0.1")
finally:
    s.close()
EOF
)"
  fi
  [ -z "$ip" ] && ip="127.0.0.1"
  printf '%s' "$ip"
}

write_config() {
  step "Writing configuration"
  mkdir -p "$DATA_DIR" || die "Cannot create data directory ${DATA_DIR}"
  local files_roots="[\"/\"]"
  if [ "$AS_ROOT" -eq 0 ]; then
    files_roots="[\"/\", \"${HOME}\"]"
  fi
  "$PY" - "$CONFIG_FILE" "$PANEL_PORT" "$DATA_DIR" "$files_roots" "$SEMI_PRIV" <<'EOF' || die "Could not write the configuration file."
import json, os, sys
path, port, data_dir, roots, semi = sys.argv[1:6]
cfg = {}
if os.path.isfile(path):
    try:
        with open(path) as fh:
            cfg = json.load(fh)
    except (OSError, ValueError):
        cfg = {}
cfg.update({
    "host": "0.0.0.0",
    "port": int(port),
    "data_dir": data_dir,
    "db_path": os.path.join(data_dir, "panel.db"),
    "log_path": os.path.join(data_dir, "panel.log"),
    "allowed_roots": json.loads(roots),
    "behind_proxy": bool(cfg.get("behind_proxy", False)),
    "secure_cookies": bool(cfg.get("secure_cookies", False)),
})
if semi == "1" and "read_only_files" not in cfg:
    cfg["read_only_files"] = False
tmp = path + ".tmp"
with open(tmp, "w") as fh:
    json.dump(cfg, fh, indent=2)
    fh.write("\n")
os.chmod(tmp, 0o600)
os.replace(tmp, path)
EOF
  ok "Configuration written to ${CONFIG_FILE}"
}

create_account() {
  step "Configuring secure access"
  local users
  users="$(PRIME_DATA_DIR="$DATA_DIR" PRIME_CONFIG="$CONFIG_FILE" "$PY" -m prime.cli info 2>/dev/null \
            | "$PY" -c 'import json,sys;print(json.load(sys.stdin)["users"])' 2>/dev/null || echo 0)"
  if [ "${users:-0}" != "0" ]; then
    ok "An administrator account already exists — keeping the existing credentials."
    return 0
  fi

  local username="${PRIME_USERNAME:-admin}"
  local password="${PRIME_ADMIN_PASSWORD:-}"
  local generated=0

  if [ -z "$password" ] && [ -t 0 ]; then
    printf '  Administrator username [%s]: ' "$username" >&2
    read -r input_user || input_user=""
    [ -n "${input_user:-}" ] && username="$input_user"
    say ""
    say "  ${C_DIM}Set a password for '${username}' (min 10 chars, letters and digits).${C_RESET}"
    say "  ${C_DIM}Press Enter to let the installer generate a strong one.${C_RESET}"
    local p1 p2
    printf '  Password: ' >&2; read -rs p1 || p1=""; say ""
    if [ -n "${p1:-}" ]; then
      printf '  Repeat password: ' >&2; read -rs p2 || p2=""; say ""
      if [ "$p1" != "$p2" ]; then die "The passwords do not match."; fi
      password="$p1"
    fi
  fi

  if [ -z "$password" ]; then
    password="$("$PY" - <<'EOF'
import secrets, string
alphabet = string.ascii_letters + string.digits + "!@#%^*-_=+"
while True:
    pw = "".join(secrets.choice(alphabet) for _ in range(20))
    if any(c.islower() for c in pw) and any(c.isupper() for c in pw) and any(c.isdigit() for c in pw):
        print(pw)
        break
EOF
)"
    generated=1
  fi

  if ! printf '%s' "$password" | PRIME_DATA_DIR="$DATA_DIR" PRIME_CONFIG="$CONFIG_FILE" \
       "$PY" -m prime.cli create-user --username "$username" >/tmp/prime-user.log 2>&1; then
    fail "Could not create the administrator account:"
    sed 's/^/      /' /tmp/prime-user.log >&2
    die "Account creation failed."
  fi
  # never leave the password in a log
  rm -f /tmp/prime-user.log
  ok "Administrator account '${username}' created"
  if [ "$generated" -eq 1 ]; then
    say ""
    say "${C_YELLOW}${C_BOLD}  ┌──────────────────────────────────────────────┐${C_RESET}"
    say "${C_YELLOW}${C_BOLD}  │  SAVE THESE CREDENTIALS — SHOWN ONLY ONCE    │${C_RESET}"
    say "${C_YELLOW}${C_BOLD}  └──────────────────────────────────────────────┘${C_RESET}"
    say "     Username: ${C_BOLD}${username}${C_RESET}"
    say "     Password: ${C_BOLD}${password}${C_RESET}"
    say "     ${C_DIM}Change it after signing in (Settings → Change password).${C_RESET}"
    say "     ${C_DIM}Reset later with: bash panel.sh reset-password${C_RESET}"
    say ""
  fi
}

# --------------------------------------------------------- service layer ----
write_systemd_unit() {
  local unit_path="/etc/systemd/system/${APP_SLUG}.service"
  local exec_start="${INSTALL_DIR}/.venv/bin/python -m uvicorn --factory prime.app:create_app --host ${PANEL_HOST} --port ${PANEL_PORT} --log-level warning"
  [ -x "${INSTALL_DIR}/.venv/bin/python" ] || exec_start="${PY} -m uvicorn --factory prime.app:create_app --host ${PANEL_HOST} --port ${PANEL_PORT} --log-level warning"
  local run_user="${RUN_USER}"
  as_root tee "$unit_path" >/dev/null <<EOF || return 1
[Unit]
Description=${APP_NAME} — Linux control panel
Documentation=file://${INSTALL_DIR}/README.md
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${run_user}
Group=$(id -gn "$run_user" 2>/dev/null || echo "$run_user")
WorkingDirectory=${INSTALL_DIR}
Environment=PRIME_CONFIG=${CONFIG_FILE}
Environment=PRIME_DATA_DIR=${DATA_DIR}
Environment=PRIME_HOST=${PANEL_HOST}
Environment=PRIME_PORT=${PANEL_PORT}
Environment=PYTHONUNBUFFERED=1
ExecStart=${exec_start}
Restart=on-failure
RestartSec=3
KillSignal=SIGTERM
TimeoutStopSec=15
# hardening (the panel needs its data dir and the filesystem it manages)
NoNewPrivileges=false
ProtectHome=false
ProtectSystem=false
PrivateTmp=false

[Install]
WantedBy=multi-user.target
EOF
  as_root systemctl daemon-reload >/dev/null 2>&1
  return 0
}

write_user_unit() {
  local unit_dir="${HOME}/.config/systemd/user"
  mkdir -p "$unit_dir" || return 1
  local exec_start="${INSTALL_DIR}/.venv/bin/python -m uvicorn --factory prime.app:create_app --host ${PANEL_HOST} --port ${PANEL_PORT} --log-level warning"
  [ -x "${INSTALL_DIR}/.venv/bin/python" ] || exec_start="${PY} -m uvicorn --factory prime.app:create_app --host ${PANEL_HOST} --port ${PANEL_PORT} --log-level warning"
  cat > "${unit_dir}/${APP_SLUG}.service" <<EOF
[Unit]
Description=${APP_NAME} — Linux control panel (user service)
After=network-online.target

[Service]
Type=simple
WorkingDirectory=${INSTALL_DIR}
Environment=PRIME_CONFIG=${CONFIG_FILE}
Environment=PRIME_DATA_DIR=${DATA_DIR}
Environment=PRIME_HOST=${PANEL_HOST}
Environment=PRIME_PORT=${PANEL_PORT}
Environment=PYTHONUNBUFFERED=1
ExecStart=${exec_start}
Restart=on-failure
RestartSec=3

[Install]
WantedBy=default.target
EOF
  systemctl --user daemon-reload >/dev/null 2>&1
  return 0
}

choose_backend() {
  if [ -n "${PRIME_BACKEND:-}" ]; then
    BACKEND="$PRIME_BACKEND"
    info "Service backend forced to ${BACKEND}"
    return 0
  fi
  if [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1; then
    if [ "$AS_ROOT" -eq 1 ]; then
      BACKEND="systemd"
    elif systemctl --user show-environment >/dev/null 2>&1; then
      BACKEND="systemd-user"
    else
      BACKEND="nohup"
    fi
  elif [ -d /run/openrc ] && command -v rc-service >/dev/null 2>&1; then
    BACKEND="openrc"
  else
    BACKEND="nohup"
  fi
  case "$BACKEND" in
    systemd)      ok "Service manager: systemd (system unit)" ;;
    systemd-user) ok "Service manager: systemd (user unit)" ;;
    openrc)       ok "Service manager: OpenRC" ;;
    nohup)        warn "No systemd/OpenRC available — using a background process with a PID file." ;;
  esac
}

write_nohup_launcher() {
  local runner="${INSTALL_DIR}/panel-run.sh"
  local py="${INSTALL_DIR}/.venv/bin/python"
  [ -x "$py" ] || py="$PY"
  cat > "$runner" <<EOF
#!/usr/bin/env bash
# generated by panel.sh — starts the panel in the background
set -uo pipefail
export PRIME_CONFIG="${CONFIG_FILE}"
export PRIME_DATA_DIR="${DATA_DIR}"
export PRIME_HOST="${PANEL_HOST}"
export PRIME_PORT="${PANEL_PORT}"
export PYTHONUNBUFFERED=1
cd "${INSTALL_DIR}" || exit 1
exec "${py}" -m uvicorn --factory prime.app:create_app \\
  --host "${PANEL_HOST}" --port "${PANEL_PORT}" --log-level warning
EOF
  chmod +x "$runner"
  printf '%s' "$runner"
}

start_service() {
  step "Starting terminal service..."
  local tries=0
  case "$BACKEND" in
    systemd)
      as_root systemctl enable "${APP_SLUG}.service" >/dev/null 2>&1 || warn "Could not enable the unit at boot."
      as_root systemctl restart "${APP_SLUG}.service" || die "systemctl could not start the service."
      ;;
    systemd-user)
      systemctl --user enable "${APP_SLUG}.service" >/dev/null 2>&1 || warn "Could not enable the user unit."
      systemctl --user restart "${APP_SLUG}.service" || die "systemctl --user could not start the service."
      ;;
    openrc)
      as_root rc-service "$APP_SLUG" restart >/dev/null 2>&1 || warn "OpenRC service not registered; using the background launcher."
      BACKEND="nohup"
      start_nohup
      ;;
    *) start_nohup ;;
  esac
  echo "$BACKEND" > "$DATA_DIR/backend" 2>/dev/null || true

  # ---- do not report success until the HTTP endpoint answers ----------
  say ""
  printf '  Waiting for the panel to answer on port %s' "$PANEL_PORT"
  while [ "$tries" -lt 40 ]; do
    if "$PY" - "$PANEL_PORT" <<'EOF' >/dev/null 2>&1
import json, sys, urllib.request
port = sys.argv[1]
with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=2) as r:
    data = json.load(r)
print(data)
sys.exit(0 if data.get("ok") else 1)
EOF
    then
      say ""
      ok "Panel is serving HTTP on port ${PANEL_PORT}"
      return 0
    fi
    tries=$((tries + 1))
    printf '.'
    sleep 1
  done
  say ""
  fail "The panel did not answer on port ${PANEL_PORT} within 40 seconds."
  show_startup_logs
  die "Startup failed — see the log above. Nothing has been reported as successful."
}

start_nohup() {
  local runner; runner="$(write_nohup_launcher)"
  mkdir -p "$DATA_DIR"
  if [ -f "$PID_FILE" ]; then
    local old; old="$(cat "$PID_FILE" 2>/dev/null)"
    if [ -n "$old" ] && kill -0 "$old" 2>/dev/null; then
      info "Stopping the previous process (pid ${old})"
      kill "$old" 2>/dev/null
      for _ in $(seq 1 20); do kill -0 "$old" 2>/dev/null || break; sleep 0.3; done
      kill -9 "$old" 2>/dev/null || true
    fi
    rm -f "$PID_FILE"
  fi
  nohup "$runner" >> "${DATA_DIR}/service.log" 2>&1 &
  local pid=$!
  echo "$pid" > "$PID_FILE"
  sleep 1
  if ! kill -0 "$pid" 2>/dev/null; then
    fail "The panel process exited immediately."
    show_startup_logs
    die "Startup failed."
  fi
  ok "Started background process (pid ${pid})"
}

show_startup_logs() {
  say "${C_DIM}  --- last log lines -------------------------------------------${C_RESET}"
  case "$BACKEND" in
    systemd)      as_root journalctl -u "${APP_SLUG}.service" -n 25 --no-pager 2>/dev/null | sed 's/^/  /' ;;
    systemd-user) systemctl --user status "${APP_SLUG}.service" -n 25 --no-pager 2>/dev/null | sed 's/^/  /' ;;
    *)            tail -n 25 "${DATA_DIR}/service.log" 2>/dev/null | sed 's/^/  /'
                  tail -n 15 "${DATA_DIR}/panel.log" 2>/dev/null | sed 's/^/  /' ;;
  esac
  say "${C_DIM}  --------------------------------------------------------------${C_RESET}"
}

stop_service() {
  local backend="${BACKEND:-}"
  [ -z "$backend" ] && backend="$(cat "$DATA_DIR/backend" 2>/dev/null || echo nohup)"
  case "$backend" in
    systemd)
      as_root systemctl stop "${APP_SLUG}.service" 2>/dev/null && ok "systemd service stopped." \
        || info "Service was not running." ;;
    systemd-user)
      systemctl --user stop "${APP_SLUG}.service" 2>/dev/null && ok "user service stopped." \
        || info "Service was not running." ;;
    *)
      if [ -f "$PID_FILE" ]; then
        local pid; pid="$(cat "$PID_FILE" 2>/dev/null)"
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
          kill "$pid" 2>/dev/null
          for _ in $(seq 1 25); do kill -0 "$pid" 2>/dev/null || break; sleep 0.3; done
          kill -9 "$pid" 2>/dev/null || true
          ok "Stopped process ${pid}."
        else
          info "No running process found for the recorded PID."
        fi
        rm -f "$PID_FILE"
      else
        info "No PID file — the panel is not running under the launcher."
      fi ;;
  esac
}

is_running() {
  local backend="${BACKEND:-}"
  [ -z "$backend" ] && backend="$(cat "$DATA_DIR/backend" 2>/dev/null || echo nohup)"
  case "$backend" in
    systemd)      as_root systemctl is-active --quiet "${APP_SLUG}.service" ;;
    systemd-user) systemctl --user is-active --quiet "${APP_SLUG}.service" ;;
    *)            [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE" 2>/dev/null)" 2>/dev/null ;;
  esac
}

# ------------------------------------------------------------ install run ---
do_install() {
  banner
  detect_os
  detect_pm
  check_privileges
  ensure_python

  # layout
  if [ "$AS_ROOT" -eq 1 ]; then
    INSTALL_DIR="${PRIME_INSTALL_DIR:-/opt/${APP_SLUG}}"
    DATA_DIR="${PRIME_DATA_DIR:-/var/lib/${APP_SLUG}}"
    RUN_USER="${PRIME_RUN_USER:-$(id -un)}"
    SEMI_PRIV=0
  else
    INSTALL_DIR="${PRIME_INSTALL_DIR:-${HOME}/.local/opt/${APP_SLUG}}"
    DATA_DIR="${PRIME_DATA_DIR:-${HOME}/.local/share/${APP_SLUG}}"
    RUN_USER="$(id -un)"
    SEMI_PRIV=1
  fi
  CONFIG_FILE="${DATA_DIR}/config.json"
  PID_FILE="${DATA_DIR}/panel.pid"
  PANEL_HOST="0.0.0.0"
  [ -f "$CONFIG_FILE" ] || FRESH_INSTALL=1
  step "Installation layout"
  info "Install directory: ${INSTALL_DIR}"
  info "Data directory:    ${DATA_DIR}"
  info "Configuration:     ${CONFIG_FILE}"

  install_python_deps
  fetch_sources
  prompt_port
  write_config
  create_account
  choose_backend
  start_service

  PANEL_IP="$(detect_host_ip)"
  save_summary "$PANEL_IP"
  print_summary "$PANEL_IP"
}

save_summary() {
  local ip="$1"
  {
    echo "install_dir=${INSTALL_DIR}"
    echo "data_dir=${DATA_DIR}"
    echo "config=${CONFIG_FILE}"
    echo "port=${PANEL_PORT}"
    echo "host=${PANEL_HOST}"
    echo "backend=${BACKEND}"
    echo "user=${RUN_USER}"
    echo "installed_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    echo "version=${APP_VERSION}"
  } > "${DATA_DIR}/install.env" 2>/dev/null || true
  chmod 600 "${DATA_DIR}/install.env" 2>/dev/null || true
}

print_summary() {
  local ip="$1"
  say ""
  say "${C_GREEN}${C_BOLD}========================================${C_RESET}"
  say "${C_BOLD}       INSTALLATION COMPLETE${C_RESET}"
  say "${C_GREEN}${C_BOLD}========================================${C_RESET}"
  say ""
  say "  Panel URL: ${C_BOLD}http://${ip}:${PANEL_PORT}${C_RESET}"
  if [ "$ip" != "127.0.0.1" ]; then
    say "  Local URL: http://127.0.0.1:${PANEL_PORT}"
  fi
  say "  Status:    ${C_GREEN}RUNNING${C_RESET}"
  say "  Service:   ${BACKEND}"
  say "  User:      ${RUN_USER}"
  say "  Install:   ${INSTALL_DIR}"
  say "  Data:      ${DATA_DIR}"
  say ""
  if [ "${WARNINGS:-0}" -gt 0 ]; then
    say "  ${C_YELLOW}${WARNINGS} warning(s) were reported above — read them before relying on the panel.${C_RESET}"
    say ""
  fi
  say "  ${C_BOLD}Management${C_RESET}"
  say "    bash panel.sh status"
  say "    bash panel.sh restart"
  say "    bash panel.sh logs"
  say "    bash panel.sh reset-password"
  say "    bash panel.sh update"
  say "    bash panel.sh uninstall"
  say ""
  say "  ${C_DIM}The panel is running as a background service, so it keeps running"
  say "  after this shell exits. Open the URL above and sign in.${C_RESET}"
  say ""
  say "  ${C_YELLOW}Security: this is plain HTTP. Put the panel behind a TLS reverse"
  say "  proxy before exposing it to the internet — see docs/HTTPS.md.${C_RESET}"
  say ""
}

# ------------------------------------------------------------- commands -----
load_layout() {
  if [ -f "${PRIME_DATA_DIR:-/var/lib/${APP_SLUG}}/install.env" ]; then
    DATA_DIR="$PRIME_DATA_DIR"
  fi
  # discover the layout from the first install.env we can find
  local candidates=("/var/lib/${APP_SLUG}/install.env" "${HOME}/.local/share/${APP_SLUG}/install.env")
  if [ -n "${PRIME_DATA_DIR:-}" ]; then candidates=("${PRIME_DATA_DIR}/install.env" "${candidates[@]}"); fi
  local found=""
  for c in "${candidates[@]}"; do
    if [ -f "$c" ]; then found="$c"; break; fi
  done
  if [ -z "$found" ]; then
    fail "PRIME TERMINAL does not look installed (no install.env found)."
    say "  Run: bash panel.sh"
    exit 1
  fi
  # shellcheck disable=SC1090
  . "$found"
  CONFIG_FILE="${config}"; PID_FILE="${data_dir}/panel.pid"
  BACKEND="${backend:-nohup}"; PANEL_PORT="${port}"
  PANEL_HOST="${host:-0.0.0.0}"; RUN_USER="${user:-$(id -un)}"
  DATA_DIR="${data_dir}"; INSTALL_DIR="${install_dir}"
  PY="$( [ -x "${INSTALL_DIR}/.venv/bin/python" ] && echo "${INSTALL_DIR}/.venv/bin/python" || echo "$(command -v python3)" )"
  AS_ROOT=0; [ "$(id -u)" -eq 0 ] && AS_ROOT=1
  if [ "$AS_ROOT" -eq 1 ]; then SUDO=""; elif command -v sudo >/dev/null 2>&1; then SUDO="sudo"; fi
}

cmd_start() {
  load_layout
  if is_running; then ok "PRIME TERMINAL is already running."; return 0; fi
  start_service
  ok "Started."
}

cmd_stop() {
  load_layout
  stop_service
}

cmd_restart() {
  load_layout
  stop_service
  sleep 1
  start_service
  ok "Restarted."
}

cmd_status() {
  load_layout
  local ip; ip="$(detect_host_ip 2>/dev/null || echo 127.0.0.1)"
  local running="stopped" colour="$C_RED"
  if is_running; then running="running"; colour="$C_GREEN"; fi
  local health=""
  if health="$(curl -fsS --max-time 3 "http://127.0.0.1:${PANEL_PORT}/api/health" 2>/dev/null)"; then
    :
  else
    health=""
  fi
  say ""
  say "${C_BOLD}${APP_NAME} ${APP_VERSION}${C_RESET}"
  say "  Status:   ${colour}${running}${C_RESET}"
  say "  Backend:  ${BACKEND}"
  say "  URL:      http://${ip}:${PANEL_PORT}"
  say "  Port:     ${PANEL_PORT} (host ${PANEL_HOST})"
  say "  Install:  ${INSTALL_DIR}"
  say "  Data:     ${DATA_DIR}"
  say "  User:     ${RUN_USER}"
  if [ -n "$health" ]; then
    say "  Health:   ${C_GREEN}${health}${C_RESET}"
  else
    say "  Health:   ${C_YELLOW}no HTTP response${C_RESET}"
  fi
  say ""
}

cmd_logs() {
  load_layout
  case "$BACKEND" in
    systemd)      as_root journalctl -u "${APP_SLUG}.service" -n 200 --no-pager ;;
    systemd-user) journalctl --user -u "${APP_SLUG}.service" -n 200 --no-pager ;;
    *)            say "${C_DIM}== service.log ==${C_RESET}"
                  tail -n 100 "${DATA_DIR}/service.log" 2>/dev/null
                  say "${C_DIM}== panel.log ==${C_RESET}"
                  tail -n 100 "${DATA_DIR}/panel.log" 2>/dev/null ;;
  esac
}

cmd_reset_password() {
  load_layout
  ensure_python >/dev/null 2>&1 || true
  PY="$( [ -x "${INSTALL_DIR}/.venv/bin/python" ] && echo "${INSTALL_DIR}/.venv/bin/python" || command -v python3 )"
  local user="${1:-admin}"
  say "Resetting the password for '${user}'."
  if ! PRIME_DATA_DIR="$DATA_DIR" PRIME_CONFIG="$CONFIG_FILE" "$PY" -m prime.cli reset-password --username "$user"; then
    die "Password reset failed. Use --user <name> or create a user with 'bash panel.sh add-user <name>'."
  fi
  ok "Done. All existing sessions for that user are invalidated."
}

cmd_add_user() {
  load_layout
  PY="$( [ -x "${INSTALL_DIR}/.venv/bin/python" ] && echo "${INSTALL_DIR}/.venv/bin/python" || command -v python3 )"
  local user="${1:-admin}"
  PRIME_DATA_DIR="$DATA_DIR" PRIME_CONFIG="$CONFIG_FILE" "$PY" -m prime.cli create-user --username "$user" \
    || die "Could not create the user."
}

cmd_config() {
  load_layout
  local editor="${EDITOR:-}"
  if [ -n "$editor" ] && [ -t 0 ]; then
    "$editor" "$CONFIG_FILE"
  else
    say "${C_DIM}# ${CONFIG_FILE}${C_RESET}"
    cat "$CONFIG_FILE"
  fi
  say ""
  say "${C_DIM}Restart the panel for changes to apply: bash panel.sh restart${C_RESET}"
}

cmd_update() {
  load_layout
  banner
  say "${C_BOLD}Updating PRIME TERMINAL${C_RESET}"
  # keep the data directory untouched; only application files are replaced
  local backup; backup="$(mktemp -d)"
  cp -a "${INSTALL_DIR}/prime" "${backup}/prime" 2>/dev/null || true
  PYTHON="$( [ -x "${INSTALL_DIR}/.venv/bin/python" ] && echo "${INSTALL_DIR}/.venv/bin/python" || command -v python3 )"
  AS_ROOT=0; [ "$(id -u)" -eq 0 ] && AS_ROOT=1
  if [ "$AS_ROOT" -eq 0 ] && command -v sudo >/dev/null 2>&1; then SUDO="sudo"; fi

  RUN_USER="${RUN_USER:-$(id -un)}"
  SEMI_PRIV=0; [ "$AS_ROOT" -eq 0 ] && SEMI_PRIV=1

  install_python_deps || { warn "Dependency refresh failed; restoring the previous files."; rm -rf "${INSTALL_DIR:?}/prime"; cp -a "${backup}/prime" "${INSTALL_DIR}/prime"; die "Update aborted."; }
  PY="$PYTHON"
  fetch_sources || { rm -rf "${INSTALL_DIR:?}/prime"; cp -a "${backup}/prime" "${INSTALL_DIR}/prime"; die "Update aborted."; }
  rm -rf "$backup"

  # re-generate the service definition (paths/unit may have changed)
  if [ "$BACKEND" = "systemd" ]; then write_systemd_unit; fi
  if [ "$BACKEND" = "systemd-user" ]; then write_user_unit; fi
  if [ "$BACKEND" = "nohup" ]; then write_nohup_launcher >/dev/null; fi

  stop_service
  sleep 1
  start_service
  ok "Update complete — user data in ${DATA_DIR} was not modified."
}

cmd_uninstall() {
  load_layout
  banner
  say "${C_BOLD}Uninstalling PRIME TERMINAL${C_RESET}"
  say "  Install: ${INSTALL_DIR}"
  say "  Data:    ${DATA_DIR} (database, config, logs)"
  local answer=""
  if [ -t 0 ] && [ -z "${PRIME_FORCE:-}" ]; then
    printf '  Really remove the panel? [y/N]: ' >&2; read -r answer || answer=""
    case "$answer" in y|Y|yes|YES) ;; *) say "  Cancelled."; exit 0 ;; esac
  fi

  stop_service
  case "$BACKEND" in
    systemd)
      as_root systemctl disable "${APP_SLUG}.service" >/dev/null 2>&1 || true
      as_root rm -f "/etc/systemd/system/${APP_SLUG}.service"
      as_root systemctl daemon-reload >/dev/null 2>&1 || true ;;
    systemd-user)
      systemctl --user disable "${APP_SLUG}.service" >/dev/null 2>&1 || true
      rm -f "${HOME}/.config/systemd/user/${APP_SLUG}.service"
      systemctl --user daemon-reload >/dev/null 2>&1 || true ;;
  esac

  local keep_data="n"
  if [ -t 0 ] && [ -z "${PRIME_FORCE:-}" ]; then
    printf '  Keep the data directory (accounts, config, logs)? [Y/n]: ' >&2
    read -r keep_data || keep_data="y"
    keep_data="${keep_data:-y}"
  else
    keep_data="${PRIME_KEEP_DATA:-y}"
  fi

  rm -rf "${INSTALL_DIR:?}" && ok "Removed ${INSTALL_DIR}" || warn "Could not remove ${INSTALL_DIR}"
  case "$keep_data" in
    n|N|no|NO)
      rm -rf "${DATA_DIR:?}" && ok "Removed ${DATA_DIR}" || warn "Could not remove ${DATA_DIR}" ;;
    *)
      ok "Kept ${DATA_DIR} (delete it manually if you want a clean slate)" ;;
  esac
  say ""
  say "${C_GREEN}PRIME TERMINAL has been removed.${C_RESET}"
}

usage() {
  cat <<EOF
${C_BOLD}${APP_NAME} ${APP_VERSION}${C_RESET}

  bash panel.sh                 install or repair this panel
  bash panel.sh start           start the service
  bash panel.sh stop            stop the service
  bash panel.sh restart         restart the service
  bash panel.sh status          show status and health
  bash panel.sh logs            show recent service logs
  bash panel.sh update          re-install application files, keep data
  bash panel.sh uninstall       remove the panel
  bash panel.sh reset-password [user]   reset an account password
  bash panel.sh add-user [user]         create another account
  bash panel.sh config          show the configuration file

Environment overrides:
  PRIME_PORT, PRIME_INSALL_DIR/PRIME_INSTALL_DIR, PRIME_DATA_DIR,
  PRIME_USERNAME, PRIME_ADMIN_PASSWORD, PRIME_BACKEND,
  PRIME_SOURCE_URL, PRIME_FORCE=1, PRIME_KEEP_DATA=n
EOF
}

# --------------------------------------------------------------- dispatch ---
main() {
  local cmd="${1:-install}"
  case "$cmd" in
    install|setup|"") do_install ;;
    start)            cmd_start ;;
    stop)             cmd_stop ;;
    restart)          cmd_restart ;;
    status)           cmd_status ;;
    logs)             cmd_logs ;;
    update)           cmd_update ;;
    uninstall|remove) cmd_uninstall ;;
    reset-password)   shift; cmd_reset_password "${1:-admin}" ;;
    add-user)         shift; cmd_add_user "${1:-admin}" ;;
    config)           cmd_config ;;
    -h|--help|help)   usage ;;
    *)                fail "Unknown command: ${cmd}"; say ""; usage; exit 2 ;;
  esac
}

main "$@"
