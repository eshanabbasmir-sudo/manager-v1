"""FastAPI application factory, middleware and static file serving."""
from __future__ import annotations

import asyncio
import logging
import os
import time
from contextlib import asynccontextmanager
from logging.handlers import RotatingFileHandler

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles

from . import APP_NAME, __version__, sysinfo
from .config import Config
from .deps import Runtime
from .routes import auth_routes, file_routes, ops_routes, system_routes, terminal_routes

STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
log = logging.getLogger("prime")


def setup_logging(cfg: Config) -> None:
    level = getattr(logging, str(cfg.log_level).upper(), logging.INFO)
    root = logging.getLogger("prime")
    root.setLevel(level)
    if root.handlers:
        return
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s")
    try:
        os.makedirs(os.path.dirname(cfg.log_path), exist_ok=True)
        fh = RotatingFileHandler(cfg.log_path, maxBytes=2 * 1024 * 1024, backupCount=3)
        fh.setFormatter(fmt)
        root.addHandler(fh)
    except OSError:
        pass
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    root.addHandler(sh)
    root.propagate = False


async def _sampler(rt: Runtime) -> None:
    """Keep the CPU / net / process counters fresh so deltas are meaningful."""
    loop = asyncio.get_running_loop()
    while True:
        try:
            await loop.run_in_executor(None, sysinfo.CPU.sample)
            await loop.run_in_executor(None, sysinfo.NET.sample)
            await loop.run_in_executor(None, lambda: sysinfo.list_processes(limit=40))
            await rt.terms.reap_idle()
            rt.auth.sweep()
            rt.limiter.sweep()
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001 — never let the sampler die
            log.exception("sampler iteration failed")
        await asyncio.sleep(2.0)


def create_app(cfg: Config | None = None) -> FastAPI:
    cfg = cfg or Config.load()
    setup_logging(cfg)
    rt = Runtime(cfg)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        log.info("%s %s starting on %s:%s (data dir %s, euid %s)", APP_NAME, rt.version,
                 cfg.host, cfg.port, cfg.data_dir, os.geteuid())
        task = asyncio.create_task(_sampler(rt))
        try:
            yield
        finally:
            task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass
            await rt.terms.close_all()
            log.info("shutdown complete")

    app = FastAPI(title=APP_NAME, version=__version__, docs_url=None, redoc_url=None,
                  openapi_url=None, lifespan=lifespan)
    app.state.rt = rt
    app.state.cfg = cfg

    # ----------------------------------------------------------- middleware
    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            origin = request.headers.get("origin")
            if origin:
                from urllib.parse import urlsplit
                try:
                    if urlsplit(origin).netloc != request.headers.get("host", ""):
                        return JSONResponse({"detail": "cross-origin request blocked"},
                                            status_code=403)
                except ValueError:
                    return JSONResponse({"detail": "bad origin"}, status_code=403)
        started = time.time()
        try:
            response = await call_next(request)
        except HTTPException:
            raise
        except Exception:  # noqa: BLE001
            log.exception("unhandled error for %s %s", request.method, request.url.path)
            return JSONResponse({"detail": "internal server error"}, status_code=500)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
        response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self' ws: wss:; "
            "frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'")
        if cfg.secure_cookies:
            response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["X-Response-Time"] = f"{(time.time() - started) * 1000:.1f}ms"
        return response

    # --------------------------------------------------------------- routes
    app.include_router(auth_routes.router)
    app.include_router(system_routes.router)
    app.include_router(terminal_routes.router)
    app.include_router(file_routes.router)
    app.include_router(ops_routes.router)

    @app.get("/api/health")
    async def health():
        return {"ok": True, "name": APP_NAME, "version": rt.version,
                "uptime": round(time.time() - rt.started, 1)}

    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

    @app.get("/")
    async def index():
        return FileResponse(os.path.join(STATIC_DIR, "index.html"),
                            headers={"Cache-Control": "no-store"})

    @app.get("/favicon.svg")
    async def favicon():
        return FileResponse(os.path.join(STATIC_DIR, "favicon.svg"),
                            media_type="image/svg+xml")

    @app.get("/manifest.webmanifest")
    async def manifest():
        return FileResponse(os.path.join(STATIC_DIR, "manifest.webmanifest"),
                            media_type="application/manifest+json")

    @app.get("/robots.txt")
    async def robots():
        return Response("User-agent: *\nDisallow: /\n", media_type="text/plain")

    return app


def run() -> None:
    import uvicorn
    cfg = Config.load()
    app = create_app(cfg)
    kwargs = {}
    if cfg.behind_proxy:
        kwargs["proxy_headers"] = True
        kwargs["forwarded_allow_ips"] = ",".join(cfg.trusted_proxies)
    uvicorn.run(app, host=cfg.host, port=cfg.port, log_level=cfg.log_level.lower(),
                access_log=False, timeout_keep_alive=30, **kwargs)
