"""Real system information straight from /proc, /sys and statvfs.

No simulation: if the kernel does not expose a value, the API returns null
plus an explanatory ``note`` instead of inventing numbers.
"""
from __future__ import annotations

import glob
import os
import platform
import pwd
import shutil
import socket
import struct
import subprocess
import time
from typing import Any, Iterable

CLK_TCK = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100
PAGE_SIZE = os.sysconf("SC_PAGE_SIZE") if hasattr(os, "sysconf") else 4096

REAL_FS = {
    "ext2", "ext3", "ext4", "xfs", "btrfs", "zfs", "f2fs", "jfs", "reiserfs",
    "vfat", "exfat", "ntfs", "ntfs3", "fuseblk", "overlay", "aufs", "ecryptfs",
    "nfs", "nfs4", "cifs", "smb3", "tmpfs", "ramfs", "bcachefs", "apfs", "9p",
}
SKIP_FS = {
    "proc", "sysfs", "devtmpfs", "devpts", "cgroup", "cgroup2", "pstore",
    "debugfs", "tracefs", "securityfs", "hugetlbfs", "mqueue", "bpf", "configfs",
    "fusectl", "autofs", "binfmt_misc", "squashfs", "nsfs", "efivarfs",
    "rpc_pipefs", "selinuxfs", "fuse.gvfsd-fuse", "sunrpc",
}


def _read(path: str, default: str = "") -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            return fh.read()
    except OSError:
        return default


def _read_int(path: str, default: int = 0) -> int:
    try:
        return int(_read(path).strip().split()[0])
    except (ValueError, IndexError):
        return default


def _which(name: str) -> str | None:
    return shutil.which(name)


# ---------------------------------------------------------------------------
# Environment / capability detection
# ---------------------------------------------------------------------------
def container_info() -> dict[str, Any]:
    kind = None
    evidence = []
    if os.path.exists("/.dockerenv"):
        kind, evidence = "docker", ["/.dockerenv exists"]
    elif os.path.exists("/run/.containerenv"):
        kind, evidence = "podman", ["/run/.containerenv exists"]
    if kind is None and os.path.exists("/proc/1/cgroup"):
        cg = _read("/proc/1/cgroup")
        for marker, name in (("docker", "docker"), ("kubepods", "kubernetes"),
                             ("lxc", "lxc"), ("containerd", "containerd"),
                             ("podman", "podman"), ("buildkit", "buildkit")):
            if marker in cg:
                kind, evidence = name, [f"/proc/1/cgroup mentions {marker}"]
                break
    if kind is None:
        virt = _read("/proc/1/environ").replace("\x00", " ")  # may be unreadable
        if "container=" in virt:
            kind, evidence = "container", ["/proc/1/environ container="]
    if kind is None:
        sv = _which("systemd-detect-virt")
        if sv:
            try:
                out = subprocess.run([sv, "--container"], capture_output=True, text=True,
                                     timeout=3)
                if out.returncode == 0 and out.stdout.strip() not in ("", "none"):
                    kind, evidence = out.stdout.strip(), ["systemd-detect-virt --container"]
            except (OSError, subprocess.SubprocessError):
                pass
    if kind is None and _read_int("/proc/1/pid", 1) == 1 and _read("/proc/1/comm").strip() in {
            "systemd", "init"}:
        kind = None
    return {"is_container": kind is not None, "kind": kind, "evidence": evidence}


def cgroup_limits() -> dict[str, Any]:
    """Container CPU/memory quotas (v2 first, then v1)."""
    out: dict[str, Any] = {"cpu_quota_cores": None, "memory_limit_bytes": None,
                           "memory_current_bytes": None, "pids_limit": None,
                           "source": None}
    # cgroup v2
    cpu_max = _read("/sys/fs/cgroup/cpu.max").strip()
    if cpu_max and not cpu_max.startswith("max"):
        parts = cpu_max.split()
        if len(parts) == 2 and parts[1].isdigit() and int(parts[1]) > 0:
            out["cpu_quota_cores"] = round(int(parts[0]) / int(parts[1]), 2)
            out["source"] = "cgroup2"
    mem_max = _read("/sys/fs/cgroup/memory.max").strip()
    if mem_max and mem_max.isdigit():
        out["memory_limit_bytes"] = int(mem_max)
        out["source"] = out["source"] or "cgroup2"
    mem_cur = _read("/sys/fs/cgroup/memory.current").strip()
    if mem_cur.isdigit():
        out["memory_current_bytes"] = int(mem_cur)
    pids_max = _read("/sys/fs/cgroup/pids.max").strip()
    if pids_max.isdigit():
        out["pids_limit"] = int(pids_max)

    if out["cpu_quota_cores"] is None:
        quota = _read_int("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", -1)
        period = _read_int("/sys/fs/cgroup/cpu/cpu.cfs_period_us", 100000)
        if quota and quota > 0 and period > 0:
            out["cpu_quota_cores"] = round(quota / period, 2)
            out["source"] = "cgroup1"
    if out["memory_limit_bytes"] is None:
        lim = _read_int("/sys/fs/cgroup/memory/memory.limit_in_bytes", 0)
        if lim and lim < (1 << 60):
            out["memory_limit_bytes"] = lim
            out["source"] = out["source"] or "cgroup1"
    return out


def capabilities() -> dict[str, Any]:
    ctr = container_info()
    is_root = os.geteuid() == 0
    systemd_running = os.path.isdir("/run/systemd/system")
    pm = None
    for name, probe in (("apt", "apt-get"), ("dnf", "dnf"), ("yum", "yum"),
                        ("pacman", "pacman"), ("apk", "apk"), ("zypper", "zypper")):
        if _which(probe):
            pm = name
            break
    return {
        "platform": "linux",
        "is_root": is_root,
        "effective_user": pwd.getpwuid(os.geteuid()).pw_name if os.geteuid() is not None else "",
        "container": ctr,
        "systemd": systemd_running,
        "systemd_reason": "" if systemd_running else
            "systemd is not PID 1 in this environment (common inside containers)",
        "package_manager": pm,
        "sudo": _which("sudo") is not None,
        "journalctl": _which("journalctl") is not None,
        "tools": {t: _which(t) is not None for t in
                  ("bash", "ss", "netstat", "ping", "traceroute", "ssh-keygen",
                   "df", "free", "ps", "python3")},
        "has_ptmx": os.path.exists("/dev/ptmx"),
        "cgroup": cgroup_limits(),
    }


# ---------------------------------------------------------------------------
# CPU
# ---------------------------------------------------------------------------
class _CpuSampler:
    def __init__(self) -> None:
        self.prev_total: tuple[int, int] | None = None
        self.prev_cores: list[tuple[int, int]] = []
        self.percent = 0.0
        self.core_percent: list[float] = []
        self.last_sample = 0.0

    def sample(self) -> None:
        lines = _read("/proc/stat").splitlines()
        totals: list[tuple[int, int]] = []
        for line in lines:
            if not line.startswith("cpu"):
                continue
            parts = line.split()
            key = parts[0]
            values = [int(x) for x in parts[1:] if x.isdigit()]
            if len(values) < 4:
                continue
            idle = values[3] + (values[4] if len(values) > 4 else 0)
            total = sum(values)
            totals.append((total, idle))
        if not totals:
            return
        total_all, idle_all = totals[0]
        if self.prev_total:
            dt = total_all - self.prev_total[0]
            di = idle_all - self.prev_total[1]
            if dt > 0:
                self.percent = max(0.0, min(100.0, 100.0 * (dt - di) / dt))
        new_cores = []
        if self.prev_cores and len(self.prev_cores) == len(totals) - 1:
            for (t, i), (pt, pi) in zip(totals[1:], self.prev_cores):
                dt, di = t - pt, i - pi
                new_cores.append(max(0.0, min(100.0, 100.0 * (dt - di) / dt)) if dt > 0 else 0.0)
        self.core_percent = new_cores or [round(self.percent, 1)] * (len(totals) - 1)
        self.prev_total = (total_all, idle_all)
        self.prev_cores = totals[1:]
        self.last_sample = time.time()


CPU = _CpuSampler()


def cpu_info() -> dict[str, Any]:
    if time.time() - CPU.last_sample > 1.0:
        CPU.sample()
    model = ""
    for line in _read("/proc/cpuinfo").splitlines():
        if line.lower().startswith("model name"):
            model = line.split(":", 1)[1].strip()
            break
    if not model:
        for line in _read("/proc/cpuinfo").splitlines():
            if line.lower().startswith(("hardware", "processor", "cpu model")):
                model = line.split(":", 1)[1].strip()
                break
    logical = os.cpu_count() or len(CPU.core_percent) or 1
    cg = cgroup_limits()
    return {
        "usage_percent": round(CPU.percent, 1),
        "cores": CPU.core_percent,
        "logical_cores": logical,
        "physical_cores": _physical_cores(),
        "model": model or "unknown",
        "clock_mhz": _cpu_clock(),
        "load": load_average(),
        "quota_cores": cg["cpu_quota_cores"],
        "sampled_at": CPU.last_sample,
    }


def _cpu_clock() -> float | None:
    for line in _read("/proc/cpuinfo").splitlines():
        if line.lower().startswith("cpu mhz"):
            try:
                return round(float(line.split(":", 1)[1].strip()), 0)
            except ValueError:
                return None
    return None


def _physical_cores() -> int:
    ids = set()
    phys = None
    package = "0"
    physical_id_seen = False
    for line in _read("/proc/cpuinfo").splitlines():
        line = line.strip()
        if line.startswith("physical id"):
            package = line.split(":", 1)[1].strip()
            physical_id_seen = True
        elif line.startswith("core id"):
            phys = line.split(":", 1)[1].strip()
        elif not line and phys is not None:
            ids.add((package, phys))
            phys = None
    if not ids:
        return os.cpu_count() or 1
    return len(ids) if physical_id_seen else len(os.cpu_count() and [1] * (os.cpu_count() or 1))


def load_average() -> dict[str, float]:
    parts = _read("/proc/loadavg").split()
    try:
        return {"1m": float(parts[0]), "5m": float(parts[1]), "15m": float(parts[2]),
                "runnable": parts[3]}
    except (ValueError, IndexError):
        return {"1m": 0.0, "5m": 0.0, "15m": 0.0, "runnable": ""}


# ---------------------------------------------------------------------------
# Memory
# ---------------------------------------------------------------------------
def memory_info() -> dict[str, Any]:
    info: dict[str, int] = {}
    for line in _read("/proc/meminfo").splitlines():
        if ":" in line:
            key, val = line.split(":", 1)
            num = val.strip().split()
            if num and num[0].isdigit():
                info[key] = int(num[0]) * 1024
    total = info.get("MemTotal", 0)
    available = info.get("MemAvailable", info.get("MemFree", 0))
    used = max(0, total - available)
    swap_total = info.get("SwapTotal", 0)
    swap_free = info.get("SwapFree", 0)
    cg = cgroup_limits()
    limit = cg["memory_limit_bytes"]
    return {
        "total": total,
        "used": used,
        "available": available,
        "free": info.get("MemFree", 0),
        "buffers": info.get("Buffers", 0),
        "cached": info.get("Cached", 0),
        "shared": info.get("Shmem", 0),
        "percent": round(100 * used / total, 1) if total else 0.0,
        "swap_total": swap_total,
        "swap_used": max(0, swap_total - swap_free),
        "swap_percent": round(100 * (swap_total - swap_free) / swap_total, 1) if swap_total else 0.0,
        "container_limit": limit,
        "container_used": cg["memory_current_bytes"],
        "container_percent": (round(100 * (cg["memory_current_bytes"] or 0) / limit, 1)
                              if limit and cg["memory_current_bytes"] else None),
        "cgroup_source": cg["source"],
    }


# ---------------------------------------------------------------------------
# Disks
# ---------------------------------------------------------------------------
def _mounts() -> list[tuple[str, str, str]]:
    out = []
    seen = set()
    for line in _read("/proc/mounts").splitlines():
        parts = line.split()
        if len(parts) < 3:
            continue
        dev, mnt, fstype = parts[0], parts[1], parts[2]
        mnt = mnt.replace("\\040", " ")
        if fstype in SKIP_FS or fstype not in REAL_FS:
            continue
        if mnt in seen:
            continue
        if not os.path.isdir(mnt):
            continue
        if fstype == "tmpfs" and mnt != "/" and not mnt.startswith(("/run", "/dev/shm")):
            continue
        try:
            st = os.statvfs(mnt)
        except OSError:
            continue
        if st.f_blocks == 0:
            continue
        seen.add(mnt)
        out.append((dev, mnt, fstype))
    out.sort(key=lambda x: (x[1] != "/", x[1]))
    return out


def disk_info() -> dict[str, Any]:
    items = []
    for dev, mnt, fstype in _mounts():
        try:
            st = os.statvfs(mnt)
        except OSError:
            continue
        total = st.f_blocks * st.f_frsize
        free = st.f_bavail * st.f_frsize
        used = total - st.f_bfree * st.f_frsize
        # overlay / container root cannot see the host disk: report honestly
        items.append({
            "device": dev,
            "mount": mnt,
            "fstype": fstype,
            "total": total,
            "used": used,
            "free": free,
            "percent": round(100 * used / total, 1) if total else 0.0,
            "inodes_total": st.f_files,
            "inodes_free": st.f_favail,
            "read_only": bool(st.f_flag & os.ST_RDONLY) if hasattr(os, "ST_RDONLY") else False,
        })
    return {"items": items, "root": next((i for i in items if i["mount"] == "/"), None)}


# ---------------------------------------------------------------------------
# Network
# ---------------------------------------------------------------------------
class _NetSampler:
    def __init__(self) -> None:
        self.prev: dict[str, tuple[int, int]] = {}
        self.prev_ts = 0.0
        self.rates: dict[str, dict[str, float]] = {}
        self.total = {"rx_bytes": 0, "tx_bytes": 0, "rx_rate": 0.0, "tx_rate": 0.0}

    def _read(self) -> dict[str, tuple[int, int]]:
        data = {}
        for line in _read("/proc/net/dev").splitlines()[2:]:
            if ":" not in line:
                continue
            name, rest = line.split(":", 1)
            fields = rest.split()
            if len(fields) < 9:
                continue
            data[name.strip()] = (int(fields[0]), int(fields[8]))
        return data

    def sample(self) -> None:
        now = time.time()
        cur = self._read()
        dt = now - self.prev_ts if self.prev_ts else 0
        rates = {}
        for name, (rx, tx) in cur.items():
            if dt > 0 and name in self.prev:
                prx, ptx = self.prev[name]
                rates[name] = {"rx": max(0.0, (rx - prx) / dt), "tx": max(0.0, (tx - ptx) / dt)}
            else:
                rates[name] = {"rx": 0.0, "tx": 0.0}
        self.prev = cur
        self.prev_ts = now
        self.rates = rates
        rx_total = sum(v[0] for v in cur.values())
        tx_total = sum(v[1] for v in cur.values())
        self.total = {
            "rx_bytes": rx_total,
            "tx_bytes": tx_total,
            "rx_rate": round(sum(r["rx"] for n, r in rates.items() if n != "lo"), 1),
            "tx_rate": round(sum(r["tx"] for n, r in rates.items() if n != "lo"), 1),
        }


NET = _NetSampler()


def _iface_addresses(name: str) -> dict[str, Any]:
    """IPv4/IPv6 addresses via SIOCGIFADDR or `ip -j addr`."""
    addresses: list[str] = []
    try:
        import fcntl
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            packed = struct.pack("256s", name.encode()[:15])
            res = fcntl.ioctl(s.fileno(), 0x8915, packed)  # SIOCGIFADDR
            addresses.append(socket.inet_ntoa(res[20:24]))
        finally:
            s.close()
    except OSError:
        pass
    for line in _read(f"/proc/net/if_inet6", "").splitlines():
        parts = line.split()
        if len(parts) >= 6 and parts[5] == name:
            try:
                addr = ":".join(parts[0][i:i + 4] for i in range(0, 32, 4))
                import ipaddress
                addresses.append(str(ipaddress.IPv6Address(addr)))
            except ValueError:
                pass
    sa = _read(f"/sys/class/net/{name}/address").strip()
    state = _read(f"/sys/class/net/{name}/operstate").strip() or "unknown"
    mtu = _read_int(f"/sys/class/net/{name}/mtu")
    speed = _read_int(f"/sys/class/net/{name}/speed", -1)
    return {"mac": sa, "state": state, "mtu": mtu, "speed_mbps": speed if speed > 0 else None,
            "addresses": addresses}


def network_info() -> dict[str, Any]:
    if time.time() - NET.prev_ts > 1.5:
        NET.sample()
    ifaces = []
    counters = NET._read()
    for name in sorted(os.listdir("/sys/class/net")):
        rx, tx = counters.get(name, (0, 0))
        rate = NET.rates.get(name, {"rx": 0.0, "tx": 0.0})
        ifaces.append({
            "name": name,
            "rx_bytes": rx,
            "tx_bytes": tx,
            "rx_rate": round(rate["rx"], 1),
            "tx_rate": round(rate["tx"], 1),
            **_iface_addresses(name),
        })
    hostname = socket.gethostname()
    try:
        primary_ip = socket.gethostbyname(hostname)
    except OSError:
        primary_ip = ""
    routes = []
    for line in _read("/proc/net/route").splitlines()[1:]:
        f = line.split()
        if len(f) >= 3 and f[1] == "00000000":
            try:
                gw = socket.inet_ntoa(struct.pack("<L", int(f[2], 16)))
            except (ValueError, struct.error):
                gw = ""
            routes.append({"iface": f[0], "gateway": gw})
    return {"interfaces": ifaces, "total": NET.total, "hostname": hostname,
            "primary_ip": primary_ip, "gateways": routes,
            "dns": _dns_servers()}


def _dns_servers() -> list[str]:
    out = []
    for line in _read("/etc/resolv.conf").splitlines():
        if line.startswith("nameserver"):
            parts = line.split()
            if len(parts) > 1:
                out.append(parts[1])
    return out


# ---------------------------------------------------------------------------
# System overview
# ---------------------------------------------------------------------------
def os_info() -> dict[str, Any]:
    rel = {}
    for line in _read("/etc/os-release").splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            rel[k] = v.strip().strip('"')
    uname = platform.uname()
    up = _read("/proc/uptime").split()
    uptime = float(up[0]) if up else 0.0
    boot = time.time() - uptime
    return {
        "distro": rel.get("PRETTY_NAME") or rel.get("NAME") or "Linux",
        "id": rel.get("ID", ""),
        "version": rel.get("VERSION_ID", ""),
        "kernel": uname.release,
        "arch": uname.machine,
        "hostname": uname.node,
        "uptime_seconds": uptime,
        "boot_time": boot,
        "python": platform.python_version(),
        "virtualization": virtualization(),
    }


def virtualization() -> str | None:
    sv = _which("systemd-detect-virt")
    if sv:
        try:
            r = subprocess.run([sv], capture_output=True, text=True, timeout=3)
            out = r.stdout.strip()
            return out if out and out != "none" else None
        except (OSError, subprocess.SubprocessError):
            return None
    return None


def _user_name(uid: int) -> str:
    try:
        return pwd.getpwuid(uid).pw_name
    except KeyError:
        return str(uid)


def list_processes(limit: int = 400, sort: str = "cpu") -> dict[str, Any]:
    """Parse /proc for real process data. CPU% comes from jiffy deltas."""
    now = time.time()
    dt = now - PROC_SAMPLER.prev_ts if PROC_SAMPLER.prev_ts else 0
    rows = []
    total_jiffies = 0
    pids = [p for p in os.listdir("/proc") if p.isdigit()]
    for pid in pids:
        base = f"/proc/{pid}"
        stat = _read(f"{base}/stat")
        if not stat:
            continue
        close = stat.rfind(")")
        if close < 0:
            continue
        comm = stat[stat.find("(") + 1:close]
        fields = stat[close + 2:].split()
        if len(fields) < 22:
            continue
        try:
            state = fields[0]
            ppid = int(fields[1])
            utime, stime = int(fields[11]), int(fields[12])
            threads = int(fields[17])
            starttime = int(fields[19])
            rss_pages = int(fields[21])
        except (ValueError, IndexError):
            continue
        cpuj = utime + stime
        total_jiffies += cpuj
        cpu_pct = 0.0
        prev = PROC_SAMPLER.prev.get(pid)
        if prev is not None and dt > 0:
            cpu_pct = max(0.0, 100.0 * (cpuj - prev) / CLK_TCK / dt)
        PROC_SAMPLER.cur[pid] = cpuj
        status = _read(f"{base}/status")
        uid = None
        vm_rss = rss_pages * PAGE_SIZE
        for line in status.splitlines():
            if line.startswith("Uid:"):
                try:
                    uid = int(line.split()[1])
                except (ValueError, IndexError):
                    pass
            elif line.startswith("VmRSS:"):
                try:
                    vm_rss = int(line.split()[1]) * 1024
                except (ValueError, IndexError):
                    pass
        cmdline = _read(f"{base}/cmdline").replace("\x00", " ").strip()
        exe = ""
        try:
            exe = os.readlink(f"{base}/exe")
        except OSError:
            pass
        hz = CLK_TCK
        started = PROC_SAMPLER.boot_time + starttime / hz if PROC_SAMPLER.boot_time else 0
        rows.append({
            "pid": int(pid),
            "ppid": ppid,
            "name": comm,
            "state": state,
            "cpu": round(cpu_pct, 1),
            "mem": vm_rss,
            "mem_percent": 0.0,
            "threads": threads,
            "user": _user_name(uid) if uid is not None else "",
            "command": cmdline or f"[{comm}]",
            "exe": exe,
            "started": started,
        })
    total_mem = 0
    for line in _read("/proc/meminfo").splitlines():
        if line.startswith("MemTotal:"):
            total_mem = int(line.split()[1]) * 1024
            break
    for row in rows:
        row["mem_percent"] = round(100 * row["mem"] / total_mem, 1) if total_mem else 0.0
    key = {"cpu": lambda r: -r["cpu"], "mem": lambda r: -r["mem"],
           "pid": lambda r: -r["pid"], "name": lambda r: r["name"]}.get(sort, lambda r: -r["cpu"])
    rows.sort(key=key)
    PROC_SAMPLER.prev = dict(PROC_SAMPLER.cur)
    PROC_SAMPLER.cur = {}
    PROC_SAMPLER.prev_ts = now
    return {"items": rows[:limit], "total": len(rows), "sort": sort,
            "cpu_count": os.cpu_count() or 1}


class _ProcSampler:
    def __init__(self) -> None:
        self.prev: dict[str, int] = {}
        self.cur: dict[str, int] = {}
        self.prev_ts = 0.0
        self.boot_time = time.time() - _safe_uptime()


def _safe_uptime() -> float:
    try:
        return float(_read("/proc/uptime").split()[0])
    except (ValueError, IndexError):
        return 0.0


PROC_SAMPLER = _ProcSampler()


def listening_ports() -> dict[str, Any]:
    """Parse /proc/net/{tcp,tcp6,udp,udp6} and map sockets to processes."""
    states = {"01": "ESTABLISHED", "02": "SYN_SENT", "03": "SYN_RECV", "04": "FIN_WAIT1",
              "05": "FIN_WAIT2", "06": "TIME_WAIT", "07": "CLOSE", "08": "CLOSE_WAIT",
              "09": "LAST_ACK", "0A": "LISTEN", "0B": "CLOSING", "0C": "NEW_SYN_RECV"}
    inode_map = _socket_inodes()
    rows = []
    for proto, path in (("tcp", "/proc/net/tcp"), ("tcp6", "/proc/net/tcp6"),
                        ("udp", "/proc/net/udp"), ("udp6", "/proc/net/udp6")):
        for line in _read(path).splitlines()[1:]:
            f = line.split()
            if len(f) < 10:
                continue
            local, rem, st, inode = f[1], f[2], f[3], f[9]
            try:
                ip_hex, port_hex = local.rsplit(":", 1)
                port = int(port_hex, 16)
                ip = _hex_ip(ip_hex, proto.endswith("6"))
            except ValueError:
                continue
            state = states.get(st, st)
            if proto.startswith("tcp") and state != "LISTEN":
                continue
            owner = inode_map.get(inode)
            rows.append({
                "protocol": proto,
                "address": ip,
                "port": port,
                "state": state,
                "inode": inode,
                "process": owner[0] if owner else None,
                "pid": owner[1] if owner else None,
                "user": owner[2] if owner else None,
                "hidden": owner is None,
            })
    rows.sort(key=lambda r: r["port"])
    visible = sum(1 for r in rows if r["pid"] is not None)
    note = ""
    if visible < len(rows):
        note = ("Some sockets belong to other users; their owning process is only visible "
                "when the panel runs as root.")
    return {"items": rows, "note": note}


def _hex_ip(hexstr: str, ipv6: bool) -> str:
    if not ipv6:
        b = bytes.fromhex(hexstr)[::-1]
        return ".".join(str(x) for x in b)
    raw = bytes.fromhex(hexstr)
    words = [raw[i:i + 4][::-1] for i in range(0, 16, 4)]
    import ipaddress
    return str(ipaddress.IPv6Address(b"".join(words)))


def _socket_inodes() -> dict[str, tuple[str, int, str]]:
    out: dict[str, tuple[str, int, str]] = {}
    for pid in [p for p in os.listdir("/proc") if p.isdigit()]:
        fd_dir = f"/proc/{pid}/fd"
        try:
            fds = os.listdir(fd_dir)
        except OSError:
            continue
        name = None
        uid = None
        for fd in fds:
            try:
                target = os.readlink(f"{fd_dir}/{fd}")
            except OSError:
                continue
            if target.startswith("socket:["):
                inode = target[8:-1]
                if name is None:
                    name = _read(f"/proc/{pid}/comm").strip() or pid
                    uid = _proc_uid(pid)
                out[inode] = (name, int(pid), uid or "")
    return out


def _proc_uid(pid: str) -> str | None:
    for line in _read(f"/proc/{pid}/status").splitlines():
        if line.startswith("Uid:"):
            try:
                return _user_name(int(line.split()[1]))
            except (ValueError, IndexError):
                return None
    return None


def disk_io() -> dict[str, Any]:
    items = []
    for line in _read("/proc/diskstats").splitlines():
        f = line.split()
        if len(f) < 14:
            continue
        name = f[2]
        if any(name.startswith(p) for p in ("loop", "ram", "dm-", "sr")) and not name.startswith("dm-"):
            continue
        if os.path.exists(f"/sys/block/{name}") is False and not name.startswith(("sd", "nvme", "vd", "hd", "xvd", "mmcblk")):
            continue
        try:
            items.append({
                "device": name,
                "reads": int(f[3]),
                "read_sectors": int(f[5]),
                "writes": int(f[7]),
                "write_sectors": int(f[9]),
                "io_ms": int(f[12]),
            })
        except ValueError:
            continue
    return {"items": items[:24]}


# ---------------------------------------------------------------------------
# process actions
# ---------------------------------------------------------------------------
def process_detail(pid: int) -> dict[str, Any] | None:
    base = f"/proc/{pid}"
    if not os.path.isdir(base):
        return None
    stat = _read(f"{base}/stat")
    close = stat.rfind(")")
    fields = stat[close + 2:].split() if close > 0 else []
    status = {}
    for line in _read(f"{base}/status").splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            status[k] = v.strip()
    env_count = len(_read(f"{base}/environ").split("\x00"))
    return {
        "pid": pid,
        "name": stat[stat.find("(") + 1:close] if close > 0 else "",
        "state": fields[0] if fields else "",
        "ppid": int(fields[1]) if len(fields) > 1 else 0,
        "threads": int(fields[17]) if len(fields) > 17 else 0,
        "rss": int(status.get("VmRSS", "0 kB").split()[0] or 0) * 1024,
        "vsz": int(status.get("VmSize", "0 kB").split()[0] or 0) * 1024,
        "user": _proc_uid(str(pid)),
        "command": _read(f"{base}/cmdline").replace("\x00", " ").strip(),
        "cwd": _safe_link(f"{base}/cwd"),
        "exe": _safe_link(f"{base}/exe"),
        "root": _safe_link(f"{base}/root"),
        "open_fds": len(os.listdir(f"{base}/fd")) if os.access(f"{base}/fd", os.R_OK) else None,
        "environment_variables": env_count if env_count > 1 else 0,
        "sig_cgt": status.get("SigCgt", ""),
        "selinux": status.get("Seccomp", ""),
    }


def _safe_link(path: str) -> str:
    try:
        return os.readlink(path)
    except OSError:
        return ""


def kill_process(pid: int, signal_name: str = "TERM") -> tuple[bool, str]:
    import signal as sigmod
    if pid in (1, os.getpid()):
        return False, "refusing to signal PID 1 or the panel itself"
    sig = {"TERM": sigmod.SIGTERM, "KILL": sigmod.SIGKILL, "HUP": sigmod.SIGHUP,
           "INT": sigmod.SIGINT, "STOP": sigmod.SIGSTOP, "CONT": sigmod.SIGCONT}.get(
               signal_name.upper())
    if sig is None:
        return False, "unsupported signal"
    try:
        os.kill(pid, sig)
        return True, f"sent SIG{signal_name.upper()} to {pid}"
    except ProcessLookupError:
        return False, "no such process"
    except PermissionError:
        return False, "permission denied (the panel is not privileged enough)"
    except OSError as exc:
        return False, str(exc)


# ---------------------------------------------------------------------------
# misc
# ---------------------------------------------------------------------------
def thermal_info() -> list[dict[str, Any]]:
    out = []
    for zone in sorted(glob.glob("/sys/class/thermal/thermal_zone*")):
        try:
            temp = int(_read(f"{zone}/temp").strip()) / 1000.0
            kind = _read(f"{zone}/type").strip()
            out.append({"zone": os.path.basename(zone), "type": kind, "celsius": round(temp, 1)})
        except (ValueError, OSError):
            continue
    return out


def logged_in_users() -> list[dict[str, Any]]:
    out = []
    for line in _read("/var/run/utmp", "").splitlines():
        continue
    who = _which("who")
    if who:
        try:
            r = subprocess.run([who], capture_output=True, text=True, timeout=3)
            for line in r.stdout.splitlines():
                out.append({"raw": line})
        except (OSError, subprocess.SubprocessError):
            pass
    return out


def snapshot() -> dict[str, Any]:
    return {
        "os": os_info(),
        "cpu": cpu_info(),
        "memory": memory_info(),
        "disk": disk_info(),
        "network": network_info(),
        "capabilities": capabilities(),
        "thermal": thermal_info(),
        "hostname": socket.gethostname(),
    }
