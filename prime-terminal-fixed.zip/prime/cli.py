"""Command line helpers used by panel.sh (account creation, port checks, info).

    python3 -m prime.cli create-user --username admin   # password on stdin
    python3 -m prime.cli reset-password --username admin
    python3 -m prime.cli check-port --port 8080
    python3 -m prime.cli info
"""
from __future__ import annotations

import argparse
import getpass
import json
import os
import socket
import sys

from . import __version__
from .auth import AuthStore
from .config import Config


def _read_password(arg_password: str | None) -> str:
    if arg_password:
        return arg_password
    if not sys.stdin.isatty():
        data = sys.stdin.readline().rstrip("\n")
        if data:
            return data
        raise SystemExit("no password supplied on stdin")
    first = getpass.getpass("Password: ")
    second = getpass.getpass("Repeat password: ")
    if first != second:
        raise SystemExit("passwords do not match")
    return first


def cmd_create_user(args: argparse.Namespace) -> int:
    cfg = Config.load()
    store = AuthStore(cfg)
    password = _read_password(args.password)
    try:
        if store.get_user(args.username):
            if not args.force:
                print(f"error: user '{args.username}' already exists", file=sys.stderr)
                return 1
            store.set_password(args.username, password)
            print(f"password updated for '{args.username}'")
            return 0
        store.create_user(args.username, password)
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    store.audit("cli.create_user", f"account {args.username} created from the command line")
    print(f"created user '{args.username}'")
    return 0


def cmd_reset_password(args: argparse.Namespace) -> int:
    cfg = Config.load()
    store = AuthStore(cfg)
    if not store.get_user(args.username):
        print(f"error: no such user '{args.username}'", file=sys.stderr)
        return 1
    password = _read_password(args.password)
    try:
        store.set_password(args.username, password)
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    store.audit("cli.reset_password", f"password reset for {args.username}")
    print(f"password reset for '{args.username}' (all sessions invalidated)")
    return 0


def cmd_check_port(args: argparse.Namespace) -> int:
    port = args.port
    if not (1 <= port <= 65535):
        print(f"invalid port {port}", file=sys.stderr)
        return 2
    family = socket.AF_INET
    sock = socket.socket(family, socket.SOCK_STREAM)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((args.host or "0.0.0.0", port))
    except PermissionError:
        print("port <1024 needs root", file=sys.stderr)
        return 3
    except OSError as exc:
        print(f"port {port} is not available: {exc.strerror or exc}", file=sys.stderr)
        return 1
    finally:
        sock.close()
    print(f"port {port} is free")
    return 0


def cmd_info(args: argparse.Namespace) -> int:
    cfg = Config.load()
    store = AuthStore(cfg)
    print(json.dumps({
        "version": __version__,
        "host": cfg.host,
        "port": cfg.port,
        "data_dir": cfg.data_dir,
        "db_path": cfg.db_path,
        "log_path": cfg.log_path,
        "users": store.user_count(),
        "shell": cfg.shell_path,
        "euid": os.geteuid(),
    }, indent=2))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="prime.cli", description="PRIME TERMINAL helper")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("create-user")
    p.add_argument("--username", default="admin")
    p.add_argument("--password", default=None, help="avoid: visible in process list; prefer stdin")
    p.add_argument("--force", action="store_true", help="reset the password if the user exists")
    p.set_defaults(func=cmd_create_user)

    p = sub.add_parser("reset-password")
    p.add_argument("--username", default="admin")
    p.add_argument("--password", default=None)
    p.set_defaults(func=cmd_reset_password)

    p = sub.add_parser("check-port")
    p.add_argument("--port", type=int, required=True)
    p.add_argument("--host", default="0.0.0.0")
    p.set_defaults(func=cmd_check_port)

    p = sub.add_parser("info")
    p.set_defaults(func=cmd_info)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
