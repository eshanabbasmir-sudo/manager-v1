"""Authentication, sessions, users and single-use WebSocket tickets.

Everything lives in a small SQLite database (stdlib) inside the data
directory. Only *hashes* of session tokens and WS tickets are stored, so a
stolen database cannot be replayed as a cookie.
"""
from __future__ import annotations

import os
import sqlite3
import threading
import time
from typing import Optional

from . import security
from .config import Config

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    is_admin INTEGER NOT NULL DEFAULT 1,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL,
    password_changed_at REAL NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    csrf TEXT NOT NULL,
    created_at REAL NOT NULL,
    last_seen REAL NOT NULL,
    expires_at REAL NOT NULL,
    ip TEXT DEFAULT '',
    user_agent TEXT DEFAULT '',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS ws_tickets (
    ticket_hash TEXT PRIMARY KEY,
    session_hash TEXT NOT NULL,
    expires_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    username TEXT DEFAULT '',
    ip TEXT DEFAULT '',
    action TEXT NOT NULL,
    detail TEXT DEFAULT '',
    ok INTEGER NOT NULL DEFAULT 1
);
"""


class AuthError(Exception):
    pass


class Session:
    __slots__ = ("token", "csrf", "user_id", "username", "created_at", "last_seen",
                 "expires_at", "ip", "user_agent")

    def __init__(self, **kw):
        for slot in self.__slots__:
            setattr(self, slot, kw.get(slot))

    def as_public(self) -> dict:
        return {
            "username": self.username,
            "csrf": self.csrf,
            "created_at": self.created_at,
            "last_seen": self.last_seen,
            "expires_at": self.expires_at,
            "ip": self.ip,
        }


class AuthStore:
    def __init__(self, cfg: Config) -> None:
        self.cfg = cfg
        self._lock = threading.RLock()
        os.makedirs(os.path.dirname(cfg.db_path) or ".", exist_ok=True)
        self._conn = sqlite3.connect(cfg.db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.executescript(SCHEMA)
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.commit()
        try:
            os.chmod(cfg.db_path, 0o600)
        except OSError:
            pass

    # ---- users ---------------------------------------------------------
    def user_count(self) -> int:
        with self._lock:
            row = self._conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()
        return int(row["c"])

    def get_user(self, username: str) -> Optional[sqlite3.Row]:
        with self._lock:
            return self._conn.execute(
                "SELECT * FROM users WHERE username = ?", (username,)).fetchone()

    def create_user(self, username: str, password: str) -> None:
        username = (username or "").strip()
        if not username or len(username) > 64 or any(c in username for c in "/\\ \t\n\x00:"):
            raise ValueError("invalid username")
        problems = security.password_problems(password)
        if problems:
            raise ValueError(" ".join(problems))
        now = time.time()
        with self._lock:
            try:
                self._conn.execute(
                    "INSERT INTO users (username, password_hash, is_admin, created_at, updated_at,"
                    " password_changed_at) VALUES (?,?,1,?,?,?)",
                    (username, security.hash_password(password), now, now, now))
                self._conn.commit()
            except sqlite3.IntegrityError:
                raise ValueError("user already exists")

    def set_password(self, username: str, password: str, require_current: str | None = None) -> None:
        user = self.get_user(username)
        if user is None:
            raise ValueError("no such user")
        if require_current is not None:
            if not security.verify_password(require_current, user["password_hash"]):
                raise AuthError("current password is incorrect")
        problems = security.password_problems(password)
        if problems:
            raise ValueError(" ".join(problems))
        now = time.time()
        with self._lock:
            self._conn.execute(
                "UPDATE users SET password_hash = ?, updated_at = ?, password_changed_at = ?"
                " WHERE id = ?",
                (security.hash_password(password), now, now, user["id"]))
            # invalidate every other session for that user
            self._conn.execute("DELETE FROM sessions WHERE user_id = ?", (user["id"],))
            self._conn.commit()

    # ---- login ---------------------------------------------------------
    def authenticate(self, username: str, password: str, ip: str, ua: str) -> Session:
        user = self.get_user(username)
        if user is None:
            # burn the same amount of CPU so user enumeration is harder
            security.verify_password(password, security.DUMMY_HASH)
            raise AuthError("invalid username or password")
        if not security.verify_password(password, user["password_hash"]):
            raise AuthError("invalid username or password")
        return self.new_session(int(user["id"]), user["username"], ip, ua)

    def new_session(self, user_id: int, username: str, ip: str, ua: str) -> Session:
        token = security.new_token(32)
        csrf = security.new_token(24)
        now = time.time()
        expires = now + self.cfg.session_ttl
        with self._lock:
            self._conn.execute(
                "INSERT INTO sessions (token_hash, user_id, csrf, created_at, last_seen,"
                " expires_at, ip, user_agent) VALUES (?,?,?,?,?,?,?,?)",
                (security.token_hash(token), user_id, csrf, now, now, expires,
                 ip or "", (ua or "")[:300]))
            self._conn.commit()
        return Session(token=token, csrf=csrf, user_id=user_id, username=username,
                       created_at=now, last_seen=now, expires_at=expires, ip=ip, user_agent=ua)

    def lookup(self, token: str, touch: bool = True) -> Optional[Session]:
        if not token or len(token) > 200:
            return None
        th = security.token_hash(token)
        now = time.time()
        with self._lock:
            row = self._conn.execute(
                "SELECT s.*, u.username FROM sessions s JOIN users u ON u.id = s.user_id"
                " WHERE s.token_hash = ?", (th,)).fetchone()
            if row is None:
                return None
            if row["expires_at"] < now:
                self._conn.execute("DELETE FROM sessions WHERE token_hash = ?", (th,))
                self._conn.commit()
                return None
            if touch and now - row["last_seen"] > 30:
                # sliding expiry: only extended while the session is in use
                new_exp = now + self.cfg.session_ttl
                self._conn.execute(
                    "UPDATE sessions SET last_seen = ?, expires_at = ? WHERE token_hash = ?",
                    (now, new_exp, th))
                self._conn.commit()
                row = dict(row)
                row["expires_at"] = new_exp
                row["last_seen"] = now
        return Session(token=token, csrf=row["csrf"], user_id=row["user_id"],
                       username=row["username"], created_at=row["created_at"],
                       last_seen=row["last_seen"], expires_at=row["expires_at"],
                       ip=row["ip"], user_agent=row["user_agent"])

    def destroy(self, token: str) -> None:
        if not token:
            return
        with self._lock:
            self._conn.execute("DELETE FROM sessions WHERE token_hash = ?",
                               (security.token_hash(token),))
            self._conn.commit()

    def destroy_all_for_user(self, username: str, keep_token: str | None = None) -> None:
        user = self.get_user(username)
        if not user:
            return
        with self._lock:
            if keep_token:
                self._conn.execute(
                    "DELETE FROM sessions WHERE user_id = ? AND token_hash != ?",
                    (user["id"], security.token_hash(keep_token)))
            else:
                self._conn.execute("DELETE FROM sessions WHERE user_id = ?", (user["id"],))
            self._conn.commit()

    def list_sessions(self, username: str) -> list[dict]:
        user = self.get_user(username)
        if not user:
            return []
        with self._lock:
            rows = self._conn.execute(
                "SELECT created_at, last_seen, expires_at, ip, user_agent FROM sessions"
                " WHERE user_id = ? ORDER BY last_seen DESC", (user["id"],)).fetchall()
        return [dict(r) for r in rows]

    def sweep(self) -> None:
        now = time.time()
        with self._lock:
            self._conn.execute("DELETE FROM sessions WHERE expires_at < ?", (now,))
            self._conn.execute("DELETE FROM ws_tickets WHERE expires_at < ?", (now,))
            self._conn.commit()

    # ---- websocket tickets --------------------------------------------
    def issue_ws_ticket(self, session: Session, ttl: int = 45) -> str:
        ticket = security.new_token(24)
        now = time.time()
        with self._lock:
            self._conn.execute(
                "INSERT INTO ws_tickets (ticket_hash, session_hash, expires_at) VALUES (?,?,?)",
                (security.token_hash(ticket), security.token_hash(session.token), now + ttl))
            self._conn.commit()
        return ticket

    def consume_ws_ticket(self, ticket: str, cookie_token: str) -> bool:
        """A ticket is bound to the session cookie that requested it."""
        if not ticket or not cookie_token:
            return False
        th = security.token_hash(ticket)
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM ws_tickets WHERE ticket_hash = ?", (th,)).fetchone()
            if row is None:
                return False
            self._conn.execute("DELETE FROM ws_tickets WHERE ticket_hash = ?", (th,))
            self._conn.commit()
        if row["expires_at"] < time.time():
            return False
        return security.constant_eq(row["session_hash"], security.token_hash(cookie_token))

    # ---- audit ---------------------------------------------------------
    def audit(self, action: str, detail: str = "", ok: bool = True,
              username: str = "", ip: str = "") -> None:
        try:
            with self._lock:
                self._conn.execute(
                    "INSERT INTO audit (ts, username, ip, action, detail, ok) VALUES (?,?,?,?,?,?)",
                    (time.time(), username, ip, action, detail[:500], 1 if ok else 0))
                self._conn.commit()
        except sqlite3.Error:
            pass

    def recent_audit(self, limit: int = 50) -> list[dict]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT ts, username, ip, action, detail, ok FROM audit"
                " ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
