/**
 * Application shell: authentication, theme, navigation and view lifecycle.
 */
import { api, setCsrf } from "./api.js";
import { icon } from "./icons.js";
import * as ui from "./ui.js";
import { esc, el, $ } from "./ui.js";

import dashboard from "./views/dashboard.js";
import terminal from "./views/terminal.js";
import files from "./views/files.js";
import processes from "./views/processes.js";
import services from "./views/services.js";
import packages from "./views/packages.js";
import logs from "./views/logs.js";
import pythonView from "./views/python.js";
import diagnostics from "./views/diagnostics.js";
import ssh from "./views/ssh.js";
import settings from "./views/settings.js";

const VIEWS = {
  dashboard, terminal, files, processes, services, packages, logs,
  python: pythonView, diagnostics, ssh, settings,
};

const NAV = [
  { group: "Overview", items: [{ id: "dashboard", label: "Dashboard", icon: "dashboard" }] },
  {
    group: "Control",
    items: [
      { id: "terminal", label: "Terminal", icon: "terminal" },
      { id: "files", label: "Files", icon: "folder" },
      { id: "processes", label: "Processes", icon: "activity" },
    ],
  },
  {
    group: "System",
    items: [
      { id: "services", label: "Services", icon: "layers" },
      { id: "packages", label: "Packages", icon: "box" },
      { id: "logs", label: "Logs", icon: "scroll" },
    ],
  },
  {
    group: "Tools",
    items: [
      { id: "python", label: "Python", icon: "code" },
      { id: "diagnostics", label: "Diagnostics", icon: "wifi" },
      { id: "ssh", label: "SSH keys", icon: "key" },
    ],
  },
  { group: "Account", items: [{ id: "settings", label: "Settings", icon: "settings" }] },
];

const TABS = ["dashboard", "terminal", "files", "processes"];

const app = {
  user: null,
  view: null,
  viewId: null,
  ctx: null,
  online: true,
  healthTimer: null,
  root: null,
};

/* ------------------------------------------------------------------ theme */
export function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  try {
    localStorage.setItem("prime-theme", theme);
  } catch { /* private mode */ }
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", theme === "light" ? "#eef1f7" : "#06070a");
}

function initTheme() {
  let saved = null;
  try {
    saved = localStorage.getItem("prime-theme");
  } catch { /* ignore */ }
  const prefersLight = window.matchMedia("(prefers-color-scheme: light)").matches;
  applyTheme(saved || (prefersLight ? "light" : "dark"));
}

function toggleTheme() {
  const next = document.documentElement.dataset.theme === "light" ? "dark" : "light";
  applyTheme(next);
  document.querySelectorAll("[data-theme-icon]").forEach((node) => {
    node.innerHTML = icon(next === "light" ? "moon" : "sun");
  });
}

/* ------------------------------------------------------------------- auth */
function renderAuth({ needsSetup, message = "" }) {
  const root = $("#root");
  document.body.style.overflow = "auto";
  root.innerHTML = `
    <div class="auth-wrap">
      <div class="auth-card">
        <div class="auth-head">
          <div class="logo">
            <span class="logo-mark">${icon("terminal")}</span>
            <span>PRIME <em>TERMINAL</em></span>
          </div>
          <h1>${needsSetup ? "Create your account" : "Welcome back"}</h1>
          <p>${needsSetup
            ? "This panel has no account yet. Choose credentials for the administrator."
            : "Sign in to control this Linux server."}</p>
        </div>
        <form id="auth-form" autocomplete="on" novalidate>
          <div class="field">
            <label for="username">Username</label>
            <input class="input" id="username" name="username" autocomplete="username"
                   value="${needsSetup ? "admin" : ""}" required spellcheck="false">
          </div>
          <div class="field">
            <label for="password">Password</label>
            <div class="pw-wrap">
              <input class="input" id="password" name="password" type="password"
                     autocomplete="${needsSetup ? "new-password" : "current-password"}"
                     required minlength="${needsSetup ? 10 : 1}">
              <button class="pw-toggle" type="button" id="pw-toggle" aria-label="Show password">
                ${icon("eye")}
              </button>
            </div>
            ${needsSetup ? `<div class="field-hint">At least 10 characters, with a letter and a digit.</div>` : ""}
          </div>
          ${needsSetup ? `
          <div class="field">
            <label for="password2">Confirm password</label>
            <input class="input" id="password2" type="password" autocomplete="new-password" required>
          </div>` : ""}
          <div class="field-error" id="auth-error">${esc(message)}</div>
          <button class="btn btn-primary btn-block" type="submit" id="auth-submit">
            ${needsSetup ? "Create account & sign in" : "Sign in"}
          </button>
        </form>
        <div class="auth-note">
          ${icon("shield")} Sessions are protected with an HttpOnly cookie, CSRF tokens and
          rate-limited sign-in. ${needsSetup
            ? "The account is stored locally on this server as a scrypt hash."
            : "If you have lost the password, reset it on the server with <span class=\"mono\">bash panel.sh reset-password</span>."}
        </div>
        <div class="auth-foot">
          <span>PRIME TERMINAL ${esc(window.__PRIME_VERSION__ || "")}</span>
          <button class="btn btn-ghost btn-sm" type="button" id="auth-theme">
            <span data-theme-icon>${icon(document.documentElement.dataset.theme === "light" ? "moon" : "sun")}</span>
            Theme
          </button>
        </div>
      </div>
    </div>`;

  const form = $("#auth-form");
  const errorBox = $("#auth-error");
  const submit = $("#auth-submit");
  $("#pw-toggle").addEventListener("click", () => {
    const input = $("#password");
    const show = input.type === "password";
    input.type = show ? "text" : "password";
    $("#pw-toggle").innerHTML = icon(show ? "eyeOff" : "eye");
  });
  $("#auth-theme").addEventListener("click", toggleTheme);

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    errorBox.textContent = "";
    const username = $("#username").value.trim();
    const password = $("#password").value;
    if (!username || !password) {
      errorBox.textContent = "Enter a username and a password.";
      return;
    }
    if (needsSetup) {
      const confirm = $("#password2").value;
      if (password !== confirm) {
        errorBox.textContent = "The passwords do not match.";
        return;
      }
    }
    submit.disabled = true;
    submit.innerHTML = `<span class="spinner"></span>${needsSetup ? "Creating…" : "Signing in…"}`;
    try {
      const endpoint = needsSetup ? "/api/auth/setup" : "/api/auth/login";
      const result = await api.post(endpoint, { username, password });
      setCsrf(result.csrf);
      app.user = { username: result.user };
      await bootShell();
    } catch (err) {
      errorBox.textContent = err.message || "Sign-in failed.";
      submit.disabled = false;
      submit.textContent = needsSetup ? "Create account & sign in" : "Sign in";
      form.classList.add("view-enter");
    }
  });
  setTimeout(() => $("#username")?.focus(), 200);
}

/* ------------------------------------------------------------------ shell */
function navMarkup(activeId) {
  return NAV.map(
    (group) => `
    <div class="nav-group">
      <div class="nav-label">${esc(group.group)}</div>
      ${group.items
        .map(
          (item) => `<button class="nav-item ${item.id === activeId ? "active" : ""}"
            data-nav="${item.id}" type="button">${icon(item.icon)}<span>${esc(item.label)}</span></button>`,
        )
        .join("")}
    </div>`,
  ).join("");
}

function tabbarMarkup(activeId) {
  const items = TABS.map(
    (id) => {
      const found = NAV.flatMap((g) => g.items).find((i) => i.id === id);
      return `<button class="tab-item ${id === activeId ? "active" : ""}" data-nav="${id}" type="button">
        ${icon(found.icon)}<span>${esc(found.label)}</span></button>`;
    },
  ).join("");
  return `${items}
    <button class="tab-item" id="tab-more" type="button">
      ${icon("more")}<span>More</span></button>`;
}

async function bootShell() {
  try {
    const me = await api.get("/api/auth/me");
    app.user = me.user;
    window.__PRIME_VERSION__ = me.version;
  } catch { /* status endpoint already handles auth */ }

  const root = $("#root");
  document.body.style.overflow = "hidden";
  root.innerHTML = `
    <div id="app">
      <aside class="sidebar" id="sidebar">
        <div class="logo" style="padding:4px 8px 0">
          <span class="logo-mark">${icon("terminal")}</span>
          <span>PRIME<br><em style="font-size:10px;letter-spacing:.14em">TERMINAL</em></span>
        </div>
        <nav id="nav-root" aria-label="Main">${navMarkup("dashboard")}</nav>
        <div class="sidebar-foot">
          <div class="row" style="gap:8px">
            <span class="avatar">${esc((app.user?.username || "?").slice(0, 1))}</span>
            <div class="grow truncate">
              <div style="color:var(--text);font-weight:600">${esc(app.user?.username || "")}</div>
              <div class="faint" style="font-size:11px">administrator</div>
            </div>
          </div>
          <div style="margin-top:8px" id="sidebar-host">—</div>
        </div>
      </aside>
      <header class="topbar">
        <button class="icon-btn menu-toggle" id="menu-toggle" aria-label="Menu">${icon("menu")}</button>
        <div class="grow truncate" style="min-width:0">
          <h2 id="view-title">Dashboard</h2>
          <div class="crumb" id="view-crumb"></div>
        </div>
        <div class="topbar-right">
          <span class="conn-pill live hide-sm" id="conn-pill">
            <span class="dot"></span><span>connected</span>
          </span>
          <button class="icon-btn" id="theme-toggle" aria-label="Toggle theme">
            <span data-theme-icon>${icon(document.documentElement.dataset.theme === "light" ? "moon" : "sun")}</span>
          </button>
          <button class="icon-btn" id="account-btn" aria-label="Account">
            <span class="avatar" style="width:28px;height:28px;font-size:12px">${esc((app.user?.username || "?").slice(0, 1))}</span>
          </button>
        </div>
      </header>
      <main id="view"></main>
      <nav class="tabbar" id="tabbar" aria-label="Sections">${tabbarMarkup("dashboard")}</nav>
    </div>
    <div id="sidebar-backdrop" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:30;backdrop-filter:blur(3px)"></div>`;

  $("#theme-toggle").addEventListener("click", toggleTheme);
  $("#menu-toggle").addEventListener("click", () => toggleDrawer(true));
  $("#sidebar-backdrop").addEventListener("click", () => toggleDrawer(false));
  $("#account-btn").addEventListener("click", openAccountMenu);
  $("#tab-more").addEventListener("click", openMoreSheet);
  document.body.addEventListener("click", handleNavClick);

  startHealthPolling();
  window.addEventListener("hashchange", route);
  if (!location.hash) location.replace("#/dashboard");
  else route();
  ui.apiReady = true;
}

function handleNavClick(event) {
  const target = event.target.closest("[data-nav]");
  if (!target) return;
  const id = target.dataset.nav;
  if (id) {
    navigate(id);
    toggleDrawer(false);
  }
}

function toggleDrawer(open) {
  const sidebar = $("#sidebar");
  const backdrop = $("#sidebar-backdrop");
  if (!sidebar) return;
  sidebar.classList.toggle("open", open);
  backdrop.style.display = open ? "block" : "none";
}

function openAccountMenu() {
  const button = $("#account-btn");
  const existing = $("#account-menu");
  if (existing) {
    existing.remove();
    return;
  }
  const rect = button.getBoundingClientRect();
  const menu = el("div", { class: "menu", id: "account-menu" });
  menu.style.top = `${rect.bottom + 8}px`;
  menu.style.right = `${Math.max(12, window.innerWidth - rect.right)}px`;
  menu.style.left = "auto";
  menu.innerHTML = `
    <div style="padding:10px 12px 6px">
      <div style="font-weight:650">${esc(app.user?.username || "")}</div>
      <div class="faint" style="font-size:11.5px">signed in</div>
    </div>
    <div class="menu-sep"></div>
    <button class="menu-item" data-nav="settings">${icon("settings")}Settings</button>
    <button class="menu-item" data-nav="ssh">${icon("key")}SSH keys</button>
    <div class="menu-sep"></div>
    <button class="menu-item danger" id="logout-item">${icon("logout")}Sign out</button>`;
  document.body.appendChild(menu);
  menu.addEventListener("click", async (event) => {
    const nav = event.target.closest("[data-nav]");
    if (nav) {
      menu.remove();
      navigate(nav.dataset.nav);
      return;
    }
    if (event.target.closest("#logout-item")) {
      menu.remove();
      await logout();
    }
  });
  setTimeout(() => {
    const off = (event) => {
      if (!menu.contains(event.target)) {
        menu.remove();
        document.removeEventListener("click", off);
      }
    };
    document.addEventListener("click", off);
  }, 0);
}

function openMoreSheet() {
  const items = NAV.flatMap((g) => g.items).filter((i) => !TABS.includes(i.id));
  const content = `<div class="sheet-actions">
    ${items
      .map(
        (item) => `<button class="list-row" data-nav="${item.id}" type="button">
          <span class="lead">${icon(item.icon)}</span>
          <span class="grow">${esc(item.label)}</span>
          ${icon("chevronRight")}
        </button>`,
      )
      .join("")}
    <div class="menu-sep"></div>
    <button class="list-row" id="more-logout" type="button">
      <span class="lead" style="color:var(--danger)">${icon("logout")}</span>
      <span class="grow" style="color:var(--danger)">Sign out</span>
    </button>
  </div>`;
  const s = ui.sheet({ title: "More", content });
  s.card.addEventListener("click", async (event) => {
    const nav = event.target.closest("[data-nav]");
    if (nav) {
      ui.closeSheet(s);
      navigate(nav.dataset.nav);
      return;
    }
    if (event.target.closest("#more-logout")) {
      ui.closeSheet(s);
      await logout();
    }
  });
}

async function logout() {
  try {
    await api.post("/api/auth/logout");
  } catch { /* ignore */ }
  cleanup();
  renderAuth({ needsSetup: false, message: "You have been signed out." });
}

function cleanup() {
  if (app.healthTimer) clearInterval(app.healthTimer);
  app.healthTimer = null;
  destroyView();
}

function startHealthPolling() {
  const pill = $("#conn-pill");
  const setOnline = (online) => {
    app.online = online;
    if (!pill) return;
    pill.classList.toggle("live", online);
    pill.classList.toggle("down", !online);
    pill.innerHTML = `<span class="dot ${online ? "pulse" : ""}"></span><span>${online ? "connected" : "offline"}</span>`;
  };
  const check = async () => {
    try {
      const res = await fetch("/api/health", { credentials: "same-origin", cache: "no-store" });
      setOnline(res.ok);
    } catch {
      setOnline(false);
    }
  };
  check();
  app.healthTimer = setInterval(check, 15000);
  window.addEventListener("online", check);
  window.addEventListener("offline", () => setOnline(false));
}

/* ----------------------------------------------------------------- router */
function navigate(id) {
  if (!VIEWS[id]) id = "dashboard";
  if (location.hash === `#/${id}`) {
    route();
    return;
  }
  location.hash = `#/${id}`;
}

function destroyView() {
  if (app.view && typeof app.view.unmount === "function") {
    try {
      app.view.unmount();
    } catch (err) {
      console.error("view unmount failed", err);
    }
  }
  app.view = null;
  app.viewId = null;
}

async function route() {
  const hash = location.hash.replace(/^#\/?/, "") || "dashboard";
  const id = VIEWS[hash] ? hash : "dashboard";
  const view = VIEWS[id];
  if (app.viewId === id && app.view) return;

  destroyView();
  const main = $("#view");
  if (!main) return;
  main.classList.toggle("no-pad", Boolean(view.noPad));
  main.innerHTML = "";
  main.scrollTop = 0;

  const title = $("#view-title");
  if (title) title.textContent = view.title || id;
  const crumb = $("#view-crumb");
  if (crumb) crumb.textContent = view.crumb || "";

  document.querySelectorAll("[data-nav]").forEach((node) => {
    node.classList.toggle("active", node.dataset.nav === id);
  });
  document.title = `${view.title || "PRIME"} · PRIME TERMINAL`;

  app.view = view;
  app.viewId = id;
  app.ctx = {
    navigate,
    user: app.user,
    online: () => app.online,
    refresh: () => route(),
  };
  try {
    await view.mount(main, app.ctx);
  } catch (err) {
    console.error(err);
    main.innerHTML = `<div class="card"><div class="empty">${icon("alert")}
      <div><b>This view failed to load.</b><div class="faint" style="margin-top:6px">${esc(err.message || err)}</div></div>
      <button class="btn btn-sm" id="view-reload">Reload the panel</button></div></div>`;
    main.querySelector("#view-reload")?.addEventListener("click", () => location.reload());
  }
}

/* ------------------------------------------------------------------- boot */
async function boot() {
  initTheme();
  window.addEventListener("prime:unauthorized", () => {
    cleanup();
    renderAuth({ needsSetup: false, message: "Your session expired. Sign in again." });
  });
  let status;
  try {
    status = await api.get("/api/auth/status");
  } catch (err) {
    $("#boot")?.classList.add("hide");
    $("#root").innerHTML = `<div class="auth-wrap"><div class="auth-card">
      <div class="auth-head"><h1>Cannot reach the panel</h1>
      <p>${esc(err.message)}</p></div>
      <button class="btn btn-primary btn-block" id="boot-retry">Retry</button>
      </div></div>`;
    document.getElementById("boot-retry")?.addEventListener("click", () => location.reload());
    return;
  }
  window.__PRIME_VERSION__ = status.version;
  const bootEl = $("#boot");
  if (bootEl) {
    bootEl.classList.add("hide");
    setTimeout(() => bootEl.remove(), 400);
  }
  if (status.authenticated) {
    setCsrf(status.csrf);
    app.user = { username: status.user };
    await bootShell();
  } else {
    renderAuth({ needsSetup: status.needs_setup });
  }
}

boot();
