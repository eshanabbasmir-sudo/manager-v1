/** Network diagnostics — whitelisted tools executed with argv arrays (no shell). */
import { api } from "../api.js";
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc } from "../ui.js";

const state = { tools: [], target: "1.1.1.1", running: null, last: null };

const TARGET_DEFAULTS = {
  ping: "1.1.1.1",
  dns: "localhost",
  trace: "1.1.1.1",
  http: "https://example.com",
};

function toolButton(tool) {
  return `<button class="btn ${tool.available ? "" : ""}" data-tool="${tool.id}"
      ${tool.available ? "" : "disabled"} title="${esc(tool.command)}">
      ${icon(tool.id === "ping" ? "zap" : tool.id === "dns" ? "globe" : tool.id === "http" ? "external"
        : tool.id === "trace" ? "move" : tool.id === "ports" ? "network" : "server")}
      ${esc(tool.label)}</button>`;
}

function shell() {
  return `<div class="view-enter">
    <div class="card">
      <div class="card-head">
        <div class="card-title-icon">${icon("wifi")}</div>
        <div><h3>Network diagnostics</h3>
          <div class="sub">real commands, executed with argument arrays — never through a shell</div></div>
      </div>
      <div class="field">
        <label>Target host or URL</label>
        <input class="input mono" id="diag-target" value="${esc(state.target)}"
               placeholder="example.com or https://example.com" spellcheck="false" autocomplete="off">
      </div>
      <div class="chip-row" id="diag-tools">
        ${state.tools.map(toolButton).join("") || ui.skeletonRows(1, 44)}
      </div>
      ${state.tools.some((t) => !t.available)
        ? `<div class="notice" style="margin-top:12px">${icon("alert")}<div>Some tools are not
            installed: ${state.tools.filter((t) => !t.available).map((t) => `<span class="mono">${esc(t.id)}</span>`).join(", ")}.
            Install them with your package manager to enable those checks.</div></div>`
        : ""}
    </div>
    <div class="card" id="diag-result-card" style="margin-top:16px;${state.last ? "" : "display:none"}">
      <div class="card-head">
        <div class="card-title-icon">${icon("terminal")}</div>
        <div><h3 id="diag-title">Result</h3><div class="sub mono" id="diag-cmd"></div></div>
        <div class="spacer"></div>
        <span class="badge" id="diag-exit"></span>
      </div>
      <pre class="code-out" id="diag-out" style="max-height:48vh"></pre>
    </div>
  </div>`;
}

function renderResult(result) {
  const card = document.getElementById("diag-result-card");
  const out = document.getElementById("diag-out");
  if (!card || !out) return;
  card.style.display = "";
  document.getElementById("diag-title").textContent = result.label || "Result";
  document.getElementById("diag-cmd").textContent = (result.command || []).join(" ");
  const exit = document.getElementById("diag-exit");
  exit.className = `badge ${result.ok ? "ok" : "danger"}`;
  exit.textContent = `exit ${result.code} · ${result.duration}s`;
  out.textContent = `${result.stdout || ""}${result.stderr ? `\n${result.stderr}` : ""}`.trim() || "(no output)";
}

async function run(tool) {
  const input = document.getElementById("diag-target");
  const target = input?.value.trim() || "";
  const spec = state.tools.find((t) => t.id === tool);
  if (spec?.needs_target && !target) {
    ui.notifyWarn("Target required", "Enter a host or URL first.");
    return;
  }
  state.target = target;
  const card = document.getElementById("diag-result-card");
  card.style.display = "";
  document.getElementById("diag-title").textContent = spec?.label || "Running…";
  document.getElementById("diag-cmd").textContent = "";
  document.getElementById("diag-exit").textContent = "";
  document.getElementById("diag-out").textContent = "running…";
  document.querySelectorAll("[data-tool]").forEach((b) => { b.disabled = true; });
  try {
    const result = await api.post(
      "/api/diagnostics/run",
      {},
      { tool, target },
    );
    state.last = result;
    renderResult(result);
  } catch (err) {
    document.getElementById("diag-out").textContent = ui.errorText(err);
    document.getElementById("diag-title").textContent = "Failed";
    const exit = document.getElementById("diag-exit");
    exit.className = "badge danger";
    exit.textContent = `error ${err.status}`;
  } finally {
    document.querySelectorAll("[data-tool]").forEach((b) => {
      const spec2 = state.tools.find((t) => t.id === b.dataset.tool);
      b.disabled = !spec2?.available;
    });
  }
}

export default {
  title: "Diagnostics",
  crumb: "ping, DNS, HTTP, routes",
  async mount(container, ctx) {
    try {
      const data = await api.get("/api/diagnostics/tools");
      state.tools = data.tools;
    } catch (err) {
      container.innerHTML = `<div class="card">${ui.emptyState(ui.errorText(err), "alert")}</div>`;
      return;
    }
    container.innerHTML = shell();
    container.addEventListener("click", (event) => {
      const btn = event.target.closest("[data-tool]");
      if (btn) run(btn.dataset.tool);
    });
    container.addEventListener("keydown", (event) => {
      if (event.target.id === "diag-target" && event.key === "Enter") {
        const tool = state.tools.find((t) => t.needs_target && t.available);
        if (tool) run(tool.id);
      }
    });
  },
  unmount() {},
};
