/** Log viewer: /var/log files and journald, with grep and live tail. */
import { api } from "../api.js";
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc, bytes, timestamp } from "../ui.js";

const state = {
  tab: "files",
  sources: null,
  selected: null,
  lines: [],
  grep: "",
  count: 200,
  live: false,
  timer: null,
  loading: false,
};

function sourceList() {
  const files = state.sources?.files || [];
  if (!files.length) return ui.emptyState("No log files found", "scroll");
  return `<div class="list">${files
    .map(
      (f) => `<button class="list-row ${state.selected === f.path ? "active" : ""}"
        data-file="${esc(f.path)}" type="button"
        ${f.readable ? "" : 'style="opacity:.55"'} data-readonly="${f.readable ? "1" : "0"}">
        <span class="lead">${icon(f.readable ? "scroll" : "lock")}</span>
        <span class="grow truncate">
          <span class="title truncate">${esc(f.name)}</span>
          <span class="meta"><span>${bytes(f.size)}</span><span>${esc(timestamp(f.mtime))}</span></span>
        </span>
        ${icon("chevronRight", 16)}
      </button>`,
    )
    .join("")}</div>`;
}

function viewer() {
  if (state.tab === "journal") {
    return `<div class="toolbar">
        <div class="search">${icon("search")}
          <input class="input" id="log-grep" placeholder="Filter lines…" value="${esc(state.grep)}"></div>
        <select class="select" id="log-lines" style="max-width:130px;min-height:40px;padding:8px 36px 8px 12px">
          ${[100, 200, 500, 1000].map((n) => `<option value="${n}" ${n === state.count ? "selected" : ""}>${n} lines</option>`).join("")}
        </select>
        <button class="btn btn-sm" id="log-refresh">${icon("refresh")}Refresh</button>
        <button class="btn btn-sm ${state.live ? "btn-primary" : ""}" id="log-live">
          ${icon(state.live ? "pause" : "play")}${state.live ? "Live" : "Tail"}</button>
      </div>
      <pre class="code-out" id="log-body" style="max-height:52vh">${state.lines.length ? esc(state.lines.join("\n")) : "loading…"}</pre>`;
  }
  if (!state.selected) {
    return ui.emptyState("Select a log file to read it", "scroll");
  }
  return `<div class="toolbar">
      <div class="grow truncate mono" style="font-size:12.5px">${esc(state.selected)}</div>
      <div class="search" style="max-width:220px">${icon("search")}
        <input class="input" id="log-grep" placeholder="Filter lines…" value="${esc(state.grep)}"></div>
      <select class="select" id="log-lines" style="max-width:130px;min-height:40px;padding:8px 36px 8px 12px">
        ${[100, 200, 500, 1000, 2000].map((n) => `<option value="${n}" ${n === state.count ? "selected" : ""}>${n} lines</option>`).join("")}
      </select>
      <button class="btn btn-sm" id="log-refresh">${icon("refresh")}Refresh</button>
      <button class="btn btn-sm ${state.live ? "btn-primary" : ""}" id="log-live">
        ${icon(state.live ? "pause" : "play")}${state.live ? "Live" : "Tail"}</button>
    </div>
    <pre class="code-out" id="log-body" style="max-height:52vh">${state.lines.length ? esc(state.lines.join("\n")) : "loading…"}</pre>`;
}

function shell() {
  return `<div class="view-enter">
    <div class="card">
      <div class="card-head">
        <div class="card-title-icon">${icon("scroll")}</div>
        <div><h3>Logs</h3><div class="sub">${
          state.tab === "files" ? `${state.sources?.files?.length || 0} files` : "journald"
        }</div></div>
        <div class="spacer"></div>
        <button class="btn btn-sm" id="log-reload">${icon("refresh")}Reload</button>
      </div>
      <div class="tabs" id="log-tabs">
        <button class="tab ${state.tab === "files" ? "active" : ""}" data-tab="files">Files</button>
        <button class="tab ${state.tab === "journal" ? "active" : ""}" data-tab="journal">journalctl</button>
      </div>
      <div class="tmux-grid" style="display:grid;grid-template-columns:minmax(220px,300px) 1fr;gap:16px">
        <div id="log-sources">${state.tab === "files" ? sourceList() : journalHelp()}</div>
        <div id="log-viewer">${viewer()}</div>
      </div>
    </div>
  </div>`;
}

function journalHelp() {
  if (!state.sources?.journal) {
    return `<div class="notice">${icon("alert")}<div>journalctl is not available on this system.
      Use the Files tab instead.</div></div>`;
  }
  return `<div class="stack">
    <div class="field"><label>Filter unit (optional)</label>
      <input class="input" id="journal-unit" placeholder="e.g. ssh.service"></div>
    <div class="field"><label>Priority</label>
      <select class="select" id="journal-priority">
        <option value="all">All</option><option value="err">Errors only</option>
        <option value="warning">Warnings and worse</option><option value="info">Info</option>
      </select></div>
    <div class="notice info">${icon("info")}<div>Reading the journal usually requires root or
      membership of the <span class="mono">systemd-journal</span> group.</div></div>
  </div>`;
}

async function loadSources(container) {
  try {
    state.sources = await api.get("/api/logs");
  } catch (err) {
    container.innerHTML = `<div class="card">${ui.emptyState(ui.errorText(err), "alert")}</div>`;
    return;
  }
  container.innerHTML = shell();
}

async function loadFile(path) {
  state.selected = path;
  state.lines = [];
  const srcHost = document.getElementById("log-sources");
  if (srcHost) srcHost.innerHTML = sourceList();
  const viewerHost = document.getElementById("log-viewer");
  if (viewerHost) viewerHost.innerHTML = viewer();
  await tail();
}

async function tail() {
  const body = document.getElementById("log-body");
  if (state.tab === "journal") {
    const unit = document.getElementById("journal-unit")?.value.trim() || undefined;
    const priority = document.getElementById("journal-priority")?.value || "all";
    try {
      const data = await api.get("/api/logs/journal", {
        lines: state.count, grep: state.grep, unit, priority,
      });
      state.lines = data.lines;
    } catch (err) {
      state.lines = [`[${ui.errorText(err)}]`];
    }
  } else {
    if (!state.selected) return;
    try {
      const data = await api.get("/api/logs/tail", {
        path: state.selected, lines: state.count, grep: state.grep,
      });
      state.lines = data.lines;
    } catch (err) {
      state.lines = [`[${ui.errorText(err)}]`];
    }
  }
  if (body) {
    body.textContent = state.lines.length ? state.lines.join("\n") : "(no matching lines)";
    body.scrollTop = body.scrollHeight;
  }
}

export default {
  title: "Logs",
  crumb: "log files and journald",
  async mount(container, ctx) {
    container.innerHTML = ui.skeletonRows(2, 120);
    await loadSources(container);

    container.addEventListener("click", (event) => {
      const tab = event.target.closest("[data-tab]");
      if (tab) {
        state.tab = tab.dataset.tab;
        state.lines = [];
        container.innerHTML = shell();
        if (state.tab === "journal") tail();
        else if (state.selected) tail();
        return;
      }
      const file = event.target.closest("[data-file]");
      if (file) {
        if (file.dataset.readonly === "0") {
          ui.notifyWarn("Not readable", "This log needs root; run the panel as root or add the user to the adm group.");
        }
        loadFile(file.dataset.file);
        return;
      }
      if (event.target.closest("#log-refresh")) {
        tail();
        return;
      }
      if (event.target.closest("#log-reload")) {
        loadSources(container);
        return;
      }
      if (event.target.closest("#log-live")) {
        state.live = !state.live;
        const btn = document.getElementById("log-live");
        if (btn) {
          btn.classList.toggle("btn-primary", state.live);
          btn.innerHTML = `${icon(state.live ? "pause" : "play")}${state.live ? "Live" : "Tail"}`;
        }
        if (state.live) startTimer();
        else stopTimer();
        return;
      }
    });

    container.addEventListener("keydown", (event) => {
      if (event.target.id === "log-grep" && event.key === "Enter") {
        state.grep = event.target.value.trim();
        tail();
      }
      if (event.target.id === "journal-unit" && event.key === "Enter") {
        state.grep = document.getElementById("log-grep")?.value.trim() || "";
        tail();
      }
    });
    container.addEventListener("change", (event) => {
      if (event.target.id === "log-lines") {
        state.count = Number(event.target.value);
        tail();
      }
      if (event.target.id === "journal-priority") {
        tail();
      }
    });

    function startTimer() {
      stopTimer();
      state.timer = setInterval(() => {
        if (!document.hidden && state.live) tail();
      }, 3000);
    }
    function stopTimer() {
      if (state.timer) clearInterval(state.timer);
      state.timer = null;
    }
    this._start = startTimer;
    this._stop = stopTimer;
  },
  unmount() {
    if (state.timer) clearInterval(state.timer);
    state.timer = null;
    state.live = false;
    state.lines = [];
  },
};
