/** Account, security and panel settings. */
import { api, setCsrf } from "../api.js";
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc, timestamp, ago, duration, bytes } from "../ui.js";

const state = { me: null, sessions: [], audit: [], panel: null, caps: null };

function shell() {
  const s = state.sessions;
  const panel = state.panel || {};
  const caps = state.caps || {};
  const container = caps.container || {};
  return `<div class="view-enter grid cols-2">
    <div class="card">
      <div class="card-head">
        <div class="card-title-icon">${icon("user")}</div>
        <div><h3>Account</h3><div class="sub">${esc(state.me?.user?.username || "")}</div></div>
      </div>
      <div class="field">
        <label>Current password</label>
        <input class="input" id="pw-current" type="password" autocomplete="current-password">
      </div>
      <div class="field">
        <label>New password</label>
        <input class="input" id="pw-new" type="password" autocomplete="new-password">
        <div class="field-hint">At least 10 characters with a letter and a digit. Other sessions are signed out.</div>
      </div>
      <div class="field">
        <label>Confirm new password</label>
        <input class="input" id="pw-confirm" type="password" autocomplete="new-password">
      </div>
      <button class="btn btn-primary" id="pw-save">${icon("lock")}Change password</button>
      <div class="notice info" style="margin-top:14px">${icon("info")}
        <div>Passwords are stored as scrypt hashes (N=32768) in
        <span class="mono">${esc(panel.data_dir || "")}/panel.db</span>.</div></div>
    </div>

    <div class="card">
      <div class="card-head">
        <div class="card-title-icon">${icon("history")}</div>
        <div><h3>Active sessions</h3><div class="sub">${s.length} session${s.length === 1 ? "" : "s"}</div></div>
        <div class="spacer"></div>
        <button class="btn btn-sm btn-danger" id="sess-revoke">${icon("logout")}Sign out all</button>
      </div>
      <div class="list">
        ${s.map((x) => `<div class="list-row" style="cursor:default">
          <span class="lead">${icon("user")}</span>
          <span class="grow truncate">
            <span class="title truncate mono">${esc(x.ip || "unknown")}</span>
            <span class="meta truncate"><span>${esc((x.user_agent || "unknown client").slice(0, 60))}</span></span>
          </span>
          <span class="faint" style="font-size:11.5px;text-align:right;white-space:nowrap">
            ${esc(ago(x.last_seen))}<br>expires ${esc(ago(x.expires_at).replace(" ago", ""))}
          </span>
        </div>`).join("") || ui.emptyState("No sessions", "user")}
      </div>
    </div>

    <div class="card">
      <div class="card-head">
        <div class="card-title-icon">${icon("shield")}</div>
        <div><h3>Security posture</h3><div class="sub">what the server allows</div></div>
      </div>
      <dl class="kv">
        <dt>Panel user</dt><dd>${esc(panel.user || "—")}${caps.is_root ? ' <span class="badge warn">root</span>' : ""}</dd>
        <dt>Secure cookies</dt><dd>${panel.secure_cookies ? "enabled" : "disabled (plain HTTP)"}</dd>
        <dt>Reverse proxy mode</dt><dd>${panel.behind_proxy ? "enabled" : "disabled"}</dd>
        <dt>Container</dt><dd>${container.is_container ? esc(container.kind || "yes") : "no (host)"}</dd>
        <dt>service manager</dt><dd>${caps.systemd ? "systemd present" : "unavailable"}</dd>
        <dt>File roots</dt><dd class="mono" style="font-size:11.5px">${esc((panel.allowed_roots || []).join(", "))}</dd>
        <dt>Read-only files</dt><dd>${panel.read_only_files ? "yes" : "no"}</dd>
        <dt>Terminal sessions</dt><dd>${esc(panel.sessions ?? 0)}</dd>
      </dl>
      <div class="notice" style="margin-top:14px">${icon("lock")}
        <div><b>Put this panel behind HTTPS.</b> Use a reverse proxy (Caddy, nginx) with a TLS
        certificate and set <span class="mono">"behind_proxy": true, "secure_cookies": true</span>
        in the panel config. See <span class="mono">docs/HTTPS.md</span>.</div></div>
    </div>

    <div class="card">
      <div class="card-head">
        <div class="card-title-icon">${icon("clock")}</div>
        <div><h3>Activity log</h3><div class="sub">most recent panel actions</div></div>
      </div>
      <div class="list" style="max-height:360px;overflow-y:auto">
        ${state.audit.map((a) => `<div class="list-row" style="cursor:default">
          <span class="lead" style="${a.ok ? "" : "color:var(--danger)"}">${icon(a.ok ? "check" : "alert")}</span>
          <span class="grow truncate">
            <span class="title truncate">${esc(a.action)}</span>
            <span class="meta truncate"><span>${esc(a.detail || "")}</span></span>
          </span>
          <span class="faint" style="font-size:11px;white-space:nowrap">${esc(ago(a.ts))}</span>
        </div>`).join("") || ui.emptyState("No activity recorded", "history")}
      </div>
    </div>

    <div class="card span-2">
      <div class="card-head">
        <div class="card-title-icon">${icon("terminal")}</div>
        <div><h3>About PRIME TERMINAL</h3><div class="sub">version ${esc(panel.version || "")}</div></div>
        <div class="spacer"></div>
        <button class="btn btn-sm btn-danger" id="logout-btn">${icon("logout")}Sign out</button>
      </div>
      <dl class="kv">
        <dt>Server process</dt><dd class="mono">pid ${esc(panel.pid ?? "—")} · ${bytes(panel.rss || 0)} RSS</dd>
        <dt>Panel uptime</dt><dd>${esc(duration(panel.uptime_seconds))}</dd>
        <dt>Data directory</dt><dd class="mono">${esc(panel.data_dir || "")}</dd>
        <dt>Management</dt><dd class="mono" style="font-size:11.5px">bash panel.sh start|stop|restart|status|update|uninstall</dd>
      </dl>
      <div class="notice info" style="margin-top:14px">${icon("info")}
        <div>Every value in this panel is read from the running kernel or produced by real
        commands — there are no simulated statistics.</div></div>
    </div>
  </div>`;
}

export default {
  title: "Settings",
  crumb: "account, security and panel info",
  async mount(container, ctx) {
    container.innerHTML = ui.skeletonRows(2, 160);
    try {
      const [me, sessions, audit, panel, caps] = await Promise.all([
        api.get("/api/auth/me"),
        api.get("/api/auth/sessions"),
        api.get("/api/auth/audit", { limit: 40 }),
        api.get("/api/system/panel"),
        api.get("/api/system/capabilities"),
      ]);
      state.me = me;
      state.sessions = sessions.sessions || [];
      state.audit = audit.items || [];
      state.panel = { ...panel, secure_cookies: caps.secure_cookies, behind_proxy: caps.behind_proxy };
      state.caps = caps;
    } catch (err) {
      container.innerHTML = `<div class="card">${ui.emptyState(ui.errorText(err), "alert")}</div>`;
      return;
    }
    container.innerHTML = shell();

    container.addEventListener("click", async (event) => {
      if (event.target.closest("#pw-save")) {
        const current = document.getElementById("pw-current").value;
        const next = document.getElementById("pw-new").value;
        const confirm = document.getElementById("pw-confirm").value;
        if (!current || !next) {
          ui.notifyWarn("Incomplete", "Fill in the current and new password.");
          return;
        }
        if (next !== confirm) {
          ui.notifyWarn("Mismatch", "The new passwords do not match.");
          return;
        }
        try {
          const result = await api.post("/api/auth/password", { current, new: next });
          if (result.csrf) setCsrf(result.csrf);
          ui.notifyOk("Password changed", "Other sessions were signed out.");
          ["pw-current", "pw-new", "pw-confirm"].forEach((id) => {
            const node = document.getElementById(id);
            if (node) node.value = "";
          });
        } catch (err) {
          ui.showError(err, "Could not change the password");
        }
        return;
      }
      if (event.target.closest("#sess-revoke")) {
        const ok = await ui.confirmDialog({
          title: "Sign out everywhere?",
          message: "Every session including this one will be invalidated.",
          confirmLabel: "Sign out all",
          danger: true,
        });
        if (!ok) return;
        try {
          await api.post("/api/auth/sessions/revoke");
          window.location.reload();
        } catch (err) {
          ui.showError(err, "Could not revoke sessions");
        }
        return;
      }
      if (event.target.closest("#logout-btn")) {
        try {
          await api.post("/api/auth/logout");
        } catch { /* ignore */ }
        window.location.reload();
      }
    });
  },
  unmount() {},
};
