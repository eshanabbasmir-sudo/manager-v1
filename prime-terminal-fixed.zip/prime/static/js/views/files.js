/** File manager — real browsing, editing, upload/download and permissions. */
import { api, downloadFile } from "../api.js";
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc, bytes, timestamp, ago } from "../ui.js";

const state = {
  path: "/",
  entries: [],
  offset: 0,
  limit: 200,
  total: 0,
  hasMore: false,
  sort: "name",
  order: "asc",
  hidden: true,
  meta: null,
  roots: [],
  loading: false,
  search: null,
  ctx: null,
  scrollHandler: null,
};

function fileIcon(entry) {
  if (entry.type === "dir") return "folder";
  if (entry.type === "link") return "external";
  const name = entry.name || "";
  if (/\.(diff|patch)$/i.test(name)) return "code";
  if (/\.(txt|md|log|conf|cfg|ini|yml|yaml|json|toml|env)$/i.test(name)) return "file";
  if (/\.(sh|bash|py|js|ts|go|rs|c|h|cpp|rb|php|pl|lua)$/i.test(name)) return "code";
  if (/\.(gz|tgz|xz|zip|tar|bz2|zst|7z|rar)$/i.test(name)) return "box";
  return "file";
}

function crumbs() {
  const crumbs = state.meta?.breadcrumbs || [{ name: "/", path: "/" }];
  return `<div class="fm-crumbs" id="fm-crumbs">
    ${crumbs
      .map(
        (c, i) => `${i ? `<span class="crumb-sep">/</span>` : ""}
        <button class="crumb" data-path="${esc(c.path)}" type="button">${esc(c.name === "/" ? "root" : c.name)}</button>`,
      )
      .join("")}
  </div>`;
}

function row(entry) {
  const isDir = entry.type === "dir" || entry.target_type === "dir";
  const perms = entry.mode_string || "";
  return `<div class="list-row" data-path="${esc(entry.path)}" data-type="${esc(entry.type)}" role="button" tabindex="0">
    <span class="lead ${isDir ? "dir" : "file"}">${icon(fileIcon(entry))}</span>
    <span class="grow truncate">
      <span class="title truncate">${esc(entry.name)}${entry.is_symlink ? ` <span class="faint" style="font-size:11px">→ ${esc(entry.target_type || "link")}</span>` : ""}</span>
      <span class="fm-sub mono">${isDir ? "directory" : bytes(entry.size)} · ${esc(perms)} · ${esc(entry.owner)}:${esc(entry.group)}</span>
    </span>
    <span class="fm-props">
      <span class="mono">${esc(perms)}</span>
      <span title="${esc(timestamp(entry.mtime, "long"))}">${esc(ago(entry.mtime))}</span>
    </span>
    <span class="fm-row-actions row" style="gap:2px">
      ${isDir
        ? `<button class="icon-btn" data-act="open" title="Open" aria-label="Open">${icon("chevronRight")}</button>`
        : `<button class="icon-btn" data-act="edit" title="Edit / view" aria-label="Edit">${icon("edit")}</button>`}
      <button class="icon-btn" data-act="more" title="Actions" aria-label="Actions">${icon("more")}</button>
    </span>
  </div>`;
}

function listMarkup() {
  if (state.search) {
    return `<div class="stack">
      <div class="row between">
        <span class="badge accent">search: ${esc(state.search.query)}</span>
        <button class="btn btn-sm btn-ghost" id="fm-clear-search">${icon("x")}Clear</button>
      </div>
      <div class="list">${
        state.entries.length
          ? state.entries.map(row).join("")
          : ui.emptyState("No matches in this tree", "search")
      }</div>
      ${state.search.truncated ? `<div class="notice info">${icon("info")}<div>Results were truncated. Narrow the query or the directory.</div></div>` : ""}
    </div>`;
  }
  if (state.loading && !state.entries.length) return ui.skeletonRows(6, 46);
  if (!state.entries.length) {
    return ui.emptyState("This directory is empty", "folderOpen");
  }
  return `<div class="list fm-list">${state.entries.map(row).join("")}</div>
    ${state.hasMore
      ? `<div class="row" style="justify-content:center;margin-top:10px">
          <button class="btn btn-sm" id="fm-more">Load more (${state.entries.length}/${state.total})</button>
        </div>`
      : state.total > state.limit
        ? `<div class="faint" style="text-align:center;font-size:12px;margin-top:10px">Showing ${state.entries.length} of ${state.total}</div>`
        : ""}`;
}

function shell() {
  const ro = state.meta?.read_only ? `<span class="badge warn">read-only mode</span>` : "";
  return `
  <div class="view-enter">
    <div class="card" style="padding:14px 14px 8px">
      <div class="toolbar" style="margin-bottom:10px">
        <button class="icon-btn" id="fm-up" title="Parent directory" aria-label="Up">${icon("arrowUp")}</button>
        <button class="icon-btn" id="fm-refresh" title="Refresh" aria-label="Refresh">${icon("refresh")}</button>
        ${crumbs()}
        ${ro}
      </div>
      <div class="toolbar" style="margin-bottom:8px">
        <div class="search">
          ${icon("search")}
          <input class="input" id="fm-search" type="search" placeholder="Search this tree…"
                 autocomplete="off" enterkeyhint="search">
        </div>
        <select class="select" id="fm-sort" style="max-width:170px;min-height:40px;padding:8px 36px 8px 12px">
          <option value="name">Name</option>
          <option value="mtime">Modified</option>
          <option value="size">Size</option>
          <option value="type">Type</option>
          <option value="owner">Owner</option>
        </select>
        <button class="btn btn-sm" id="fm-order" title="Toggle direction">
          ${state.order === "asc" ? icon("arrowDown") : icon("arrowUp")}
        </button>
        <button class="btn btn-sm" id="fm-hidden" title="Show hidden files">
          ${icon(state.hidden ? "eye" : "eyeOff")}${state.hidden ? "Hidden" : "Visible"}
        </button>
        <span class="right"></span>
        <button class="btn btn-sm" id="fm-new">${icon("plus")}New</button>
        <button class="btn btn-sm btn-primary" id="fm-upload">${icon("upload")}Upload</button>
        <input type="file" id="fm-file-input" multiple hidden>
      </div>
      <div id="fm-drop" style="display:none" class="drop-hint">Drop files to upload into ${esc(state.path)}</div>
    </div>
    <div class="card" style="margin-top:16px">
      <div class="row between" style="margin-bottom:10px;gap:10px">
        <div class="truncate mono" style="font-size:12.5px">${esc(state.path)}</div>
        <div class="faint" style="font-size:12px;white-space:nowrap" id="fm-count">
          ${state.total} item${state.total === 1 ? "" : "s"}${state.meta?.fs ? ` · ${bytes(state.meta.fs.free)} free` : ""}
        </div>
      </div>
      <div id="fm-list">${listMarkup()}</div>
    </div>
  </div>`;
}

function refreshMeta() {
  const count = document.getElementById("fm-count");
  if (count) {
    count.textContent = `${state.total} item${state.total === 1 ? "" : "s"}${
      state.meta?.fs ? ` · ${bytes(state.meta.fs.free)} free` : ""}`;
  }
  const crumbsHost = document.getElementById("fm-crumbs");
  if (crumbsHost) crumbsHost.outerHTML = crumbs();
}

function bindCrumbNav() {
  document.getElementById("fm-crumbs")?.addEventListener("click", (event) => {
    const btn = event.target.closest("[data-path]");
    if (btn) navigateTo(btn.dataset.path);
  });
}

async function navigateTo(path, { keepSearch = false } = {}) {
  state.path = path;
  state.offset = 0;
  if (!keepSearch) state.search = null;
  await load();
}

async function load({ append = false } = {}) {
  state.loading = true;
  const listHost = document.getElementById("fm-list");
  if (listHost && !append) listHost.innerHTML = ui.skeletonRows(6, 46);
  try {
    const data = await api.get("/api/files/list", {
      path: state.path,
      offset: append ? state.entries.length : 0,
      limit: state.limit,
      hidden: state.hidden,
      sort: state.sort,
      order: state.order,
    });
    state.meta = { ...data, entries: undefined };
    state.roots = data.roots;
    state.total = data.total;
    state.hasMore = data.has_more;
    state.entries = append ? state.entries.concat(data.entries) : data.entries;
    state.search = null;
    if (listHost) listHost.innerHTML = listMarkup();
    refreshMeta();
    bindCrumbNav();
    const searchInput = document.getElementById("fm-search");
    if (searchInput) searchInput.value = "";
  } catch (err) {
    state.entries = [];
    if (listHost) {
      listHost.innerHTML = `<div class="notice danger">${icon("alert")}<div>${esc(ui.errorText(err))}</div></div>`;
    }
    ui.showError(err, "Cannot open this directory");
  } finally {
    state.loading = false;
  }
}

async function runSearch(query) {
  const listHost = document.getElementById("fm-list");
  if (!query || query.length < 2) {
    state.search = null;
    if (!state.entries.length) await load();
    else if (listHost) listHost.innerHTML = listMarkup();
    return;
  }
  listHost.innerHTML = ui.skeletonRows(4, 46);
  try {
    const data = await api.post("/api/files/search", {
      root: state.path,
      query,
      limit: 300,
      max_depth: 8,
    });
    state.entries = data.items;
    state.search = { query, truncated: data.truncated };
    state.total = data.items.length;
    listHost.innerHTML = listMarkup();
  } catch (err) {
    ui.showError(err, "Search failed");
    listHost.innerHTML = listMarkup();
  }
}

function openRowActions(entry) {
  const isDir = entry.type === "dir" || entry.target_type === "dir";
  const actions = [
    isDir
      ? { label: "Open", icon: "folderOpen", act: "open" }
      : { label: "Edit / view", icon: "edit", act: "edit" },
    !isDir ? { label: "Download", icon: "download", act: "download" } : null,
    isDir ? { label: "Download as .tar.gz", icon: "download", act: "archive" } : null,
    { label: "Rename", icon: "edit", act: "rename" },
    { label: "Copy to…", icon: "copy", act: "copy" },
    { label: "Move to…", icon: "move", act: "move" },
    { label: "Permissions & owner", icon: "lock", act: "chmod" },
    { label: "Delete", icon: "trash", act: "delete", danger: true },
  ].filter(Boolean);

  const content = `<div class="sheet-actions">
    <div class="list-row" style="cursor:default">
      <span class="lead ${isDir ? "dir" : "file"}">${icon(fileIcon(entry))}</span>
      <span class="grow truncate">
        <span class="title truncate">${esc(entry.name)}</span>
        <span class="meta"><span class="mono">${esc(entry.mode_string)}</span><span>${esc(entry.owner)}:${esc(entry.group)}</span><span>${isDir ? "dir" : bytes(entry.size)}</span></span>
      </span>
    </div>
    <div class="menu-sep"></div>
    ${actions
      .map(
        (a) => `<button class="list-row ${a.danger ? "danger" : ""}" data-act="${a.act}" type="button">
          <span class="lead" ${a.danger ? 'style="color:var(--danger)"' : ""}>${icon(a.icon)}</span>
          <span class="grow">${esc(a.label)}</span></button>`,
      )
      .join("")}
    <div class="menu-sep"></div>
    <div class="faint" style="font-size:11.5px;padding:6px 12px 2px;overflow-wrap:anywhere">
      ${esc(entry.path)}<br>modified ${esc(timestamp(entry.mtime, "long"))}
    </div>
  </div>`;
  const s = ui.sheet({ title: entry.name, content });
  s.card.addEventListener("click", async (event) => {
    const btn = event.target.closest("[data-act]");
    if (!btn) return;
    ui.closeSheet(s);
    handleAction(btn.dataset.act, entry);
  });
}

async function handleAction(act, entry) {
  switch (act) {
    case "open":
      return navigateTo(entry.path);
    case "edit":
      return openEditor(entry);
    case "download":
      try {
        await downloadFile("/api/files/download", { path: entry.path });
      } catch (err) {
        ui.showError(err, "Download failed");
      }
      return;
    case "archive":
      try {
        ui.notifyInfo("Archiving…", "Packing the directory on the server");
        await downloadFile("/api/files/archive", { path: entry.path });
      } catch (err) {
        ui.showError(err, "Archive failed");
      }
      return;
    case "rename": {
      const name = await ui.promptDialog({
        title: "Rename",
        subtitle: entry.path,
        label: "New name",
        value: entry.name,
        confirmLabel: "Rename",
      });
      if (!name || name === entry.name) return;
      try {
        await api.post("/api/files/rename", { path: entry.path, name });
        ui.notifyOk("Renamed", name);
        load();
      } catch (err) {
        ui.showError(err, "Rename failed");
      }
      return;
    }
    case "copy":
    case "move": {
      const destination = await ui.promptDialog({
        title: act === "move" ? "Move to directory" : "Copy to directory",
        subtitle: `${entry.name} → destination directory path`,
        label: "Destination directory",
        value: state.path,
        confirmLabel: act === "move" ? "Move" : "Copy",
        hint: "The item keeps its name; a suffix is added if it already exists.",
      });
      if (!destination) return;
      try {
        await api.post("/api/files/transfer", { path: entry.path, destination, move: act === "move" });
        ui.notifyOk(act === "move" ? "Moved" : "Copied", destination);
        load();
      } catch (err) {
        ui.showError(err, act === "move" ? "Move failed" : "Copy failed");
      }
      return;
    }
    case "delete": {
      const ok = await ui.confirmDialog({
        title: "Delete this item?",
        message: `“${entry.name}” will be removed from the server.`,
        detail: entry.path,
        confirmLabel: "Delete",
        danger: true,
      });
      if (!ok) return;
      try {
        await api.post("/api/files/delete", { path: entry.path, recursive: true });
        ui.notifyOk("Deleted", entry.name);
        load();
      } catch (err) {
        ui.showError(err, "Delete failed");
      }
      return;
    }
    case "chmod":
      return openPermissions(entry);
    default:
      return undefined;
  }
}

function openPermissions(entry) {
  const octal = (entry.mode & 0o777).toString(8).padStart(3, "0");
  const content = `<div class="stack">
    <div class="field">
      <label>Permission bits (octal)</label>
      <input class="input mono" id="perm-mode" value="${esc(octal)}" maxlength="4" spellcheck="false">
      <div class="field-hint">Current: <span class="mono">${esc(entry.mode_string)}</span></div>
    </div>
    <div class="chip-row">
      ${[["644", "rw-r--r--"], ["600", "rw-------"], ["755", "rwxr-xr-x"], ["700", "rwx------"], ["777", "rwxrwxrwx"]]
        .map(([m, label]) => `<button class="btn btn-sm" data-setmode="${m}">${m} <span class="faint">${label}</span></button>`)
        .join("")}
    </div>
    <div class="field-row" style="margin-top:4px">
      <div class="field"><label>Owner</label><input class="input" id="perm-owner" value="${esc(entry.owner)}"></div>
      <div class="field"><label>Group</label><input class="input" id="perm-group" value="${esc(entry.group)}"></div>
    </div>
    <div class="notice info">${icon("info")}<div>chown usually requires the panel to run as root.</div></div>
  </div>`;
  const s = ui.sheet({
    title: "Permissions",
    subtitle: entry.path,
    content,
    actions: [
      { label: "Cancel", kind: "ghost" },
      {
        label: "Apply",
        kind: "primary",
        onClick: async ({ close }) => {
          const mode = document.getElementById("perm-mode").value.trim();
          const owner = document.getElementById("perm-owner").value.trim();
          const group = document.getElementById("perm-group").value.trim();
          try {
            if (mode && mode !== octal) await api.post("/api/files/chmod", { path: entry.path, mode });
            if (owner !== entry.owner || group !== entry.group) {
              await api.post("/api/files/chown", { path: entry.path, owner, group });
            }
            ui.notifyOk("Permissions updated", entry.name);
            close();
            load();
          } catch (err) {
            ui.showError(err, "Could not update permissions");
          }
        },
      },
    ],
  });
  s.card.addEventListener("click", (event) => {
    const btn = event.target.closest("[data-setmode]");
    if (btn) document.getElementById("perm-mode").value = btn.dataset.setmode;
  });
}

async function openEditor(entry) {
  let data;
  try {
    data = await api.get("/api/files/read", { path: entry.path });
  } catch (err) {
    if (err.status === 415 || err.status === 413) {
      ui.sheet({
        title: entry.name,
        subtitle: "This file cannot be edited in the browser",
        content: `<div class="notice">${icon("alert")}<div>${esc(ui.errorText(err))}</div></div>`,
        actions: [
          { label: "Download", kind: "primary", icon: "download",
            onClick: () => downloadFile("/api/files/download", { path: entry.path }).catch((e) => ui.showError(e, "Download failed")) },
        ],
      });
      return;
    }
    ui.showError(err, "Cannot open this file");
    return;
  }

  const readOnly = data.read_only_mode || data.config_read_only;
  const area = `${readOnly
    ? `<div class="notice">${icon("lock")}<div>You can read this file but not write it
        ${data.config_read_only ? "(the panel is in read-only mode)" : "(file permissions deny writing)"}.</div></div>`
    : ""}
    <textarea class="fm-editor" id="fm-editor" spellcheck="false" ${readOnly ? "readonly" : ""}>${esc(data.content)}</textarea>
    <div class="row between faint" style="font-size:11.5px;margin-top:8px;gap:10px">
      <span id="fm-editor-info">${bytes(data.size)} · ${esc((data.mode & 0o777).toString(8))}</span>
      <span class="mono">Ctrl/⌘+S to save</span>
    </div>`;

  const s = ui.sheet({
    title: entry.name,
    subtitle: data.path,
    content: area,
    wide: true,
    tall: true,
    actions: [
      { label: "Close", kind: "ghost" },
      !readOnly ? { label: "Save", kind: "primary", icon: "save", close: false,
        onClick: async ({ close }) => {
          const text = document.getElementById("fm-editor").value;
          try {
            const result = await api.post("/api/files/write", {
              path: data.path,
              content: text,
              expected_mtime: data.mtime,
            });
            data.mtime = result.mtime;
            data.size = result.size;
            ui.notifyOk("Saved", entry.name);
            load();
            close();
          } catch (err) {
            ui.showError(err, "Save failed");
          }
        } } : null,
    ].filter(Boolean),
  });
  const editor = document.getElementById("fm-editor");
  const info = document.getElementById("fm-editor-info");
  const updateInfo = () => {
    if (!info) return;
    const val = editor.value;
    const lines = val.split("\n").length;
    info.textContent = `${lines} lines · ${bytes(new Blob([val]).size)} · ${(data.mode & 0o777).toString(8)}`;
  };
  editor?.addEventListener("input", updateInfo);
  editor?.addEventListener("keydown", (event) => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "s") {
      event.preventDefault();
      s.foot.querySelector(".btn-primary")?.click();
    }
    if (event.key === "Tab") {
      event.preventDefault();
      const start = editor.selectionStart;
      const end = editor.selectionEnd;
      editor.value = `${editor.value.slice(0, start)}  ${editor.value.slice(end)}`;
      editor.selectionStart = editor.selectionEnd = start + 2;
      updateInfo();
    }
  });
  setTimeout(() => editor?.focus(), 150);
}

function openNewMenu() {
  const content = `<div class="sheet-actions">
    <button class="list-row" data-new="folder" type="button">
      <span class="lead">${icon("folder")}</span><span class="grow">New folder</span></button>
    <button class="list-row" data-new="file" type="button">
      <span class="lead">${icon("file")}</span><span class="grow">New empty file</span></button>
    <button class="list-row" data-new="path" type="button">
      <span class="lead">${icon("move")}</span><span class="grow">Go to path…</span></button>
  </div>`;
  const s = ui.sheet({ title: "Create", subtitle: state.path, content });
  s.card.addEventListener("click", async (event) => {
    const btn = event.target.closest("[data-new]");
    if (!btn) return;
    ui.closeSheet(s);
    if (btn.dataset.new === "folder") {
      const name = await ui.promptDialog({ title: "New folder", label: "Folder name", confirmLabel: "Create" });
      if (!name) return;
      try {
        await api.post("/api/files/mkdir", { path: state.path, name, mode: "755" });
        ui.notifyOk("Folder created", name);
        load();
      } catch (err) {
        ui.showError(err, "Could not create the folder");
      }
    } else if (btn.dataset.new === "file") {
      const name = await ui.promptDialog({ title: "New file", label: "File name", confirmLabel: "Create" });
      if (!name) return;
      try {
        await api.post("/api/files/create", { path: state.path, name, content: "", mode: "644" });
        ui.notifyOk("File created", name);
        await load();
        const created = state.entries.find((e) => e.name === name);
        if (created) openEditor(created);
      } catch (err) {
        ui.showError(err, "Could not create the file");
      }
    } else {
      const target = await ui.promptDialog({ title: "Go to path", label: "Directory", value: state.path, confirmLabel: "Open" });
      if (target) navigateTo(target);
    }
  });
}

async function uploadFiles(fileList) {
  if (!fileList || !fileList.length) return;
  const files = Array.from(fileList);
  const progressHost = document.createElement("div");
  progressHost.className = "stack";
  const sheetObj = ui.sheet({
    title: files.length === 1 ? `Uploading ${files[0].name}` : `Uploading ${files.length} files`,
    subtitle: `into ${state.path}`,
    content: progressHost,
    dismissible: false,
  });
  let failed = 0;
  for (const file of files) {
    const rowEl = document.createElement("div");
    rowEl.className = "stack";
    rowEl.style.gap = "6px";
    rowEl.innerHTML = `<div class="row between" style="font-size:12.5px">
        <span class="truncate mono">${esc(file.name)}</span>
        <span class="faint">${bytes(file.size)}</span>
      </div>
      <div class="progress"><i style="width:0%"></i></div>`;
    progressHost.appendChild(rowEl);
    const bar = rowEl.querySelector(".progress > i");
    try {
      const query = new URLSearchParams({ path: state.path, name: file.name }).toString();
      const result = await api.upload(`/api/files/upload?${query}`, file, {
        onProgress: (ratio) => {
          bar.style.width = `${Math.round(ratio * 100)}%`;
        },
      });
      bar.style.width = "100%";
      bar.style.background = "var(--ok)";
      if (result?.name && result.name !== file.name) {
        ui.notifyInfo("Renamed on upload", `${file.name} → ${result.name} (already existed)`);
      }
    } catch (err) {
      failed += 1;
      bar.style.background = "var(--danger)";
      ui.showError(err, `Upload failed: ${file.name}`);
    }
  }
  ui.closeSheet(sheetObj);
  if (!failed) ui.notifyOk("Upload complete", `${files.length} file${files.length === 1 ? "" : "s"}`);
  load();
}

function wireUploadDrop(container) {
  const drop = document.getElementById("fm-drop");
  let depth = 0;
  const show = (on) => {
    if (drop) drop.style.display = on ? "block" : "none";
  };
  container.addEventListener("dragenter", (event) => {
    if (!event.dataTransfer?.types?.includes("Files")) return;
    event.preventDefault();
    depth += 1;
    show(true);
  });
  container.addEventListener("dragover", (event) => {
    if (!event.dataTransfer?.types?.includes("Files")) return;
    event.preventDefault();
  });
  container.addEventListener("dragleave", () => {
    depth = Math.max(0, depth - 1);
    if (!depth) show(false);
  });
  container.addEventListener("drop", (event) => {
    if (!event.dataTransfer?.files?.length) return;
    event.preventDefault();
    depth = 0;
    show(false);
    uploadFiles(event.dataTransfer.files);
  });
}

export default {
  title: "Files",
  crumb: "real server filesystem",
  async mount(container, ctx) {
    state.ctx = ctx;
    try {
      const roots = await api.get("/api/files/roots");
      state.roots = roots.roots;
      state.path = roots.home || roots.roots[0] || "/";
      state.meta = { read_only: roots.read_only, fs: null, breadcrumbs: null };
    } catch (err) {
      container.innerHTML = `<div class="card">${ui.emptyState(ui.errorText(err), "alert")}</div>`;
      throw err;
    }
    container.innerHTML = shell();
    await load();

    container.addEventListener("click", (event) => {
      const rowEl = event.target.closest(".list-row[data-path]");
      if (rowEl) {
        const path = rowEl.dataset.path;
        const entry = state.entries.find((e) => e.path === path);
        const actBtn = event.target.closest("[data-act]");
        if (!entry) return;
        if (actBtn) {
          event.stopPropagation();
          if (actBtn.dataset.act === "more") openRowActions(entry);
          else handleAction(actBtn.dataset.act, entry);
          return;
        }
        if (entry.type === "dir" || entry.target_type === "dir") navigateTo(entry.path);
        else openEditor(entry);
        return;
      }
      const more = event.target.closest("#fm-more");
      if (more) {
        load({ append: true });
        return;
      }
      if (event.target.closest("#fm-clear-search")) {
        state.search = null;
        load();
      }
    });

    document.getElementById("fm-up").addEventListener("click", () => {
      if (state.meta?.parent) navigateTo(state.meta.parent);
    });
    document.getElementById("fm-refresh").addEventListener("click", () => load());
    document.getElementById("fm-new").addEventListener("click", openNewMenu);
    document.getElementById("fm-upload").addEventListener("click", () => {
      document.getElementById("fm-file-input").click();
    });
    document.getElementById("fm-file-input").addEventListener("change", (event) => {
      uploadFiles(event.target.files);
      event.target.value = "";
    });
    document.getElementById("fm-sort").addEventListener("change", (event) => {
      state.sort = event.target.value;
      load();
    });
    document.getElementById("fm-order").addEventListener("click", () => {
      state.order = state.order === "asc" ? "desc" : "asc";
      const btn = document.getElementById("fm-order");
      btn.innerHTML = state.order === "asc" ? icon("arrowDown") : icon("arrowUp");
      load();
    });
    document.getElementById("fm-hidden").addEventListener("click", () => {
      state.hidden = !state.hidden;
      const btn = document.getElementById("fm-hidden");
      btn.innerHTML = `${icon(state.hidden ? "eye" : "eyeOff")}${state.hidden ? "Hidden" : "Visible"}`;
      load();
    });
    let searchTimer = null;
    document.getElementById("fm-search").addEventListener("input", (event) => {
      const query = event.target.value.trim();
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => runSearch(query), 420);
    });

    bindCrumbNav();
    wireUploadDrop(container);

    // infinite scroll
    const main = document.getElementById("view");
    state.scrollHandler = () => {
      if (!state.hasMore || state.loading) return;
      if (main.scrollTop + main.clientHeight >= main.scrollHeight - 240) load({ append: true });
    };
    main?.addEventListener("scroll", state.scrollHandler, { passive: true });
  },
  unmount() {
    const main = document.getElementById("view");
    if (main && state.scrollHandler) main.removeEventListener("scroll", state.scrollHandler);
    state.scrollHandler = null;
    state.entries = [];
    state.search = null;
  },
};
