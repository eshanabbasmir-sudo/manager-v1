/** Package management through the system's own package manager. */
import { api } from "../api.js";
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc, bytes } from "../ui.js";

const state = {
  tab: "search",
  backend: null,
  results: [],
  installed: [],
  installedTotal: 0,
  query: "",
  filter: "",
  jobTimer: null,
  loading: false,
};

function backendNotice() {
  const b = state.backend;
  if (!b) return "";
  if (!b.ok) {
    return `<div class="notice danger">${icon("alert")}<div><b>${esc(b.kind)} is not fully usable.</b>
      ${esc(b.note || "Required tools are missing.")}</div></div>`;
  }
  return "";
}

function searchRows() {
  if (state.loading) return ui.skeletonRows(4, 46);
  if (!state.results.length) {
    return ui.emptyState(state.query ? "No matching packages" : "Search for a package to install", "box");
  }
  return `<div class="list">${state.results
    .map(
      (p) => `<div class="list-row" style="cursor:default">
        <span class="lead">${icon("box")}</span>
        <span class="grow truncate">
          <span class="title truncate">${esc(p.name)} ${p.installed ? '<span class="badge ok">installed</span>' : ""}</span>
          <span class="meta truncate"><span>${esc(p.description || "")}</span></span>
        </span>
        ${p.installed
          ? `<button class="btn btn-sm" data-remove="${esc(p.name)}">${icon("trash")}Remove</button>`
          : `<button class="btn btn-sm btn-primary" data-install="${esc(p.name)}">${icon("download")}Install</button>`}
      </div>`,
    )
    .join("")}</div>`;
}

function installedRows() {
  const needle = state.filter.toLowerCase();
  const items = state.installed.filter((p) => !needle || p.name.toLowerCase().includes(needle));
  if (!items.length) return ui.emptyState("No packages found", "box");
  return `<div class="list">${items
    .slice(0, 400)
    .map(
      (p) => `<div class="list-row" style="cursor:default">
        <span class="lead">${icon("box")}</span>
        <span class="grow truncate">
          <span class="title truncate">${esc(p.name)}</span>
          <span class="meta"><span class="mono">${esc(p.version || "")}</span>${p.size_kb ? `<span>${bytes(p.size_kb * 1024)}</span>` : ""}</span>
        </span>
        <button class="btn btn-sm" data-remove="${esc(p.name)}">${icon("trash")}Remove</button>
      </div>`,
    )
    .join("")}</div>
    <div class="faint" style="text-align:center;font-size:12px;margin-top:10px">
      ${items.length} shown · ${state.installedTotal} installed
    </div>`;
}

function shell() {
  return `<div class="view-enter">
    ${backendNotice()}
    <div class="card" style="margin-top:0">
      <div class="card-head">
        <div class="card-title-icon">${icon("box")}</div>
        <div><h3>Packages</h3>
          <div class="sub">${esc(state.backend?.kind || "detecting…")} backend · ${
            state.backend?.ok ? "ready" : "limited"}</div></div>
        <div class="spacer"></div>
        <button class="btn btn-sm" id="pkg-upgrade" title="Upgrade all packages">
          ${icon("arrowUp")}Upgrade all
        </button>
      </div>
      <div class="tabs" id="pkg-tabs">
        <button class="tab ${state.tab === "search" ? "active" : ""}" data-tab="search">Search</button>
        <button class="tab ${state.tab === "installed" ? "active" : ""}" data-tab="installed">Installed</button>
      </div>
      ${state.tab === "search"
        ? `<div class="toolbar">
            <div class="search">${icon("search")}
              <input class="input" id="pkg-query" placeholder="Package name, e.g. nginx"
                     value="${esc(state.query)}" autocomplete="off" enterkeyhint="search"></div>
            <button class="btn btn-sm" id="pkg-search">${icon("search")}Search</button>
          </div>
          <div id="pkg-list">${searchRows()}</div>`
        : `<div class="toolbar">
            <div class="search">${icon("search")}
              <input class="input" id="pkg-filter" placeholder="Filter installed packages"
                     value="${esc(state.filter)}" autocomplete="off"></div>
            <button class="btn btn-sm" id="pkg-reload">${icon("refresh")}Reload</button>
          </div>
          <div id="pkg-list">${installedRows()}</div>`}
    </div>
    <div id="pkg-job" style="margin-top:16px"></div>
    <div class="notice info" style="margin-top:16px">${icon("info")}
      <div>Package operations run the real package manager with <span class="mono">-y</span> and are
      executed in the background; output streams below. They need root (or passwordless sudo).</div></div>
  </div>`;
}

async function loadInstalled(container) {
  const host = document.getElementById("pkg-list");
  if (host) host.innerHTML = ui.skeletonRows(5, 46);
  try {
    const data = await api.get("/api/packages");
    state.backend = data.backend;
    state.installed = data.items;
    state.installedTotal = data.total;
    if (host) host.innerHTML = installedRows();
  } catch (err) {
    state.installed = [];
    if (host) host.innerHTML = `<div class="notice danger">${icon("alert")}<div>${esc(ui.errorText(err))}</div></div>`;
  }
}

async function doSearch() {
  const input = document.getElementById("pkg-query");
  state.query = (input?.value || state.query || "").trim();
  if (state.query.length < 2) {
    ui.notifyWarn("Search", "Enter at least 2 characters.");
    return;
  }
  state.loading = true;
  const host = document.getElementById("pkg-list");
  if (host) host.innerHTML = searchRows();
  try {
    const data = await api.get("/api/packages/search", { q: state.query });
    state.backend = data.backend;
    state.results = data.items;
    state.loading = false;
    if (host) host.innerHTML = searchRows() || "";
    if (!data.items.length) {
      ui.notifyInfo("No results", data.stderr ? data.stderr.slice(0, 160) : "Nothing matched that name.");
    }
  } catch (err) {
    state.loading = false;
    state.results = [];
    if (host) host.innerHTML = `<div class="notice danger">${icon("alert")}<div>${esc(ui.errorText(err))}</div></div>`;
  }
}

async function runPackageAction(action, names, container) {
  if (!names.length) return;
  const label = action === "upgrade"
    ? "Upgrade all packages?"
    : `${action === "install" ? "Install" : "Remove"} ${names.join(", ")}?`;
  const ok = await ui.confirmDialog({
    title: label,
    message: action === "remove"
      ? "Removing a package can break dependent software."
      : "The package manager will download and apply changes.",
    confirmLabel: action === "install" ? "Install" : action === "remove" ? "Remove" : "Upgrade",
    danger: action !== "install",
  });
  if (!ok) return;
  try {
    const { job } = await api.post("/api/packages/action", { names, action });
    const host = document.getElementById("pkg-job");
    if (host) {
      host.innerHTML = `<div class="card">
        <div class="card-head"><div class="card-title-icon">${icon("box")}</div>
          <div><h3>${esc(action)}</h3><div class="sub mono truncate">${esc(job.command)}</div></div>
          <div class="spacer"></div>
          <button class="btn btn-sm btn-danger" id="pkg-cancel">${icon("stop")}Cancel</button>
        </div>
        <pre class="code-out" id="pkg-out">starting…</pre></div>`;
      document.getElementById("pkg-cancel")?.addEventListener("click", async () => {
        try {
          await api.post(`/api/jobs/${job.id}/cancel`);
          ui.notifyWarn("Cancelling", "Sent a termination signal to the package manager");
        } catch (err) {
          ui.showError(err, "Could not cancel");
        }
      });
    }
    pollJob(job.id, container);
  } catch (err) {
    ui.showError(err, "Package operation failed");
  }
}

function pollJob(jobId, container) {
  clearInterval(state.jobTimer);
  state.jobTimer = setInterval(async () => {
    try {
      const job = await api.get(`/api/jobs/${jobId}`);
      const out = document.getElementById("pkg-out");
      if (out) {
        out.textContent = `${job.output || ""}${job.error ? `\n${job.error}` : ""}` || "starting…";
        out.scrollTop = out.scrollHeight;
      }
      if (!job.running) {
        clearInterval(state.jobTimer);
        state.jobTimer = null;
        const cancelBtn = document.getElementById("pkg-cancel");
        if (cancelBtn) cancelBtn.remove();
        if (job.exit_code === 0) ui.notifyOk("Finished", `${job.label} completed`);
        else ui.notifyErr("Command failed", `exit code ${job.exit_code}`);
        if (state.tab === "installed") loadInstalled(container);
        if (state.query) doSearch();
      }
    } catch {
      clearInterval(state.jobTimer);
      state.jobTimer = null;
    }
  }, 1000);
}

export default {
  title: "Packages",
  crumb: "real package manager",
  async mount(container, ctx) {
    try {
      const data = await api.get("/api/packages");
      state.backend = data.backend;
      state.installed = data.items;
      state.installedTotal = data.total;
    } catch (err) {
      container.innerHTML = `<div class="card">${ui.emptyState(ui.errorText(err), "alert")}</div>`;
      return;
    }
    container.innerHTML = shell();

    container.addEventListener("click", (event) => {
      const tab = event.target.closest("[data-tab]");
      if (tab) {
        state.tab = tab.dataset.tab;
        container.innerHTML = shell();
        if (state.tab === "installed") loadInstalled(container);
        if (state.tab === "search" && state.results.length) {
          const host = document.getElementById("pkg-list");
          if (host) host.innerHTML = searchRows();
        }
        return;
      }
      if (event.target.closest("#pkg-search")) {
        doSearch();
        return;
      }
      if (event.target.closest("#pkg-reload")) {
        loadInstalled(container);
        return;
      }
      if (event.target.closest("#pkg-upgrade")) {
        runPackageAction("upgrade", [], container);
        return;
      }
      const install = event.target.closest("[data-install]");
      if (install) {
        runPackageAction("install", [install.dataset.install], container);
        return;
      }
      const remove = event.target.closest("[data-remove]");
      if (remove) runPackageAction("remove", [remove.dataset.remove], container);
    });

    container.addEventListener("keydown", (event) => {
      if (event.target.id === "pkg-query" && event.key === "Enter") doSearch();
    });
    container.addEventListener("input", (event) => {
      if (event.target.id === "pkg-filter") {
        state.filter = event.target.value;
        const host = document.getElementById("pkg-list");
        if (host) host.innerHTML = installedRows();
      }
    });
  },
  unmount() {
    if (state.jobTimer) clearInterval(state.jobTimer);
    state.jobTimer = null;
  },
};
