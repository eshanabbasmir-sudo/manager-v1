/** Dashboard — live values pulled from /api/system/overview (real /proc data). */
import { api } from "../api.js";
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc, bytes, rate, duration, timestamp } from "../ui.js";

const history = { cpu: [], mem: [], rx: [], tx: [] };
const MAX_POINTS = 60;

let timer = null;
let root = null;
let ctxRef = null;

function ringClass(value) {
  return value >= 90 ? "danger" : value >= 75 ? "warn" : "ok";
}

function coreBars(cores) {
  if (!cores || !cores.length) return "";
  return `<div class="core-grid">${cores
    .slice(0, 64)
    .map(
      (value) => `<div class="core" title="${value.toFixed(1)}%">
        <i style="height:${Math.max(2, Math.min(100, value))}%"></i></div>`,
    )
    .join("")}</div>`;
}

function template(data) {
  const { os, cpu, memory, disk, network, capabilities, panel, thermal } = data;
  const container = capabilities.container || {};
  const cg = capabilities.cgroup || {};
  const diskItems = (disk.items || []).slice(0, 6);
  const ifaces = (network.interfaces || []).filter((i) => i.name !== "lo");

  return `
  <div class="grid cols-2">
    <div class="card span-2">
      <div class="row wrap" style="gap:18px;align-items:flex-start">
        <div class="grow" style="min-width:220px">
          <div class="metric-label">${container.is_container ? "container host" : "server"}</div>
          <div class="row" style="gap:10px;margin:6px 0 10px">
            <h2 style="margin:0;font-size:22px;letter-spacing:-.02em" class="truncate">${esc(os.hostname)}</h2>
            <span class="badge accent">${esc(os.arch)}</span>
          </div>
          <div class="row wrap" style="gap:8px">
            <span class="badge">${esc(os.distro)}</span>
            <span class="badge">kernel ${esc(os.kernel)}</span>
            ${container.is_container
              ? `<span class="badge warn">${esc(container.kind || "container")}</span>`
              : `<span class="badge ok">host</span>`}
            ${panel && panel.root ? `<span class="badge warn">running as root</span>` : ""}
            <span class="badge"><span class="dot" style="color:var(--ok)"></span>panel up ${esc(duration(panel?.uptime_seconds))}</span>
          </div>
        </div>
        <div class="row" style="gap:22px;flex-wrap:wrap">
          <div class="stat-mini"><div class="v mono">${esc(duration(os.uptime_seconds))}</div><div class="l">uptime</div></div>
          <div class="stat-mini"><div class="v mono">${cpu.logical_cores}</div><div class="l">cpu cores</div></div>
          <div class="stat-mini"><div class="v mono">${bytes(memory.total, 0)}</div><div class="l">memory</div></div>
          <div class="stat-mini"><div class="v mono">${esc((network.primary_ip || "—"))}</div><div class="l">primary ip</div></div>
        </div>
      </div>
      ${container.is_container ? `
      <div class="notice" style="margin-top:14px">${icon("info")}
        <div><b>Running inside ${esc(container.kind || "a container")}.</b>
        CPU, memory and disk figures come from the kernel visible to this
        container. ${cg.memory_limit_bytes
          ? `The container limit is ${bytes(cg.memory_limit_bytes)}${cg.cpu_quota_cores ? ` and ${cg.cpu_quota_cores} CPU cores` : ""}.`
          : "No cgroup memory limit is set, so totals may be the host's."}
        ${esc(container.evidence?.[0] || "")}</div>
      </div>` : ""}
    </div>

    <div class="card" id="card-cpu">
      <div class="card-head">
        <div class="card-title-icon">${icon("cpu")}</div>
        <div><h3>Processor</h3><div class="sub truncate">${esc(cpu.model)}</div></div>
        <div class="spacer"></div>
        <span class="badge" id="cpu-clock">${cpu.clock_mhz ? `${Math.round(cpu.clock_mhz)} MHz` : "—"}</span>
      </div>
      <div class="row" style="align-items:center;gap:18px">
        <div class="ring" id="cpu-ring" style="--val:${cpu.usage_percent}">
          <span id="cpu-pct">${Math.round(cpu.usage_percent)}%</span>
        </div>
        <div class="grow" style="min-width:0">
          <div class="row between" style="font-size:12.5px">
            <span class="faint">Load average</span>
            <span class="mono" id="cpu-load">${cpu.load["1m"].toFixed(2)} · ${cpu.load["5m"].toFixed(2)} · ${cpu.load["15m"].toFixed(2)}</span>
          </div>
          <div style="margin-top:8px" id="cpu-spark">${ui.sparkline(history.cpu, { height: 40 })}</div>
        </div>
      </div>
      <div id="cpu-cores">${coreBars(cpu.cores)}</div>
      <div class="row between" style="margin-top:10px;font-size:12px">
        <span class="faint">${cpu.logical_cores} logical · ${cpu.physical_cores} physical</span>
        <span class="faint mono">${esc(cpu.load.runnable || "")} runnable</span>
      </div>
    </div>

    <div class="card" id="card-mem">
      <div class="card-head">
        <div class="card-title-icon">${icon("memory")}</div>
        <div><h3>Memory</h3><div class="sub">MemTotal from /proc/meminfo</div></div>
      </div>
      <div class="metric-value" id="mem-value">${bytes(memory.used)} <small>/ ${bytes(memory.total)}</small></div>
      <div class="bar ${ringClass(memory.percent)}" style="margin:12px 0 10px">
        <i id="mem-bar" style="width:${memory.percent}%"></i>
      </div>
      <div class="row between" style="font-size:12.5px">
        <span class="faint">Available <b class="mono" id="mem-avail" style="color:var(--text)">${bytes(memory.available)}</b></span>
        <span class="faint" id="mem-pct">${memory.percent.toFixed(1)}% used</span>
      </div>
      <div style="margin-top:12px" id="mem-spark">${ui.sparkline(history.mem, { height: 36, color: "var(--accent-2)" })}</div>
      <dl class="kv" style="margin-top:12px">
        <dt>Swap</dt><dd>${memory.swap_total ? `${bytes(memory.swap_used)} / ${bytes(memory.swap_total)}` : "not configured"}</dd>
        <dt>Buffers / cache</dt><dd>${bytes(memory.buffers + memory.cached)}</dd>
        ${memory.container_limit ? `<dt>Container limit</dt><dd>${bytes(memory.container_limit)}${memory.container_percent !== null ? ` (${memory.container_percent.toFixed(1)}%)` : ""}</dd>` : ""}
      </dl>
    </div>

    <div class="card">
      <div class="card-head">
        <div class="card-title-icon">${icon("hardDrive")}</div>
        <div><h3>Storage</h3><div class="sub">${(disk.items || []).length} mounted filesystems</div></div>
      </div>
      <div id="disk-rows">
      ${diskItems.map((d) => `
        <div class="disk-row">
          <div class="row between">
            <span class="mono truncate" style="font-size:12.5px">${esc(d.mount)}</span>
            <span class="faint mono" style="font-size:12px">${bytes(d.used)} / ${bytes(d.total)}</span>
          </div>
          <div class="bar thin ${ringClass(d.percent)}"><i style="width:${d.percent}%"></i></div>
          <div class="row between faint" style="font-size:11px">
            <span>${esc(d.fstype)} · ${esc(d.device)}</span>
            <span>${d.percent.toFixed(0)}% · ${bytes(d.free)} free</span>
          </div>
        </div>`).join("") || ui.emptyState("No filesystems reported", "hardDrive")}
      </div>
    </div>

    <div class="card">
      <div class="card-head">
        <div class="card-title-icon">${icon("network")}</div>
        <div><h3>Network</h3><div class="sub">${esc(network.hostname)}${network.gateways?.[0]?.gateway ? ` · gw ${esc(network.gateways[0].gateway)}` : ""}</div></div>
      </div>
      <div class="row" style="gap:16px">
        <div class="stat-mini grow"><div class="v mono" id="net-rx">${rate(network.total.rx_rate)}</div><div class="l">${icon("arrowDown", 11)} download</div></div>
        <div class="stat-mini grow"><div class="v mono" id="net-tx">${rate(network.total.tx_rate)}</div><div class="l">${icon("arrowUp", 11)} upload</div></div>
      </div>
      <div style="margin:10px 0 4px" id="net-spark">${ui.sparkline(history.rx, { height: 38, color: "var(--ok)" })}</div>
      <div class="stack" style="margin-top:8px">
        ${ifaces.map((i) => `
          <div class="row between" style="font-size:12.5px;gap:8px">
            <span class="row truncate" style="gap:8px">
              <span class="dot" style="color:${i.state === "up" ? "var(--ok)" : "var(--text-faint)"}"></span>
              <b>${esc(i.name)}</b>
              <span class="faint mono truncate">${esc(i.addresses?.[0] || "no address")}</span>
            </span>
            <span class="faint mono" style="font-size:11.5px">↓${rate(i.rx_rate)} ↑${rate(i.tx_rate)}</span>
          </div>`).join("") || ui.emptyState("No interfaces", "network")}
      </div>
      <div class="row between faint" style="margin-top:10px;font-size:11.5px">
        <span>total ↓ ${bytes(network.total.rx_bytes)} · ↑ ${bytes(network.total.tx_bytes)}</span>
        <span>DNS ${esc((network.dns || []).slice(0, 2).join(", ") || "—")}</span>
      </div>
    </div>

    <div class="card">
      <div class="card-head">
        <div class="card-title-icon">${icon("server")}</div>
        <div><h3>System</h3><div class="sub">kernel &amp; platform facts</div></div>
      </div>
      <dl class="kv">
        <dt>Distribution</dt><dd>${esc(os.distro)}</dd>
        <dt>Kernel</dt><dd class="mono">${esc(os.kernel)}</dd>
        <dt>Architecture</dt><dd>${esc(os.arch)}</dd>
        <dt>Booted</dt><dd>${esc(timestamp(os.boot_time, "long"))}</dd>
        <dt>Python</dt><dd class="mono">${esc(os.python)}</dd>
        <dt>Privilege</dt><dd>${capabilities.is_root ? "root" : esc(capabilities.effective_user)}</dd>
        <dt>Service manager</dt><dd>${capabilities.systemd ? "systemd" : "unavailable"}</dd>
        <dt>Package manager</dt><dd>${esc(capabilities.package_manager || "none")}</dd>
        ${thermal && thermal.length ? `<dt>Temperature</dt><dd>${thermal.map((t) => `${t.celsius}°C`).join(", ")}</dd>` : ""}
      </dl>
    </div>

    <div class="card">
      <div class="card-head">
        <div class="card-title-icon">${icon("activity")}</div>
        <div><h3>Top processes</h3><div class="sub">sorted by CPU</div></div>
        <div class="spacer"></div>
        <button class="btn btn-sm btn-ghost" data-goto="processes">All ${icon("chevronRight", 14)}</button>
      </div>
      <div class="list" id="top-procs">${ui.skeletonRows(4, 32)}</div>
    </div>

    <div class="card">
      <div class="card-head">
        <div class="card-title-icon">${icon("shield")}</div>
        <div><h3>Panel status</h3><div class="sub">PRIME TERMINAL ${esc(panel?.version || "")}</div></div>
      </div>
      <dl class="kv">
        <dt>Process</dt><dd class="mono">pid ${esc(panel?.pid ?? "—")}</dd>
        <dt>Running as</dt><dd>${esc(panel?.user || "—")}</dd>
        <dt>Panel uptime</dt><dd>${esc(duration(panel?.uptime_seconds))}</dd>
        <dt>Memory (RSS)</dt><dd>${bytes(panel?.rss || 0)}</dd>
        <dt>Terminal sessions</dt><dd>${esc(panel?.sessions ?? 0)}</dd>
        <dt>Data directory</dt><dd class="mono truncate" style="font-size:11.5px">${esc(panel?.data_dir || "")}</dd>
        <dt>File roots</dt><dd class="mono truncate" style="font-size:11.5px">${esc((panel?.allowed_roots || []).join(", "))}</dd>
      </dl>
    </div>
  </div>`;
}

function pushHistory(data) {
  history.cpu.push(data.cpu.usage_percent);
  history.mem.push(data.memory.percent);
  history.rx.push(data.network.total.rx_rate);
  history.tx.push(data.network.total.tx_rate);
  Object.values(history).forEach((arr) => {
    if (arr.length > MAX_POINTS) arr.splice(0, arr.length - MAX_POINTS);
  });
}

function update(data) {
  if (!root) return;
  const { cpu, memory, network, panel, disk } = data;

  const ring = root.querySelector("#cpu-ring");
  if (ring) {
    ring.style.setProperty("--val", cpu.usage_percent);
    const label = root.querySelector("#cpu-pct");
    if (label) label.textContent = `${Math.round(cpu.usage_percent)}%`;
  }
  const load = root.querySelector("#cpu-load");
  if (load) {
    load.textContent = `${cpu.load["1m"].toFixed(2)} · ${cpu.load["5m"].toFixed(2)} · ${cpu.load["15m"].toFixed(2)}`;
  }
  const cores = root.querySelector("#cpu-cores");
  if (cores) {
    cores.innerHTML = coreBars(cpu.cores);
  }
  const clock = root.querySelector("#cpu-clock");
  if (clock && cpu.clock_mhz) clock.textContent = `${Math.round(cpu.clock_mhz)} MHz`;
  const cpuSpark = root.querySelector("#cpu-spark");
  if (cpuSpark) cpuSpark.innerHTML = ui.sparkline(history.cpu, { height: 40 });

  const memValue = root.querySelector("#mem-value");
  if (memValue) memValue.innerHTML = `${bytes(memory.used)} <small>/ ${bytes(memory.total)}</small>`;
  const memBar = root.querySelector("#mem-bar");
  if (memBar) {
    memBar.style.width = `${memory.percent}%`;
    memBar.parentElement.className = `bar ${ringClass(memory.percent)}`;
  }
  const memAvail = root.querySelector("#mem-avail");
  if (memAvail) memAvail.textContent = bytes(memory.available);
  const memPctEl = root.querySelector("#mem-pct");
  if (memPctEl) memPctEl.textContent = `${memory.percent.toFixed(1)}% used`;
  const memSpark = root.querySelector("#mem-spark");
  if (memSpark) memSpark.innerHTML = ui.sparkline(history.mem, { height: 36, color: "var(--accent-2)" });

  const rx = root.querySelector("#net-rx");
  if (rx) rx.textContent = rate(network.total.rx_rate);
  const tx = root.querySelector("#net-tx");
  if (tx) tx.textContent = rate(network.total.tx_rate);
  const netSpark = root.querySelector("#net-spark");
  if (netSpark) netSpark.innerHTML = ui.sparkline(history.rx, { height: 38, color: "var(--ok)" });

  const hostLabel = document.querySelector("#sidebar-host");
  if (hostLabel) {
    hostLabel.textContent = `${data.os.hostname} · ${data.os.arch}`;
  }
}

async function refreshProcs() {
  if (!root || !ctxRef) return;
  try {
    const data = await api.get("/api/system/processes", { limit: 6, sort: "cpu" });
    const host = root.querySelector("#top-procs");
    if (!host) return;
    host.innerHTML = data.items
      .map(
        (p) => `<button class="list-row" data-pid="${p.pid}" type="button">
          <span class="lead">${icon("activity")}</span>
          <span class="grow truncate">
            <span class="title truncate">${esc(p.name)}<span class="faint mono" style="font-size:11px">#${p.pid}</span></span>
            <span class="meta truncate"><span>${esc(p.user)}</span><span class="mono">cpu ${p.cpu.toFixed(1)}%</span><span class="mono">mem ${bytes(p.mem)}</span></span>
          </span>
          ${icon("chevronRight", 16)}
        </button>`,
      )
      .join("") || ui.emptyState("No processes", "activity");
  } catch { /* keep previous list */ }
}

async function tick() {
  if (document.hidden) return;
  try {
    const data = await api.get("/api/system/overview");
    pushHistory(data);
    update(data);
  } catch (err) {
    if (err.status === 401) return;
    console.warn("dashboard refresh failed", err);
  }
}

export default {
  title: "Dashboard",
  crumb: "live system overview",
  async mount(container, ctx) {
    root = container;
    ctxRef = ctx;
    container.innerHTML = ui.skeletonRows(3, 120);
    let data;
    try {
      data = await api.get("/api/system/overview");
    } catch (err) {
      container.innerHTML = `<div class="card">${ui.emptyState(ui.errorText(err), "alert")}</div>`;
      throw err;
    }
    pushHistory(data);
    container.innerHTML = `<div class="view-enter">${template(data)}</div>`;
    update(data);
    refreshProcs();

    container.addEventListener("click", (event) => {
      if (event.target.closest("[data-goto]")) {
        ctx.navigate(event.target.closest("[data-goto]").dataset.goto);
        return;
      }
      const row = event.target.closest("[data-pid]");
      if (row && ctx.navigate) ctx.navigate("processes");
    });

    const procInterval = setInterval(refreshProcs, 5000);
    timer = setInterval(tick, 2000);
    this._procInterval = procInterval;
  },
  unmount() {
    if (timer) clearInterval(timer);
    if (this._procInterval) clearInterval(this._procInterval);
    timer = null;
    root = null;
    ctxRef = null;
  },
};
