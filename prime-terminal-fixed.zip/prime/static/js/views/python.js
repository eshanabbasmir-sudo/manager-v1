/** Run Python on the server: writes a temp script and executes the real interpreter. */
import { api } from "../api.js";
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc } from "../ui.js";

const SAMPLE = `import os, platform, shutil, socket

print("host:", socket.gethostname())
print("python:", platform.python_version())
print("cwd:", os.getcwd())
total, used, free = shutil.disk_usage("/")
print(f"disk: {used // 2**30} GiB used of {total // 2**30} GiB")

# This runs on the real server with the panel's privileges.
`;

const state = { cwd: "", filename: "script.py", args: "", running: false };

function shell() {
  return `<div class="view-enter">
    <div class="card">
      <div class="card-head">
        <div class="card-title-icon">${icon("code")}</div>
        <div><h3>Python runner</h3>
          <div class="sub">executes on the server as the panel user</div></div>
        <div class="spacer"></div>
        <button class="btn btn-sm btn-primary" id="py-run">${icon("play")}Run</button>
      </div>
      <div class="field-row" style="margin-bottom:12px">
        <div class="field" style="flex:2 1 200px">
          <label>File name</label>
          <input class="input mono" id="py-filename" value="${esc(state.filename)}" spellcheck="false">
        </div>
        <div class="field" style="flex:3 1 220px">
          <label>Working directory</label>
          <input class="input mono" id="py-cwd" value="${esc(state.cwd)}" placeholder="panel data directory" spellcheck="false">
        </div>
        <div class="field" style="flex:1 1 140px">
          <label>Arguments</label>
          <input class="input mono" id="py-args" value="${esc(state.args)}" placeholder="--flag value" spellcheck="false">
        </div>
      </div>
      <textarea class="fm-editor" id="py-code" spellcheck="false" style="min-height:38vh">${esc(SAMPLE)}</textarea>
      <div class="row between faint" style="font-size:11.5px;margin-top:8px">
        <span id="py-meta">Ctrl/⌘+Enter to run</span>
        <span class="mono">timeout 30s</span>
      </div>
    </div>
    <div class="card" id="py-result-card" style="margin-top:16px;display:none">
      <div class="card-head">
        <div class="card-title-icon" id="py-result-icon">${icon("terminal")}</div>
        <div><h3 id="py-result-title">Output</h3><div class="sub" id="py-result-sub"></div></div>
        <div class="spacer"></div>
        <button class="btn btn-sm btn-ghost" id="py-clear">${icon("x")}Clear</button>
      </div>
      <pre class="code-out" id="py-out"></pre>
    </div>
    <div class="notice info" style="margin-top:16px">${icon("info")}
      <div>The script is written to a temporary directory and executed with
      <span class="mono">python3 -u</span>; stdout and stderr are captured. It has exactly the
      privileges the panel process has — nothing more.</div></div>
  </div>`;
}

async function run() {
  const code = document.getElementById("py-code").value;
  const filename = document.getElementById("py-filename").value.trim() || "script.py";
  const cwd = document.getElementById("py-cwd").value.trim();
  const args = document.getElementById("py-args").value.trim();
  const button = document.getElementById("py-run");
  if (!code.trim()) {
    ui.notifyWarn("Nothing to run", "The editor is empty.");
    return;
  }
  state.filename = filename;
  state.cwd = cwd;
  state.args = args;
  button.disabled = true;
  button.innerHTML = `<span class="spinner"></span>Running…`;
  const card = document.getElementById("py-result-card");
  const out = document.getElementById("py-out");
  card.style.display = "";
  out.textContent = "running…";
  try {
    const result = await api.post("/api/python/run", {
      code,
      filename,
      cwd: cwd || null,
      args: args ? args.split(/\s+/).filter(Boolean) : [],
    });
    const text = [result.stdout, result.stderr].filter(Boolean).join("\n");
    out.textContent = text || "(no output)";
    document.getElementById("py-result-title").textContent = result.ok ? "Output" : "Command failed";
    document.getElementById("py-result-sub").textContent =
      `exit ${result.code} · ${result.duration}s · ${result.script_path || ""}`;
    document.getElementById("py-result-icon").innerHTML = icon(result.ok ? "check" : "alert");
    if (result.ok) ui.notifyOk("Script finished", `${result.duration}s`);
    else ui.notifyErr("Script exited with an error", `exit code ${result.code}`);
  } catch (err) {
    out.textContent = ui.errorText(err);
    document.getElementById("py-result-title").textContent = "Request failed";
    document.getElementById("py-result-sub").textContent = "";
    ui.showError(err, "Could not run the script");
  } finally {
    button.disabled = false;
    button.innerHTML = `${icon("play")}Run`;
  }
}

export default {
  title: "Python",
  crumb: "execute scripts on the server",
  async mount(container, ctx) {
    container.innerHTML = shell();
    const code = document.getElementById("py-code");
    code.addEventListener("keydown", (event) => {
      if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
        event.preventDefault();
        run();
      }
      if (event.key === "Tab") {
        event.preventDefault();
        const start = code.selectionStart;
        code.value = `${code.value.slice(0, start)}    ${code.value.slice(code.selectionEnd)}`;
        code.selectionStart = code.selectionEnd = start + 4;
      }
    });
    document.getElementById("py-run").addEventListener("click", run);
    document.getElementById("py-clear").addEventListener("click", () => {
      document.getElementById("py-result-card").style.display = "none";
    });
  },
  unmount() {},
};
