/** UI primitives: toasts, sheets, dialogs, formatting and small DOM helpers. */
import { icon } from "./icons.js";

/* ------------------------------------------------------------------ escape */
export function esc(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export function el(tag, attrs = {}, html = "") {
  const node = document.createElement(tag);
  Object.entries(attrs).forEach(([k, v]) => {
    if (v === null || v === undefined || v === false) return;
    if (k === "class") node.className = v;
    else if (k === "dataset") Object.assign(node.dataset, v);
    else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2), v);
    else node.setAttribute(k, v === true ? "" : v);
  });
  if (html) node.innerHTML = html;
  return node;
}

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

/* ------------------------------------------------------------------ format */
export function bytes(n, digits = 1) {
  if (n === null || n === undefined || Number.isNaN(n)) return "—";
  if (n < 1) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB", "PB"];
  const i = Math.min(units.length - 1, Math.floor(Math.log(n) / Math.log(1024)));
  const value = n / 1024 ** i;
  return `${value.toFixed(i === 0 ? 0 : digits)} ${units[i]}`;
}

export function rate(bytesPerSec) {
  if (!bytesPerSec || bytesPerSec < 1) return "0 B/s";
  return `${bytes(bytesPerSec)}/s`;
}

export function duration(seconds) {
  if (seconds === null || seconds === undefined) return "—";
  seconds = Math.max(0, Math.floor(seconds));
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (d) return `${d}d ${h}h`;
  if (h) return `${h}h ${m}m`;
  if (m) return `${m}m ${s}s`;
  return `${s}s`;
}

export function timestamp(ts, style = "short") {
  if (!ts) return "—";
  const date = new Date(ts * 1000);
  const sameYear = date.getFullYear() === new Date().getFullYear();
  const opts = style === "long"
    ? { dateStyle: "medium", timeStyle: "medium" }
    : { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" };
  if (style === "short" && sameYear) opts.year = undefined;
  return date.toLocaleString(undefined, opts);
}

export function ago(ts) {
  if (!ts) return "—";
  const diff = Date.now() / 1000 - ts;
  if (diff < 5) return "just now";
  if (diff < 60) return `${Math.floor(diff)}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  if (diff < 2592000) return `${Math.floor(diff / 86400)}d ago`;
  return timestamp(ts);
}

export function levelClass(percent) {
  if (percent >= 90) return "danger";
  if (percent >= 75) return "warn";
  return "ok";
}

export function pct(value) {
  const n = Number(value || 0);
  return `${Math.max(0, Math.min(100, n)).toFixed(0)}%`;
}

/* ------------------------------------------------------------------- toast */
const TOAST_ICONS = { ok: "check", err: "alert", warn: "alert", info: "info" };

export function toast(type, title, message = "", timeout = 4200) {
  const host = $("#toasts");
  if (!host) return;
  const node = el("div", { class: `toast ${type}`, role: "status" });
  node.innerHTML = `${icon(TOAST_ICONS[type] || "info")}
    <div class="msg"><b>${esc(title)}</b>${message ? `<span>${esc(message)}</span>` : ""}</div>`;
  host.appendChild(node);
  const remove = () => {
    node.classList.add("out");
    setTimeout(() => node.remove(), 220);
  };
  node.addEventListener("click", remove);
  const timer = setTimeout(remove, timeout);
  node.addEventListener("mouseenter", () => clearTimeout(timer), { once: true });
  return node;
}

export const notifyOk = (t, m) => toast("ok", t, m);
export const notifyErr = (t, m) => toast("err", t, m);
export const notifyWarn = (t, m) => toast("warn", t, m);
export const notifyInfo = (t, m) => toast("info", t, m);

/* ------------------------------------------------------------------ sheets */
let openSheets = [];

export function closeSheet(sheet) {
  if (!sheet || sheet.closed) return;
  sheet.closed = true;
  sheet.overlay.classList.add("closing");
  const done = () => {
    sheet.overlay.remove();
    openSheets = openSheets.filter((s) => s !== sheet);
    if (typeof sheet.onClose === "function") sheet.onClose();
    if (!openSheets.length) document.body.style.removeProperty("overflow");
  };
  setTimeout(done, 200);
}

export function closeTopSheet() {
  if (openSheets.length) closeSheet(openSheets[openSheets.length - 1]);
}

/**
 * Open a modal (desktop) / bottom sheet (mobile).
 * @returns {{close:Function, root:HTMLElement, body:HTMLElement}}
 */
export function sheet({
  title = "",
  subtitle = "",
  content = "",
  actions = [],
  wide = false,
  tall = false,
  className = "",
  dismissible = true,
  onMount,
  onClose,
} = {}) {
  const overlay = el("div", { class: "overlay", role: "dialog", "aria-modal": "true" });
  const card = el("div", {
    class: `sheet ${wide ? "wide" : ""} ${tall ? "tall" : ""} ${className}`,
  });
  card.innerHTML = `<div class="grabber"></div>
    <div class="sheet-head">
      <div class="grow">
        ${title ? `<h3>${esc(title)}</h3>` : ""}
        ${subtitle ? `<p>${esc(subtitle)}</p>` : ""}
      </div>
      ${dismissible ? `<button class="icon-btn" data-close aria-label="Close">${icon("x")}</button>` : ""}
    </div>
    <div class="sheet-body"></div>
    <div class="sheet-foot"></div>`;
  const body = card.querySelector(".sheet-body");
  if (typeof content === "string") body.innerHTML = content;
  else if (content) body.appendChild(content);

  const foot = card.querySelector(".sheet-foot");
  const sheetObj = { overlay, card, body, foot, closed: false, onClose };
  actions.forEach((action) => {
    const button = el("button", {
      class: `btn ${action.kind === "primary" ? "btn-primary" : ""} ${
        action.kind === "danger" ? "btn-danger" : ""} ${action.kind === "ghost" ? "btn-ghost" : ""}`,
      type: "button",
    }, `${action.icon ? icon(action.icon) : ""}${esc(action.label)}`);
    button.addEventListener("click", async () => {
      if (typeof action.onClick === "function") {
        const result = await action.onClick({ sheet: sheetObj, button, close: () => closeSheet(sheetObj) });
        if (result === false) return;
      }
      if (action.close !== false) closeSheet(sheetObj);
    });
    foot.appendChild(button);
  });
  if (!actions.length) foot.remove();

  overlay.appendChild(card);
  const onKey = (event) => {
    if (event.key === "Escape" && dismissible) {
      event.preventDefault();
      closeSheet(sheetObj);
    }
  };
  document.addEventListener("keydown", onKey);
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay && dismissible) closeSheet(sheetObj);
  });
  card.querySelectorAll("[data-close]").forEach((btn) => {
    btn.addEventListener("click", () => closeSheet(sheetObj));
  });
  const originalOnClose = sheetObj.onClose;
  sheetObj.onClose = () => {
    document.removeEventListener("keydown", onKey);
    if (originalOnClose) originalOnClose();
  };
  document.body.appendChild(overlay);
  document.body.style.overflow = "hidden";
  openSheets.push(sheetObj);
  if (onMount) onMount(sheetObj);
  return sheetObj;
}

export function confirmDialog({
  title = "Are you sure?",
  message = "",
  confirmLabel = "Confirm",
  danger = false,
  detail = "",
} = {}) {
  return new Promise((resolve) => {
    let settled = false;
    const done = (value) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };
    const s = sheet({
      title,
      subtitle: message,
      content: detail ? `<div class="code-out">${esc(detail)}</div>` : "",
      actions: [
        { label: "Cancel", kind: "ghost", onClick: () => done(false) },
        {
          label: confirmLabel,
          kind: danger ? "danger" : "primary",
          onClick: () => done(true),
        },
      ],
      onClose: () => done(false),
    });
    return s;
  });
}

export function promptDialog({
  title,
  subtitle = "",
  label = "Value",
  value = "",
  placeholder = "",
  confirmLabel = "Save",
  type = "text",
  hint = "",
} = {}) {
  return new Promise((resolve) => {
    let settled = false;
    const done = (v) => {
      if (settled) return;
      settled = true;
      resolve(v);
    };
    const input = el("input", {
      class: "input",
      value,
      placeholder,
      type,
      autocomplete: "off",
      spellcheck: "false",
    });
    const wrap = el("div", { class: "field" }, `<label>${esc(label)}</label>`);
    wrap.appendChild(input);
    if (hint) wrap.appendChild(el("div", { class: "field-hint", html: esc(hint) }));
    sheet({
      title,
      subtitle,
      content: wrap,
      onMount: (s) => {
        setTimeout(() => {
          input.focus();
          input.select();
        }, 120);
        input.addEventListener("keydown", (event) => {
          if (event.key === "Enter") {
            event.preventDefault();
            const v = input.value.trim();
            if (v) {
              done(v);
              closeSheet(s);
            }
          }
        });
      },
      actions: [
        { label: "Cancel", kind: "ghost", onClick: () => done(null) },
        {
          label: confirmLabel,
          kind: "primary",
          onClick: ({ close }) => {
            const v = input.value.trim();
            if (!v) {
              input.focus();
              return false;
            }
            done(v);
            close();
            return false;
          },
        },
      ],
      onClose: () => done(null),
    });
  });
}

/* ------------------------------------------------------------- misc helpers */
export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    notifyOk("Copied", "Copied to clipboard");
    return true;
  } catch {
    try {
      const ta = el("textarea", { style: "position:fixed;opacity:0" });
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
      notifyOk("Copied", "Copied to clipboard");
      return true;
    } catch {
      notifyErr("Copy failed", "Your browser blocked clipboard access");
      return false;
    }
  }
}

export function withBusy(button, promiseFactory, busyLabel) {
  const original = button.innerHTML;
  button.disabled = true;
  if (busyLabel) button.innerHTML = `<span class="spinner"></span>${esc(busyLabel)}`;
  return Promise.resolve()
    .then(promiseFactory)
    .finally(() => {
      button.disabled = false;
      button.innerHTML = original;
    });
}

export function errorText(err) {
  if (!err) return "Unknown error";
  if (err.status === 0) return err.message || "Network error";
  return err.message || String(err);
}

export function showError(err, title = "Action failed") {
  notifyErr(title, errorText(err));
}

export function skeletonRows(count = 4, height = 44) {
  return `<div class="stack">${Array.from({ length: count })
    .map(() => `<div class="skeleton" style="height:${height}px;border-radius:14px"></div>`)
    .join("")}</div>`;
}

export function emptyState(text, iconName = "info", extra = "") {
  return `<div class="empty">${icon(iconName)}<div>${esc(text)}</div>${extra}</div>`;
}

/** Minimal SVG sparkline from a numeric series. */
export function sparkline(values, { width = 300, height = 46, color = "" } = {}) {
  if (!values || values.length < 2) {
    return `<svg class="sparkline" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none"></svg>`;
  }
  const max = Math.max(...values, 1);
  const min = Math.min(...values, 0);
  const span = max - min || 1;
  const stepX = width / (values.length - 1);
  const points = values.map((v, i) => {
    const x = i * stepX;
    const y = height - 3 - ((v - min) / span) * (height - 8);
    return `${x.toFixed(2)},${y.toFixed(2)}`;
  });
  const line = `M${points.join(" L")}`;
  const area = `${line} L${width},${height} L0,${height} Z`;
  return `<svg class="sparkline" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none">
    <defs><linearGradient id="sparkFill" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="${color || "var(--accent)"}" stop-opacity="0.26"/>
      <stop offset="100%" stop-color="${color || "var(--accent)"}" stop-opacity="0"/>
    </linearGradient></defs>
    <path class="area" d="${area}"/>
    <path class="line" d="${line}" ${color ? `style="stroke:${color}"` : ""}/>
  </svg>`;
}

export function highlightMatch(text, query) {
  if (!query) return esc(text);
  const idx = String(text).toLowerCase().indexOf(String(query).toLowerCase());
  if (idx < 0) return esc(text);
  return `${esc(text.slice(0, idx))}<mark style="background:color-mix(in srgb,var(--accent) 35%,transparent);color:inherit;border-radius:4px">${esc(
    text.slice(idx, idx + query.length))}</mark>${esc(text.slice(idx + query.length))}`;
}

export function sortBy(list, key, direction = "asc") {
  const dir = direction === "desc" ? -1 : 1;
  return [...list].sort((a, b) => {
    const av = a[key];
    const bv = b[key];
    if (typeof av === "number" && typeof bv === "number") return (av - bv) * dir;
    return String(av ?? "").localeCompare(String(bv ?? "")) * dir;
  });
}
