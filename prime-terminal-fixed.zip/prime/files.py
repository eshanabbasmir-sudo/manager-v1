"""Filesystem operations with strict path validation.

Every public function takes the *requested* path from the client and resolves
it through :func:`prime.security.safe_path`, which rejects anything outside the
configured roots and refuses to follow symlinks out of them.
"""
from __future__ import annotations

import errno
import hashlib
import mimetypes
import os
import pwd
import grp
import shutil
import stat as statmod
import subprocess
import tempfile
import time
from typing import Iterable, Iterator, Optional

from . import security
from .config import Config

CHUNK = 256 * 1024
TEXT_SNIFF = 8192


class FileError(Exception):
    def __init__(self, message: str, code: int = 400) -> None:
        super().__init__(message)
        self.message = message
        self.code = code


def _resolve(cfg: Config, requested: str, must_exist: bool = False) -> str:
    try:
        return security.safe_path(requested, cfg.allowed_roots, must_exist=must_exist)
    except security.PathError as exc:
        raise FileError(str(exc), 403 if "outside" in str(exc) else 400)


def _entry(path: str, show_owner: bool = True) -> dict:
    try:
        st = os.lstat(path)
    except OSError as exc:
        raise FileError(f"cannot stat: {exc.strerror}", 404)
    is_link = statmod.S_ISLNK(st.st_mode)
    target_type = None
    if is_link:
        try:
            target = os.stat(path)
            target_type = "dir" if statmod.S_ISDIR(target.st_mode) else "file"
        except OSError:
            target_type = "broken"
    kind = ("dir" if statmod.S_ISDIR(st.st_mode)
            else "link" if is_link
            else "file" if statmod.S_ISREG(st.st_mode)
            else "block" if statmod.S_ISBLK(st.st_mode)
            else "char" if statmod.S_ISCHR(st.st_mode)
            else "fifo" if statmod.S_ISFIFO(st.st_mode)
            else "socket" if statmod.S_ISSOCK(st.st_mode) else "other")
    owner = group = ""
    if show_owner:
        try:
            owner = pwd.getpwuid(st.st_uid).pw_name
        except KeyError:
            owner = str(st.st_uid)
        try:
            group = grp.getgrgid(st.st_gid).gr_name
        except KeyError:
            group = str(st.st_gid)
    return {
        "name": os.path.basename(path) or "/",
        "path": path,
        "type": kind,
        "target_type": target_type,
        "size": st.st_size if kind == "file" else (0 if kind == "dir" else st.st_size),
        "mtime": st.st_mtime,
        "ctime": st.st_ctime,
        "mode": statmod.S_IMODE(st.st_mode),
        "mode_string": statmod.filemode(st.st_mode),
        "uid": st.st_uid,
        "gid": st.st_gid,
        "owner": owner,
        "group": group,
        "nlink": st.st_nlink,
        "readable": os.access(path, os.R_OK),
        "writable": os.access(path, os.W_OK),
        "is_symlink": is_link,
        "mime": (mimetypes.guess_type(path)[0] or "application/octet-stream")
                if kind == "file" else None,
    }


def list_dir(cfg: Config, requested: str, offset: int = 0, limit: int = 200,
             show_hidden: bool = True, sort: str = "name", order: str = "asc") -> dict:
    path = _resolve(cfg, requested, must_exist=True)
    if not os.path.isdir(path):
        raise FileError("not a directory", 400)
    if not os.access(path, os.R_OK | os.X_OK):
        raise FileError("permission denied", 403)
    try:
        with os.scandir(path) as it:
            names = [e.name for e in it]
    except PermissionError:
        raise FileError("permission denied", 403)
    except OSError as exc:
        raise FileError(f"cannot read directory: {exc.strerror}", 500)
    names = [n for n in names if show_hidden or not n.startswith(".")]
    entries = []
    for name in names:
        try:
            entries.append(_entry(os.path.join(path, name)))
        except FileError:
            continue
    key = {
        "name": lambda e: e["name"].lower(),
        "size": lambda e: e["size"],
        "mtime": lambda e: e["mtime"],
        "type": lambda e: e["type"],
        "owner": lambda e: e["owner"],
    }.get(sort, lambda e: e["name"].lower())
    entries.sort(key=lambda e: (e["type"] not in ("dir",), key(e)), reverse=(order == "desc"))
    total = len(entries)
    offset = max(0, offset)
    limit = max(1, min(1000, limit))
    page = entries[offset:offset + limit]
    parent = os.path.dirname(path) if path != "/" else None
    try:
        st = os.statvfs(path)
        fs = {"total": st.f_blocks * st.f_frsize, "free": st.f_bavail * st.f_frsize}
    except OSError:
        fs = None
    return {
        "path": path,
        "parent": parent,
        "entries": page,
        "total": total,
        "offset": offset,
        "limit": limit,
        "has_more": offset + limit < total,
        "writable": os.access(path, os.W_OK),
        "readable": os.access(path, os.R_OK),
        "fs": fs,
        "roots": cfg.allowed_roots,
        "breadcrumbs": _breadcrumbs(path, cfg.allowed_roots),
        "protected": _protected_hit(path, cfg),
    }


def _breadcrumbs(path: str, roots: Iterable[str]) -> list[dict]:
    parts = [p for p in path.split("/") if p]
    out = [{"name": "/", "path": "/"}]
    acc = ""
    for part in parts:
        acc += "/" + part
        out.append({"name": part, "path": acc})
    return out


def _protected_hit(path: str, cfg: Config) -> bool:
    return security.is_protected(path, cfg.protected_paths)


def stat_path(cfg: Config, requested: str) -> dict:
    path = _resolve(cfg, requested, must_exist=True)
    entry = _entry(path)
    entry["protected"] = _protected_hit(path, cfg)
    entry["breadcrumbs"] = _breadcrumbs(path, cfg.allowed_roots)
    return entry


def is_probably_text(path: str) -> bool:
    try:
        with open(path, "rb") as fh:
            chunk = fh.read(TEXT_SNIFF)
    except OSError:
        return False
    if b"\x00" in chunk:
        return False
    try:
        chunk.decode("utf-8")
        return True
    except UnicodeDecodeError:
        try:
            chunk.decode("latin-1")
            return True
        except UnicodeDecodeError:
            return False


def read_text(cfg: Config, requested: str) -> dict:
    path = _resolve(cfg, requested, must_exist=True)
    if os.path.isdir(path):
        raise FileError("is a directory", 400)
    if not os.access(path, os.R_OK):
        raise FileError("permission denied", 403)
    size = os.path.getsize(path)
    limit = cfg.text_preview_kb * 1024
    if size > limit:
        raise FileError(f"file is larger than the {cfg.text_preview_kb} KB editor limit "
                        f"({size} bytes); download it instead", 413)
    if not os.access(path, os.R_OK):
        raise FileError("permission denied", 403)
    if not is_probably_text(path):
        raise FileError("file looks binary and cannot be edited as text", 415)
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            content = fh.read()
    except PermissionError:
        raise FileError("permission denied", 403)
    except OSError as exc:
        raise FileError(f"cannot read file: {exc.strerror}", 500)
    st = os.stat(path)
    return {"path": path, "content": content, "mtime": st.st_mtime, "size": size,
            "mode": statmod.S_IMODE(st.st_mode), "mode_string": statmod.filemode(st.st_mode),
            "read_only_mode": not os.access(path, os.W_OK),
            "config_read_only": cfg.read_only_files}


def write_text(cfg: Config, requested: str, content: str, expected_mtime: float | None = None,
               create: bool = False) -> dict:
    path = _resolve(cfg, requested)
    if cfg.read_only_files:
        raise FileError("the panel is configured read-only (read_only_files)", 403)
    exists = os.path.exists(path)
    if exists:
        if os.path.isdir(path):
            raise FileError("is a directory", 400)
        if not os.access(path, os.W_OK):
            raise FileError("permission denied", 403)
        if expected_mtime is not None:
            cur = os.stat(path).st_mtime
            if abs(cur - float(expected_mtime)) > 0.001:
                raise FileError("the file changed on disk since you opened it "
                                "(reload before saving)", 409)
    else:
        if not create:
            raise FileError("file does not exist", 404)
        parent = os.path.dirname(path)
        if not os.path.isdir(parent):
            raise FileError("parent directory does not exist", 404)
        if not os.access(parent, os.W_OK):
            raise FileError("permission denied", 403)
    payload = content.encode("utf-8")
    if len(payload) > cfg.text_preview_kb * 1024:
        raise FileError("content exceeds the editor limit", 413)
    tmp = None
    try:
        if exists:
            st = os.stat(path)
            fd, tmp = tempfile.mkstemp(prefix=".prime-", dir=os.path.dirname(path))
            with os.fdopen(fd, "wb") as fh:
                fh.write(payload)
            os.chmod(tmp, statmod.S_IMODE(st.st_mode))
            try:
                os.chown(tmp, st.st_uid, st.st_gid)
            except PermissionError:
                pass
            os.replace(tmp, path)
            tmp = None
        else:
            with open(path, "wb") as fh:
                fh.write(payload)
    finally:
        if tmp and os.path.exists(tmp):
            os.unlink(tmp)
    return stat_path(cfg, path)


def mkdir(cfg: Config, parent: str, name: str, mode: int = 0o755) -> dict:
    if cfg.read_only_files:
        raise FileError("panel is configured read-only", 403)
    base = _resolve(cfg, parent, must_exist=True)
    name = security.safe_child_name(name)
    target = os.path.join(base, name)
    if os.path.exists(target):
        raise FileError("already exists", 409)
    try:
        os.mkdir(target, mode)
    except PermissionError:
        raise FileError("permission denied", 403)
    except OSError as exc:
        raise FileError(exc.strerror or "cannot create directory", 500)
    return _entry(target)


def create_file(cfg: Config, parent: str, name: str, content: str = "", mode: int = 0o644) -> dict:
    if cfg.read_only_files:
        raise FileError("panel is configured read-only", 403)
    base = _resolve(cfg, parent, must_exist=True)
    name = security.safe_child_name(name)
    target = os.path.join(base, name)
    if os.path.exists(target):
        raise FileError("already exists", 409)
    try:
        fd = os.open(target, os.O_CREAT | os.O_EXCL | os.O_WRONLY, mode)
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(content)
    except PermissionError:
        raise FileError("permission denied", 403)
    except OSError as exc:
        raise FileError(exc.strerror or "cannot create file", 500)
    return _entry(target)


def rename(cfg: Config, requested: str, new_name: str) -> dict:
    if cfg.read_only_files:
        raise FileError("panel is configured read-only", 403)
    src = _resolve(cfg, requested, must_exist=True)
    if _protected_hit(src, cfg):
        raise FileError("this path is protected", 403)
    new_name = security.safe_child_name(new_name)
    dst = os.path.join(os.path.dirname(src), new_name)
    if os.path.exists(dst) and os.path.samefile(src, dst) is False:
        raise FileError("destination already exists", 409)
    try:
        os.rename(src, dst)
    except PermissionError:
        raise FileError("permission denied", 403)
    except OSError as exc:
        raise FileError(exc.strerror or "cannot rename", 500)
    return _entry(dst)


def _copy_path(src: str, dst: str) -> None:
    if os.path.isdir(src) and not os.path.islink(src):
        shutil.copytree(src, dst, symlinks=True)
    else:
        shutil.copy2(src, dst, follow_symlinks=False)


def copy_or_move(cfg: Config, requested: str, destination_dir: str, move: bool = False) -> dict:
    if cfg.read_only_files:
        raise FileError("panel is configured read-only", 403)
    src = _resolve(cfg, requested, must_exist=True)
    if _protected_hit(src, cfg):
        raise FileError("this path is protected", 403)
    dst_dir = _resolve(cfg, destination_dir, must_exist=True)
    if not os.path.isdir(dst_dir):
        raise FileError("destination is not a directory", 400)
    dst = os.path.join(dst_dir, os.path.basename(src))
    if os.path.abspath(dst).startswith(os.path.abspath(src) + os.sep):
        raise FileError("cannot copy a directory into itself", 400)
    if os.path.exists(dst):
        base, ext = os.path.splitext(dst)
        candidate = f"{base} (copy){ext}"
        i = 2
        while os.path.exists(candidate):
            candidate = f"{base} (copy {i}){ext}"
            i += 1
        dst = candidate
    try:
        if move:
            try:
                os.rename(src, dst)
            except OSError as exc:
                if exc.errno == errno.EXDEV:
                    _copy_path(src, dst)
                    if os.path.isdir(src) and not os.path.islink(src):
                        shutil.rmtree(src)
                    else:
                        os.unlink(src)
                else:
                    raise
        else:
            _copy_path(src, dst)
    except PermissionError:
        raise FileError("permission denied", 403)
    except OSError as exc:
        raise FileError(exc.strerror or "operation failed", 500)
    return _entry(dst)


def delete(cfg: Config, requested: str, recursive: bool = False) -> dict:
    if cfg.read_only_files:
        raise FileError("panel is configured read-only", 403)
    path = _resolve(cfg, requested, must_exist=True)
    if security.is_protected(path, cfg.protected_paths):
        raise FileError("this path is protected and cannot be deleted", 403)
    cfg_dir = os.path.realpath(cfg.data_dir)
    if path == cfg_dir or path.startswith(cfg_dir + os.sep):
        raise FileError("refusing to delete the panel's own data directory", 403)
    if os.path.isdir(path) and not os.path.islink(path):
        try:
            if not recursive and os.listdir(path):
                raise FileError("directory is not empty (pass recursive=true)", 409)
            if recursive:
                shutil.rmtree(path)
            else:
                os.rmdir(path)
        except PermissionError:
            raise FileError("permission denied", 403)
        except OSError as exc:
            raise FileError(exc.strerror or "cannot delete directory", 500)
    else:
        try:
            os.unlink(path)
        except PermissionError:
            raise FileError("permission denied", 403)
        except OSError as exc:
            raise FileError(exc.strerror or "cannot delete file", 500)
    return {"deleted": path, "recursive": recursive}


def chmod_path(cfg: Config, requested: str, mode: str) -> dict:
    path = _resolve(cfg, requested, must_exist=True)
    try:
        value = int(mode, 8)
    except (TypeError, ValueError):
        raise FileError("mode must be octal, e.g. 644", 400)
    if value < 0 or value > 0o7777:
        raise FileError("mode out of range", 400)
    if cfg.read_only_files:
        raise FileError("panel is configured read-only", 403)
    try:
        os.chmod(path, value)
    except PermissionError:
        raise FileError("permission denied", 403)
    except OSError as exc:
        raise FileError(exc.strerror or "cannot chmod", 500)
    return _entry(path)


def chown_path(cfg: Config, requested: str, owner: str | None, group: str | None) -> dict:
    path = _resolve(cfg, requested, must_exist=True)
    uid = -1
    gid = -1
    try:
        if owner:
            uid = int(owner) if owner.isdigit() else pwd.getpwnam(owner).pw_uid
        if group:
            gid = int(group) if group.isdigit() else grp.getgrnam(group).gr_gid
    except (KeyError, ValueError):
        raise FileError("unknown user or group", 400)
    try:
        os.chown(path, uid, gid)
    except PermissionError:
        raise FileError("permission denied (chown usually requires root)", 403)
    except OSError as exc:
        raise FileError(exc.strerror or "cannot chown", 500)
    return _entry(path)


def search(cfg: Config, root: str, query: str, limit: int = 300, max_depth: int = 8,
           include_dirs: bool = True) -> dict:
    base = _resolve(cfg, root, must_exist=True)
    if not os.path.isdir(base):
        raise FileError("not a directory", 400)
    q = (query or "").strip().lower()
    if len(q) < 2:
        raise FileError("search query must be at least 2 characters", 400)
    limit = max(1, min(1000, limit))
    results = []
    truncated = False
    start = time.time()
    base_depth = base.rstrip("/").count("/")
    for dirpath, dirnames, filenames in os.walk(base, followlinks=False,
                                                onerror=lambda e: None):
        if time.time() - start > 20:
            truncated = True
            break
        depth = dirpath.rstrip("/").count("/") - base_depth
        if depth >= max_depth:
            dirnames[:] = []
        for name in (dirnames if include_dirs else []) + filenames:
            if q in name.lower():
                full = os.path.join(dirpath, name)
                try:
                    results.append(_entry(full))
                except FileError:
                    continue
                if len(results) >= limit:
                    truncated = True
                    break
        if len(results) >= limit:
            break
    return {"query": query, "root": base, "items": results, "truncated": truncated}


def sha256_file(path: str, limit_bytes: int = 512 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    seen = 0
    with open(path, "rb") as fh:
        while True:
            chunk = fh.read(CHUNK)
            if not chunk:
                break
            h.update(chunk)
            seen += len(chunk)
            if seen > limit_bytes:
                raise FileError("file too large to hash", 413)
    return h.hexdigest()


def open_for_download(cfg: Config, requested: str) -> tuple[str, str, int]:
    path = _resolve(cfg, requested, must_exist=True)
    if os.path.isdir(path):
        raise FileError("cannot download a directory; archive it first", 400)
    if not os.access(path, os.R_OK):
        raise FileError("permission denied", 403)
    return path, os.path.basename(path) or "download", os.path.getsize(path)


def iter_file(path: str, start: int = 0, end: int | None = None) -> Iterator[bytes]:
    with open(path, "rb") as fh:
        if start:
            fh.seek(start)
        remaining = None if end is None else max(0, end - start + 1)
        while True:
            size = CHUNK if remaining is None else min(CHUNK, remaining)
            if size <= 0:
                break
            chunk = fh.read(size)
            if not chunk:
                break
            yield chunk
            if remaining is not None:
                remaining -= len(chunk)


def make_archive(cfg: Config, requested: str) -> tuple[str, str]:
    """tar.gz a directory into a temp file for download."""
    path = _resolve(cfg, requested, must_exist=True)
    if not os.path.isdir(path):
        raise FileError("only directories can be archived", 400)
    tmp_dir = tempfile.mkdtemp(prefix="prime-archive-")
    name = f"{os.path.basename(path) or 'root'}-{int(time.time())}.tar.gz"
    out = os.path.join(tmp_dir, name)
    try:
        import tarfile
        with tarfile.open(out, "w:gz") as tar:
            tar.add(path, arcname=os.path.basename(path) or "root")
    except OSError as exc:
        raise FileError(f"cannot archive: {exc}", 500)
    return out, name


def disk_usage_of(path: str) -> dict:
    try:
        out = subprocess.run(["du", "-sh", path], capture_output=True, text=True, timeout=30)
        return {"raw": out.stdout.strip()}
    except (OSError, subprocess.SubprocessError):
        return {"raw": ""}
