"""Authentication endpoints."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request, Response
from pydantic import BaseModel, Field

from .. import security
from ..auth import AuthError
from ..deps import SESSION_COOKIE, client_ip, get_rt, get_session, require_csrf

router = APIRouter(prefix="/api/auth", tags=["auth"])


class Credentials(BaseModel):
    username: str = Field(default="admin", max_length=64)
    password: str = Field(min_length=1, max_length=512)


class SetupPayload(BaseModel):
    username: str = Field(default="admin", min_length=1, max_length=64)
    password: str = Field(min_length=10, max_length=512)


class PasswordChange(BaseModel):
    current: str = Field(min_length=1, max_length=512)
    new: str = Field(min_length=10, max_length=512)


def _set_cookies(response: Response, rt, session, request: Request) -> None:
    secure = rt.cfg.secure_cookies or (
        request.url.scheme == "https")
    response.set_cookie(SESSION_COOKIE, session.token, max_age=rt.cfg.session_ttl,
                        httponly=True, samesite="strict", secure=secure, path="/")
    # readable mirror for double-submit CSRF checks
    response.set_cookie("prime_csrf", session.csrf, max_age=rt.cfg.session_ttl,
                        httponly=False, samesite="strict", secure=secure, path="/")


@router.get("/status")
async def status(request: Request):
    rt = get_rt(request)
    token = request.cookies.get(SESSION_COOKIE)
    session = rt.auth.lookup(token) if token else None
    return {
        "authenticated": session is not None,
        "needs_setup": rt.auth.user_count() == 0,
        "user": session.username if session else None,
        "csrf": session.csrf if session else None,
        "version": rt.version,
        "secure_cookies": rt.cfg.secure_cookies,
        "behind_proxy": rt.cfg.behind_proxy,
    }


@router.post("/setup")
async def setup(payload: SetupPayload, request: Request, response: Response):
    rt = get_rt(request)
    if rt.auth.user_count() != 0:
        raise HTTPException(403, "this panel already has an account; use the login form")
    ip = client_ip(request)
    problems = security.password_problems(payload.password)
    if problems:
        raise HTTPException(400, " ".join(problems))
    try:
        rt.auth.create_user(payload.username.strip(), payload.password)
        rt.auth.audit("setup", f"account {payload.username} created", True,
                      payload.username, ip)
        session = rt.auth.authenticate(payload.username.strip(), payload.password, ip,
                                       request.headers.get("user-agent", ""))
    except (ValueError, AuthError) as exc:
        raise HTTPException(400, str(exc))
    _set_cookies(response, rt, session, request)
    return {"ok": True, "user": session.username, "csrf": session.csrf}


@router.post("/login")
async def login(payload: Credentials, request: Request, response: Response):
    rt = get_rt(request)
    ip = client_ip(request)
    key = f"{ip}|{payload.username.lower().strip()}"
    wait = rt.limiter.retry_after(key) or rt.limiter.retry_after(ip)
    if wait > 0:
        rt.auth.audit("login", f"rate limited ({payload.username})", False, payload.username, ip)
        raise HTTPException(429, f"too many failed attempts; try again in {wait} seconds")
    try:
        session = rt.auth.authenticate(payload.username.strip(), payload.password, ip,
                                       request.headers.get("user-agent", ""))
    except AuthError as exc:
        delay = rt.limiter.register_failure(key)
        rt.limiter.register_failure(ip)
        rt.auth.audit("login", f"failed for {payload.username}", False, payload.username, ip)
        raise HTTPException(401, str(exc))
    rt.limiter.reset(key)
    rt.auth.audit("login", "success", True, session.username, ip)
    _set_cookies(response, rt, session, request)
    return {"ok": True, "user": session.username, "csrf": session.csrf}


@router.post("/logout")
async def logout(request: Request, response: Response):
    rt = get_rt(request)
    session = get_session(request, required=False)
    if session:
        rt.auth.destroy(session.token)
        rt.auth.audit("logout", "", True, session.username, client_ip(request))
    response.delete_cookie(SESSION_COOKIE, path="/")
    response.delete_cookie("prime_csrf", path="/")
    return {"ok": True}


@router.get("/me")
async def me(request: Request):
    rt = get_rt(request)
    session = get_session(request)
    return {"user": session.as_public(), "version": rt.version,
            "server_time": __import__("time").time()}


@router.post("/password")
async def change_password(payload: PasswordChange, request: Request, response: Response):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        rt.auth.set_password(session.username, payload.new, require_current=payload.current)
    except AuthError as exc:
        rt.auth.audit("password", "change rejected", False, session.username, client_ip(request))
        raise HTTPException(403, str(exc))
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    # set_password invalidates sessions; create a fresh one for the current browser
    new_session = rt.auth.authenticate(session.username, payload.new, client_ip(request),
                                       request.headers.get("user-agent", ""))
    _set_cookies(response, rt, new_session, request)
    rt.auth.audit("password", "changed", True, session.username, client_ip(request))
    return {"ok": True, "csrf": new_session.csrf}


@router.get("/sessions")
async def list_sessions(request: Request):
    rt = get_rt(request)
    session = get_session(request)
    return {"sessions": rt.auth.list_sessions(session.username), "current_ip": client_ip(request)}


@router.post("/sessions/revoke")
async def revoke_sessions(request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    rt.auth.destroy_all_for_user(session.username)
    new_session = rt.auth.authenticate  # noqa: F841  (intentionally not re-created)
    rt.auth.audit("sessions", "all revoked", True, session.username, client_ip(request))
    return {"ok": True, "logged_out": True}


@router.post("/ws-ticket")
async def ws_ticket(request: Request):
    """Short-lived single-use ticket for opening a WebSocket."""
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    ticket = rt.auth.issue_ws_ticket(session)
    return {"ticket": ticket, "expires_in": 45}


@router.get("/audit")
async def audit_log(request: Request, limit: int = 50):
    rt = get_rt(request)
    session = get_session(request)
    return {"items": rt.auth.recent_audit(min(200, max(1, limit))),
            "user": session.username}
