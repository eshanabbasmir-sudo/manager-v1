"""Server management endpoints: services, packages, logs, python, diagnostics, SSH."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query, Request
from pydantic import BaseModel, Field

from .. import ops
from ..deps import client_ip, get_rt, get_session, require_csrf

router = APIRouter(prefix="/api", tags=["ops"])


class ServiceAction(BaseModel):
    name: str
    action: str


class PackageAction(BaseModel):
    names: list[str] = Field(default_factory=list)
    action: str = "install"


class PythonRun(BaseModel):
    code: str = Field(max_length=512 * 1024)
    filename: str = "script.py"
    cwd: str | None = None
    args: list[str] = Field(default_factory=list)


class KeyAdd(BaseModel):
    user: str
    key: str
    comment: str = ""


# --------------------------------------------------------------------- jobs
@router.get("/jobs")
async def list_jobs(request: Request):
    rt = get_rt(request)
    get_session(request)
    return {"items": rt.jobs.list()}


@router.get("/jobs/{job_id}")
async def get_job(job_id: str, request: Request):
    rt = get_rt(request)
    get_session(request)
    job = rt.jobs.get(job_id)
    if not job:
        raise HTTPException(404, "no such job")
    return job.public()


@router.post("/jobs/{job_id}/cancel")
async def cancel_job(job_id: str, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    ok = await rt.jobs.cancel(job_id)
    if not ok:
        raise HTTPException(404, "job is not running")
    return {"ok": True}


# ----------------------------------------------------------------- services
@router.get("/services")
async def services(request: Request):
    get_session(request)
    return await ops.list_services()


@router.post("/services/action")
async def service_action(payload: ServiceAction, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        result = await ops.service_action(payload.name, payload.action, rt.jobs)
    except ops.OpError as exc:
        rt.auth.audit("service", f"{payload.action} {payload.name}: {exc.message}", False,
                      session.username, client_ip(request))
        raise HTTPException(exc.code, exc.message)
    rt.auth.audit("service", f"{payload.action} {payload.name}", True, session.username,
                  client_ip(request))
    return result


@router.get("/services/logs")
async def service_logs(request: Request, name: str, lines: int = 200):
    get_session(request)
    try:
        return await ops.service_logs(name, lines)
    except ops.OpError as exc:
        raise HTTPException(exc.code, exc.message)


# ----------------------------------------------------------------- packages
@router.get("/packages")
async def package_list(request: Request):
    get_session(request)
    return await ops.package_list_installed()


@router.get("/packages/search")
async def package_search(request: Request, q: str = Query(min_length=2, max_length=100)):
    get_session(request)
    try:
        return await ops.package_search(q)
    except ops.OpError as exc:
        raise HTTPException(exc.code, exc.message)


@router.post("/packages/action")
async def package_action(payload: PackageAction, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    if payload.action not in ("install", "remove", "upgrade"):
        raise HTTPException(400, "unsupported action")
    try:
        result = await ops.package_install(payload.names, payload.action, rt.jobs)
    except ops.OpError as exc:
        rt.auth.audit("package", f"{payload.action}: {exc.message}", False, session.username,
                      client_ip(request))
        raise HTTPException(exc.code, exc.message)
    rt.auth.audit("package", f"{payload.action} {' '.join(payload.names)}", True,
                  session.username, client_ip(request))
    return result


# --------------------------------------------------------------------- logs
@router.get("/logs")
async def log_sources(request: Request):
    rt = get_rt(request)
    get_session(request)
    return ops.log_sources(rt.cfg)


@router.get("/logs/tail")
async def log_tail(request: Request, path: str, lines: int = 200, grep: str = ""):
    rt = get_rt(request)
    get_session(request)
    try:
        return ops.tail_file(rt.cfg, path, lines, grep)
    except ops.OpError as exc:
        raise HTTPException(exc.code, exc.message)


@router.get("/logs/journal")
async def journal(request: Request, lines: int = 200, unit: str | None = None, grep: str = "",
                  priority: str = "all"):
    get_session(request)
    try:
        return await ops.journal_lines(lines, unit, grep, priority)
    except ops.OpError as exc:
        raise HTTPException(exc.code, exc.message)


# ------------------------------------------------------------------- python
@router.post("/python/run")
async def python_run(payload: PythonRun, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        result = await ops.run_python(rt.cfg, payload.code, payload.filename, payload.cwd,
                                      payload.args)
    except ops.OpError as exc:
        raise HTTPException(exc.code, exc.message)
    rt.auth.audit("python.run", payload.filename, bool(result.get("ok")), session.username,
                  client_ip(request))
    return result


# -------------------------------------------------------------- diagnostics
@router.get("/diagnostics/tools")
async def diag_tools(request: Request):
    get_session(request)
    import shutil
    tools = []
    for name, spec in ops.DIAG_TOOLS.items():
        exe = spec["argv"][0]
        tools.append({"id": name, "label": spec["label"], "command": " ".join(spec["argv"]),
                      "available": shutil.which(exe) is not None,
                      "needs_target": "target" in spec["args"]})
    return {"tools": tools}


@router.post("/diagnostics/run")
async def diag_run(request: Request, tool: str = Query(...), target: str = Query("")):
    get_session(request)
    try:
        return await ops.diagnose(tool, target)
    except ops.OpError as exc:
        raise HTTPException(exc.code, exc.message)


# ---------------------------------------------------------------------- ssh
@router.get("/ssh/keys")
async def ssh_keys(request: Request, user: str):
    get_session(request)
    try:
        return ops.list_ssh_keys(user)
    except ops.OpError as exc:
        raise HTTPException(exc.code, exc.message)


@router.post("/ssh/keys")
async def ssh_add_key(payload: KeyAdd, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        result = ops.add_ssh_key(payload.user, payload.key, payload.comment)
    except ops.OpError as exc:
        rt.auth.audit("ssh.add_key", f"{payload.user}: {exc.message}", False, session.username,
                      client_ip(request))
        raise HTTPException(exc.code, exc.message)
    rt.auth.audit("ssh.add_key", payload.user, True, session.username, client_ip(request))
    return result


@router.delete("/ssh/keys")
async def ssh_remove_key(request: Request, user: str, index: int):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        result = ops.remove_ssh_key(user, index)
    except ops.OpError as exc:
        raise HTTPException(exc.code, exc.message)
    rt.auth.audit("ssh.remove_key", f"{user}#{index}", True, session.username, client_ip(request))
    return result


@router.post("/ssh/keygen")
async def ssh_keygen(request: Request, user: str, comment: str = "prime-terminal"):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        result = await ops.generate_ssh_keypair(user, comment)
    except ops.OpError as exc:
        raise HTTPException(exc.code, exc.message)
    rt.auth.audit("ssh.keygen", user, True, session.username, client_ip(request))
    return result
