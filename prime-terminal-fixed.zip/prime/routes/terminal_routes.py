"""Terminal REST management + the WebSocket bridge to the real PTY."""
from __future__ import annotations

import asyncio
import json
import logging

from fastapi import APIRouter, HTTPException, Request, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, Field, field_validator

from ..deps import SESSION_COOKIE, client_ip, get_rt, get_session, require_csrf

log = logging.getLogger("prime.ws")
router = APIRouter(tags=["terminal"])


class NewSession(BaseModel):
    cols: int = Field(default=80, ge=2, le=512)
    rows: int = Field(default=24, ge=2, le=256)
    cwd: str | None = None
    title: str | None = Field(default=None, max_length=60)

    @field_validator("cols", mode="before")
    @classmethod
    def _clamp_cols(cls, v):
        # clients on small/unlaid-out screens may report 0/1 columns
        try:
            return min(512, max(2, int(v)))
        except (TypeError, ValueError):
            return 80

    @field_validator("rows", mode="before")
    @classmethod
    def _clamp_rows(cls, v):
        try:
            return min(256, max(2, int(v)))
        except (TypeError, ValueError):
            return 24


@router.get("/api/terminal/sessions")
async def list_sessions(request: Request):
    rt = get_rt(request)
    get_session(request)
    return {"items": rt.terms.list(), "shell": rt.cfg.shell_path,
            "max_sessions": rt.cfg.term_max_sessions,
            "linger_seconds": rt.cfg.term_linger}


@router.post("/api/terminal/sessions")
async def create_session(payload: NewSession, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        term = await rt.terms.create(cols=payload.cols, rows=payload.rows, cwd=payload.cwd)
    except RuntimeError as exc:
        raise HTTPException(409, str(exc))
    if payload.title:
        term.title = payload.title
    rt.auth.audit("terminal.new", f"{term.id} ({term.shell})", True, session.username,
                  client_ip(request))
    return term.info()


@router.delete("/api/terminal/sessions/{sid}")
async def close_session(sid: str, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    ok = await rt.terms.close(sid, force=True)
    if not ok:
        raise HTTPException(404, "no such session")
    rt.auth.audit("terminal.close", sid, True, session.username, client_ip(request))
    return {"ok": True}


@router.post("/api/terminal/sessions/{sid}/rename")
async def rename_session(sid: str, request: Request, title: str = ""):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    term = rt.terms.get(sid)
    if not term:
        raise HTTPException(404, "no such session")
    term.title = (title or "").strip()[:60] or term.title
    return term.info()


@router.websocket("/api/ws/terminal/{sid}")
async def terminal_ws(ws: WebSocket, sid: str):
    rt = ws.app.state.rt
    # --- authentication: cookie + single-use ticket, origin check -----------
    origin = ws.headers.get("origin")
    host = ws.headers.get("host", "")
    if origin:
        from urllib.parse import urlsplit
        try:
            if urlsplit(origin).netloc != host:
                await ws.close(code=4403)
                return
        except ValueError:
            await ws.close(code=4403)
            return
    token = ws.cookies.get(SESSION_COOKIE)
    session = rt.auth.lookup(token) if token else None
    if session is None:
        await ws.close(code=4401)
        return
    ticket = ws.query_params.get("ticket", "")
    if not rt.auth.consume_ws_ticket(ticket, token):
        await ws.close(code=4401)
        return

    term = rt.terms.get(sid)
    await ws.accept()
    if term is None:
        await ws.send_text(json.dumps({"type": "error", "message": "session no longer exists"}))
        await ws.close()
        return

    ip = ws.client.host if ws.client else ""
    rt.auth.audit("terminal.attach", sid, True, session.username, ip)

    client_id = term._next_client_id
    term._next_client_id += 1
    queue: asyncio.Queue[bytes] = asyncio.Queue(maxsize=512)
    from ..ptyterm import Client
    term.clients[client_id] = Client(queue=queue, id=client_id)
    term.last_active = __import__("time").time()
    log.info("client %s attached to terminal %s", client_id, sid)

    async def pump_pty() -> None:
        while True:
            data = await queue.get()
            if data == b"":
                await ws.send_text(json.dumps({
                    "type": "exit", "code": term.exit_code}))
                return
            await ws.send_bytes(data)

    async def pump_client() -> None:
        while True:
            message = await ws.receive()
            if message["type"] == "websocket.disconnect":
                return
            if message.get("bytes"):
                rt.terms.write(term, message["bytes"])
                continue
            text = message.get("text") or ""
            if not text:
                continue
            if text[0] == "{":
                try:
                    payload = json.loads(text)
                except json.JSONDecodeError:
                    rt.terms.write(term, text.encode())
                    continue
                kind = payload.get("type")
                if kind == "input":
                    rt.terms.write(term, str(payload.get("data", "")).encode())
                elif kind == "resize":
                    try:
                        cols = min(512, max(2, int(payload.get("cols", 80))))
                        rows = min(256, max(2, int(payload.get("rows", 24))))
                    except (TypeError, ValueError):
                        continue
                    rt.terms.resize(term, cols, rows)
                elif kind == "ping":
                    await ws.send_text(json.dumps({"type": "pong", "t": payload.get("t")}))
                elif kind == "signal":
                    import signal as sigmod
                    name = str(payload.get("signal", "")).upper()
                    sig = {"INT": sigmod.SIGINT, "TERM": sigmod.SIGTERM,
                           "HUP": sigmod.SIGHUP, "QUIT": sigmod.SIGQUIT}.get(name)
                    if sig and term.proc.poll() is None:
                        try:
                            term.proc.send_signal(sig)
                        except OSError:
                            pass
            else:
                rt.terms.write(term, text.encode())

    connected = True
    try:
        # replay scrollback so reconnects keep their context
        snapshot = term.snapshot_bytes()
        if snapshot:
            await ws.send_bytes(snapshot)
        await ws.send_text(json.dumps({"type": "ready", "id": sid,
                                       "cols": term.cols, "rows": term.rows,
                                       "pid": term.proc.pid}))
        tasks = [asyncio.create_task(pump_pty()), asyncio.create_task(pump_client())]
        done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
        for task in pending:
            task.cancel()
        for task in done:
            exc = task.exception()
            if exc and not isinstance(exc, (WebSocketDisconnect, asyncio.CancelledError)):
                log.warning("terminal pump task ended: %r", exc)
            else:
                log.debug("terminal pump task completed normally")
    except WebSocketDisconnect:
        pass
    except RuntimeError as exc:
        log.warning("terminal websocket runtime error: %r", exc)
    finally:
        term.clients.pop(client_id, None)
        term.last_active = __import__("time").time()
        log.info("client %s detached from terminal %s", client_id, sid)
        if connected:
            try:
                await ws.close()
            except RuntimeError:
                pass
