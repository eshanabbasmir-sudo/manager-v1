"""Filesystem API. Every path passes through safe_path() before use."""
from __future__ import annotations

import os
import re
import tempfile
import urllib.parse

from fastapi import APIRouter, HTTPException, Query, Request, Response
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel, Field

from .. import files, security
from ..deps import client_ip, get_rt, get_session, require_csrf

router = APIRouter(prefix="/api/files", tags=["files"])


def _handle(exc: Exception):
    if isinstance(exc, files.FileError):
        raise HTTPException(exc.code, exc.message)
    if isinstance(exc, security.PathError):
        raise HTTPException(403, str(exc))
    if isinstance(exc, PermissionError):
        raise HTTPException(403, "permission denied")
    if isinstance(exc, FileNotFoundError):
        raise HTTPException(404, "not found")
    raise exc


class WritePayload(BaseModel):
    path: str
    content: str = ""
    expected_mtime: float | None = None
    create: bool = False


class MkdirPayload(BaseModel):
    path: str = Field(description="parent directory")
    name: str
    mode: str = "755"


class CreatePayload(BaseModel):
    path: str
    name: str
    content: str = ""
    mode: str = "644"


class RenamePayload(BaseModel):
    path: str
    name: str


class TransferPayload(BaseModel):
    path: str
    destination: str
    move: bool = False


class DeletePayload(BaseModel):
    path: str
    recursive: bool = False


class ChmodPayload(BaseModel):
    path: str
    mode: str


class ChownPayload(BaseModel):
    path: str
    owner: str | None = None
    group: str | None = None


class SearchPayload(BaseModel):
    root: str
    query: str
    limit: int = 300
    max_depth: int = 8
    include_dirs: bool = True


def _octal(value: str, default: str) -> int:
    try:
        return int(value or default, 8)
    except ValueError:
        raise HTTPException(400, "mode must be octal, e.g. 755")


@router.get("/roots")
async def roots(request: Request):
    get_session(request)
    rt = get_rt(request)
    home = os.path.expanduser("~")
    return {
        "roots": rt.cfg.allowed_roots,
        "home": home,
        "cwd": os.getcwd(),
        "read_only": rt.cfg.read_only_files,
        "max_upload_mb": rt.cfg.max_upload_mb,
        "edit_limit_kb": rt.cfg.text_preview_kb,
        "common": [p for p in ("/", home, "/etc", "/var/log", "/var/www", "/opt", "/srv",
                               "/tmp", "/home") if os.path.isdir(p)],
        "protected": rt.cfg.protected_paths,
        "euid": os.geteuid(),
    }


@router.get("/list")
async def list_dir(request: Request, path: str = "/", offset: int = 0, limit: int = 200,
                   hidden: bool = True, sort: str = "name", order: str = "asc"):
    get_session(request)
    rt = get_rt(request)
    try:
        return files.list_dir(rt.cfg, path, offset=offset, limit=limit, show_hidden=hidden,
                              sort=sort, order=order)
    except Exception as exc:  # noqa: BLE001
        _handle(exc)


@router.get("/stat")
async def stat_path(request: Request, path: str):
    get_session(request)
    rt = get_rt(request)
    try:
        return files.stat_path(rt.cfg, path)
    except Exception as exc:  # noqa: BLE001
        _handle(exc)


@router.get("/read")
async def read_file(request: Request, path: str):
    get_session(request)
    rt = get_rt(request)
    try:
        return files.read_text(rt.cfg, path)
    except Exception as exc:  # noqa: BLE001
        _handle(exc)


@router.post("/write")
async def write_file(payload: WritePayload, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        result = files.write_text(rt.cfg, payload.path, payload.content,
                                  payload.expected_mtime, payload.create)
    except Exception as exc:  # noqa: BLE001
        rt.auth.audit("file.write", f"{payload.path}: {exc}", False, session.username,
                      client_ip(request))
        _handle(exc)
    rt.auth.audit("file.write", payload.path, True, session.username, client_ip(request))
    return result


@router.post("/mkdir")
async def mkdir(payload: MkdirPayload, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        entry = files.mkdir(rt.cfg, payload.path, payload.name, _octal(payload.mode, "755"))
    except Exception as exc:  # noqa: BLE001
        _handle(exc)
    rt.auth.audit("file.mkdir", entry["path"], True, session.username, client_ip(request))
    return entry


@router.post("/create")
async def create(payload: CreatePayload, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        entry = files.create_file(rt.cfg, payload.path, payload.name, payload.content,
                                  _octal(payload.mode, "644"))
    except Exception as exc:  # noqa: BLE001
        _handle(exc)
    rt.auth.audit("file.create", entry["path"], True, session.username, client_ip(request))
    return entry


@router.post("/rename")
async def rename(payload: RenamePayload, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        entry = files.rename(rt.cfg, payload.path, payload.name)
    except Exception as exc:  # noqa: BLE001
        _handle(exc)
    rt.auth.audit("file.rename", f"{payload.path} -> {entry['path']}", True, session.username,
                  client_ip(request))
    return entry


@router.post("/transfer")
async def transfer(payload: TransferPayload, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        entry = files.copy_or_move(rt.cfg, payload.path, payload.destination, payload.move)
    except Exception as exc:  # noqa: BLE001
        _handle(exc)
    rt.auth.audit("file.move" if payload.move else "file.copy",
                  f"{payload.path} -> {entry['path']}", True, session.username, client_ip(request))
    return entry


@router.post("/delete")
async def delete(payload: DeletePayload, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        result = files.delete(rt.cfg, payload.path, payload.recursive)
    except Exception as exc:  # noqa: BLE001
        rt.auth.audit("file.delete", f"{payload.path}: {exc}", False, session.username,
                      client_ip(request))
        _handle(exc)
    rt.auth.audit("file.delete", payload.path, True, session.username, client_ip(request))
    return result


@router.post("/chmod")
async def chmod(payload: ChmodPayload, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        entry = files.chmod_path(rt.cfg, payload.path, payload.mode)
    except Exception as exc:  # noqa: BLE001
        _handle(exc)
    rt.auth.audit("file.chmod", f"{payload.path} {payload.mode}", True, session.username,
                  client_ip(request))
    return entry


@router.post("/chown")
async def chown(payload: ChownPayload, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        entry = files.chown_path(rt.cfg, payload.path, payload.owner, payload.group)
    except Exception as exc:  # noqa: BLE001
        _handle(exc)
    rt.auth.audit("file.chown", f"{payload.path} {payload.owner}:{payload.group}", True,
                  session.username, client_ip(request))
    return entry


@router.post("/search")
async def search(payload: SearchPayload, request: Request):
    get_session(request)
    rt = get_rt(request)
    try:
        return files.search(rt.cfg, payload.root, payload.query, payload.limit,
                            payload.max_depth, payload.include_dirs)
    except Exception as exc:  # noqa: BLE001
        _handle(exc)


@router.get("/hash")
async def hash_file(request: Request, path: str):
    get_session(request)
    rt = get_rt(request)
    try:
        real = security.safe_path(path, rt.cfg.allowed_roots, must_exist=True)
        if not os.path.isfile(real):
            raise HTTPException(400, "not a regular file")
        return {"path": real, "sha256": files.sha256_file(real), "size": os.path.getsize(real)}
    except Exception as exc:  # noqa: BLE001
        _handle(exc)


@router.get("/download")
async def download(request: Request, path: str):
    get_session(request)
    rt = get_rt(request)
    try:
        real, name, size = files.open_for_download(rt.cfg, path)
    except Exception as exc:  # noqa: BLE001
        _handle(exc)
    quoted = urllib.parse.quote(name)
    headers = {"Content-Disposition": f"attachment; filename*=UTF-8''{quoted}"}
    range_header = request.headers.get("range")
    if range_header and re.match(r"^bytes=\d*-\d*$", range_header.strip()):
        spec = range_header.strip()[6:]
        start_s, _, end_s = spec.partition("-")
        start = int(start_s) if start_s else 0
        end = int(end_s) if end_s else size - 1
        end = min(end, size - 1)
        if start > end or start >= size:
            return Response(status_code=416,
                            headers={"Content-Range": f"bytes */{size}"})
        chunk = end - start + 1
        headers.update({
            "Content-Range": f"bytes {start}-{end}/{size}",
            "Accept-Ranges": "bytes",
            "Content-Length": str(chunk),
        })
        return StreamingResponse(files.iter_file(real, start, end), status_code=206,
                                 headers=headers, media_type="application/octet-stream")
    headers.update({"Content-Length": str(size), "Accept-Ranges": "bytes"})
    return StreamingResponse(files.iter_file(real), media_type="application/octet-stream",
                             headers=headers)


@router.get("/archive")
async def archive(request: Request, path: str):
    get_session(request)
    rt = get_rt(request)
    try:
        tmp, name = files.make_archive(rt.cfg, path)
    except Exception as exc:  # noqa: BLE001
        _handle(exc)
    quoted = urllib.parse.quote(name)
    return FileResponse(tmp, media_type="application/gzip", filename=None,
                        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quoted}"})


@router.post("/upload")
async def upload(request: Request, path: str = Query(...), name: str = Query(...),
                 overwrite: bool = Query(False)):
    """Stream a raw request body into the target directory (256 KB chunks)."""
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        directory = security.safe_path(path, rt.cfg.allowed_roots, must_exist=True)
    except security.PathError as exc:
        raise HTTPException(403, str(exc))
    if not os.path.isdir(directory):
        raise HTTPException(400, "upload target is not a directory")
    if not os.access(directory, os.W_OK):
        raise HTTPException(403, "permission denied")
    if rt.cfg.read_only_files:
        raise HTTPException(403, "panel is configured read-only")
    try:
        safe_name = security.safe_filename_for_upload(name)
    except security.PathError as exc:
        raise HTTPException(400, str(exc))
    target = os.path.join(directory, safe_name)
    if os.path.exists(target) and not overwrite:
        stem, ext = os.path.splitext(safe_name)
        i = 1
        while os.path.exists(target):
            target = os.path.join(directory, f"{stem} ({i}){ext}")
            i += 1
    limit = rt.cfg.max_upload_mb * 1024 * 1024
    fd, tmp = tempfile.mkstemp(prefix=".prime-upload-", dir=directory)
    written = 0
    try:
        with os.fdopen(fd, "wb") as fh:
            async for chunk in request.stream():
                written += len(chunk)
                if written > limit:
                    raise HTTPException(413, f"upload exceeds {rt.cfg.max_upload_mb} MB")
                fh.write(chunk)
        try:
            os.chmod(tmp, 0o644)
        except OSError:
            pass
        os.replace(tmp, target)
        tmp = ""
    except HTTPException:
        raise
    except OSError as exc:
        raise HTTPException(500, f"upload failed: {exc}")
    finally:
        if tmp and os.path.exists(tmp):
            try:
                os.unlink(tmp)
            except OSError:
                pass
    rt.auth.audit("file.upload", f"{target} ({written} bytes)", True, session.username,
                  client_ip(request))
    return {"ok": True, "path": target, "name": os.path.basename(target), "size": written}
